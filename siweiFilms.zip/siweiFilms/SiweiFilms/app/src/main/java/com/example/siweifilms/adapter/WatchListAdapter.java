package com.example.uscfilms.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.uscfilms.R;
import com.example.uscfilms.bean.TvTopRateBean;
import com.example.uscfilms.bean.WatchListBean;
import com.example.uscfilms.dragview.IDragListener;
import com.example.uscfilms.http.ApiConfig;

import java.util.ArrayList;
import java.util.List;

public class WatchListAdapter extends RecyclerView.Adapter<WatchListAdapter.ViewHolder> {

    private List<WatchListBean> mWatchListBeans = new ArrayList<>();
    private Context mContext;
    private IDragListener listener;

    public void setWatchListBeans(List<WatchListBean> watchListBeans) {
        mWatchListBeans.clear();
        mWatchListBeans = watchListBeans;
        notifyDataSetChanged();
    }

    //    public void setListener(IDragListener listener) {
//        this.listener = listener;
//    }

    public WatchListAdapter(List<WatchListBean> watchListBeans, Context context,IDragListener listener) {
        mWatchListBeans = watchListBeans;
        mContext = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = View.inflate(mContext, R.layout.layout_watchlist_item, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WatchListBean watchListBean = mWatchListBeans.get(position);
        Log.e("onBindViewHolder ", watchListBean.toString());
        holder.tvType.setText(watchListBean.getType());
        Glide.with(mContext)
                .load(ApiConfig.PICTURE_URL + watchListBean.getImgUrl())
                .apply(RequestOptions.bitmapTransform(new RoundedCorners(30)))
                .into(holder.ivPoster);

        holder.ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mWatchListBeans.remove(position);
                notifyDataSetChanged();
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) {
                    mListener.OnClick(watchListBean);
                }
            }
        });


    }

    @Override
    public int getItemCount() {
        return mWatchListBeans.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView ivPoster;
        private ImageView ivDelete;
        private TextView tvType;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            ivPoster = itemView.findViewById(R.id.ivPoster);
            ivDelete = itemView.findViewById(R.id.ivDelete);
            tvType = itemView.findViewById(R.id.tvType);
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (listener != null) {
                        listener.startDrag(ViewHolder.this);
                        return true;
                    }
                    return false;

                }
            });

        }
    }

    public OnWatchListClickListener mListener = null;

    public interface OnWatchListClickListener {
        void OnClick(WatchListBean watchListBean);
    }

    public void setWatchListClickListener(OnWatchListClickListener listener) {
        this.mListener = listener;
    }
}
