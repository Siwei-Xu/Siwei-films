package com.example.uscfilms.dragview;


import androidx.recyclerview.widget.RecyclerView;

public interface IDragListener {
    void startDrag(RecyclerView.ViewHolder holder);

}
