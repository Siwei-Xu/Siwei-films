package com.example.uscfilms;

import android.app.Application;

import com.zhy.http.okhttp.OkHttpUtils;

import java.util.concurrent.TimeUnit;

import cn.bmob.v3.Bmob;
import okhttp3.OkHttpClient;

public class MyApplication extends Application {

    private static Application mApplication;
    @Override
    public void onCreate() {
        super.onCreate();
        Bmob.initialize(this, "71aa0b099030c9586110b46b743c2649");
        mApplication = this;
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
//                .addInterceptor(new LoggerInterceptor("TAG"))
                .connectTimeout(10000L, TimeUnit.MILLISECONDS)
                .readTimeout(10000L, TimeUnit.MILLISECONDS)
                //其他配置
                .build();

        OkHttpUtils.initClient(okHttpClient);

    }

    public static Application getApplication() {
        return mApplication;
    }
}
