package com.example.uscfilms.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.uscfilms.R;
import com.example.uscfilms.bean.MovieCreditBean;
import com.example.uscfilms.http.ApiConfig;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class CastAdapter extends RecyclerView.Adapter<CastAdapter.ViewHolder> {

    private List<MovieCreditBean.CastBean> mCastBeans = new ArrayList<>();
    private Context mContext;

    public CastAdapter(List<MovieCreditBean.CastBean> castBeans, Context context) {
        mCastBeans = castBeans;
        mContext = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = View.inflate(mContext,R.layout.layout_cast_item,null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MovieCreditBean.CastBean castBean = mCastBeans.get(position);
        Glide.with(mContext)
                .load(ApiConfig.PICTURE_URL +castBean.getProfile_path())
                .into(holder.cvCastHead);
        holder.tvCastName.setText(castBean.getName());
    }

    @Override
    public int getItemCount() {
        return mCastBeans.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private CircleImageView cvCastHead;
        private TextView tvCastName;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cvCastHead = itemView.findViewById(R.id.cvCastHead);
            tvCastName = itemView.findViewById(R.id.tvCastName);
        }
    }
}
