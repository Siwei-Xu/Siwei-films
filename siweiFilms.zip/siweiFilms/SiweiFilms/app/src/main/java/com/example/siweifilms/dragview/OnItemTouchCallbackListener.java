package com.example.uscfilms.dragview;


public interface OnItemTouchCallbackListener {

    void onSwiped(int adapterPosition);

    boolean onMove(int srcPosition, int targetPosition);
}
