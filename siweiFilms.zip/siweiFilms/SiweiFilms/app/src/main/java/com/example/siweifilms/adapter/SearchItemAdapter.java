package com.example.uscfilms.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.uscfilms.R;
import com.example.uscfilms.bean.SearchBean;
import com.example.uscfilms.bean.TvPoplarBean;
import com.example.uscfilms.http.ApiConfig;

import java.util.ArrayList;
import java.util.List;

public class SearchItemAdapter extends RecyclerView.Adapter<SearchItemAdapter.ViewHolder>{
    private List<SearchBean.ResultsBean> mResultsBeans = new ArrayList<>();
    private Context mContext;


    public SearchItemAdapter(Context context) {
        mContext = context;
    }

    public void setResultsBeans(List<SearchBean.ResultsBean> resultsBeans) {
        mResultsBeans.clear();
        mResultsBeans = resultsBeans;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = View.inflate(mContext, R.layout.layout_search_item, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SearchBean.ResultsBean resultsBean = mResultsBeans.get(position);
        Log.e("resultsBean",resultsBean.toString());
        Log.e("holder.itemView",ApiConfig.PICTURE_URL + resultsBean.getPoster_path());
        if(!TextUtils.isEmpty(resultsBean.getPoster_path())){
            Glide.with(mContext)
                    .load(ApiConfig.PICTURE_URL + resultsBean.getPoster_path())
                    .apply(RequestOptions.bitmapTransform(new RoundedCorners(30)))
                    .into(holder.ivPoster);

        }else if(!TextUtils.isEmpty(resultsBean.getBackdrop_path())){
            Glide.with(mContext)
                    .load(ApiConfig.PICTURE_URL + resultsBean.getBackdrop_path())
                    .apply(RequestOptions.bitmapTransform(new RoundedCorners(30)))
                    .into(holder.ivPoster);
        }

        if(!TextUtils.isEmpty(resultsBean.getFirst_air_date())){
            holder.tvDate.setText("(" + resultsBean.getFirst_air_date().substring(0,4)+ ")");
        }else if(!TextUtils.isEmpty(resultsBean.getRelease_date())){
            holder.tvDate.setText("(" + resultsBean.getRelease_date().substring(0,4)+ ")");
        }
        if(!TextUtils.isEmpty(resultsBean.getTitle())){
            holder.tvName.setText(resultsBean.getTitle());
        }else if(!TextUtils.isEmpty(resultsBean.getOriginal_name())){
            holder.tvName.setText(resultsBean.getOriginal_name());
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mListener != null){
                    mListener.OnClick(resultsBean,view);
                }
            }
        });
        holder.tvType.setText(resultsBean.getMedia_type().toUpperCase());
        holder.tvStar.setText(resultsBean.getVote_average()+"");
    }

    @Override
    public int getItemCount() {
        return mResultsBeans.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView ivPoster;
        private TextView tvType;
        private TextView tvName;
        private TextView tvDate;
        private TextView tvStar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivPoster = itemView.findViewById(R.id.ivPoster);
            tvType = itemView.findViewById(R.id.tvType);
            tvName = itemView.findViewById(R.id.tvName);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvStar = itemView.findViewById(R.id.tvStar);

        }
    }

    public OnOperationClickListener mListener = null;

    public interface OnOperationClickListener {
        void OnClick(SearchBean.ResultsBean resultsBean,View view);
    }

    public void setOperationClickListener(OnOperationClickListener listener) {
        this.mListener = listener;
    }
}
