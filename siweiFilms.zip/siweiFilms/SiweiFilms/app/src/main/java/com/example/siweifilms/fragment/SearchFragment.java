package com.example.uscfilms.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.uscfilms.R;
import com.example.uscfilms.activity.DetailActivity;
import com.example.uscfilms.adapter.SearchItemAdapter;
import com.example.uscfilms.bean.SearchBean;
import com.example.uscfilms.bean.TvTopRateBean;
import com.example.uscfilms.dragview.DataUtils;
import com.example.uscfilms.http.ApiConfig;
import com.google.gson.Gson;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;

public class SearchFragment extends Fragment {

    private EditText etSearch;
    private ImageView ivClear;
    private TextView tvNoData;
    private RecyclerView rvSearch;
    private SearchItemAdapter mSearchItemAdapter;
    private List<SearchBean.ResultsBean> mSearchBeans = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);
        initView(view);
        return view;
    }

    private void initView(View view) {
        etSearch = view.findViewById(R.id.etSearch);
        ivClear = view.findViewById(R.id.ivClear);
        tvNoData = view.findViewById(R.id.tvNoData);
        rvSearch = view.findViewById(R.id.rvSearch);

        rvSearch.setLayoutManager(new LinearLayoutManager(getActivity()));
        mSearchItemAdapter = new SearchItemAdapter(getActivity());
        rvSearch.setAdapter(mSearchItemAdapter);

        etSearch.addTextChangedListener(extractTextWatcher());
        DataUtils.tool(getActivity());
        ivClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etSearch.setText("");
            }
        });
        etSearch.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if(b){
                    //获得焦点
                    ivClear.setVisibility(View.VISIBLE);
                }else {
                    ivClear.setVisibility(View.GONE);
                }
            }
        });

        mSearchItemAdapter.setOperationClickListener(new SearchItemAdapter.OnOperationClickListener() {
            @Override
            public void OnClick(SearchBean.ResultsBean resultsBean, View view) {
                Intent intent = new Intent(getActivity(), DetailActivity.class);
                intent.putExtra("DetailId",resultsBean.getId()+"");
                intent.putExtra("Type",resultsBean.getMedia_type());
                Log.e("mSearchItemAdapter","DetailId    " +resultsBean.getId() + "   " + "Type   "+ resultsBean.getMedia_type());
                startActivity(intent);
            }
        });
    }

    private TextWatcher extractTextWatcher() {
        TextWatcher watcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                Log.d("修改之前的文字", "afterTextChanged: " + s);
                if (s.toString().equals("")) {
                    mSearchBeans.clear();
                    mSearchItemAdapter.notifyDataSetChanged();
                    mSearchItemAdapter.setResultsBeans(mSearchBeans);
                } else {
                    search(s.toString());
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                Log.d("修改后的文字", "afterTextChanged: " + s);
                if (s.toString().equals("")) {
                    mSearchBeans.clear();
                    mSearchItemAdapter.notifyDataSetChanged();
                    mSearchItemAdapter.setResultsBeans(mSearchBeans);
                } else {
                    search(s.toString());
                }
            }
        };
        return watcher;
    }

    private void search(String toString) {
        OkHttpUtils
                .get()
                .url(ApiConfig.SEARCH_URL + toString + "&page=1&include_adult=false")
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Gson gson = new Gson();
                        SearchBean searchBean = gson.fromJson(response, SearchBean.class);
                        if (searchBean.getResults().size() > 0) {
                            mSearchItemAdapter.setResultsBeans(searchBean.getResults());
                        } else {
                            rvSearch.setVisibility(View.GONE);
                            tvNoData.setVisibility(View.VISIBLE);
                        }


                    }
                });
    }
}
