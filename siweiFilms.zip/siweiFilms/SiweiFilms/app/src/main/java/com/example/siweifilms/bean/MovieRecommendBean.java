package com.example.uscfilms.bean;

import java.util.List;

public class MovieRecommendBean {

    /**
     * page : 1
     * results : [{"poster_path":"/tnAuB8q5vv7Ax9UAEje5Xi4BXik.jpg","adult":false,"backdrop_path":"/pcDc2WJAYGJTTvRSEIpRZwM3Ola.jpg","id":791373,"vote_count":4991,"vote_average":8.5,"title":"Zack Snyder's Justice League","video":false,"release_date":"2021-03-18","genre_ids":[28,12,14,878],"original_language":"en","overview":"Determined to ensure Superman's ultimate sacrifice was not in vain, Bruce Wayne aligns forces with Diana Prince with plans to recruit a team of metahumans to protect the world from an approaching threat of catastrophic proportions.","original_title":"Zack Snyder's Justice League","popularity":3573.498},{"adult":false,"backdrop_path":"/srYya1ZlI97Au4jUYAktDe3avyA.jpg","genre_ids":[14,28,12],"id":464052,"original_language":"en","original_title":"Wonder Woman 1984","overview":"A botched store robbery places Wonder Woman in a global battle against a powerful and mysterious ancient force that puts her powers in jeopardy.","poster_path":"/8UlWHLMpgZm9bx6QYh0NFoq67TZ.jpg","release_date":"2020-12-16","title":"Wonder Woman 1984","video":false,"vote_average":6.8,"vote_count":4876,"popularity":1234.766},{"adult":false,"backdrop_path":"/30BxobPLvzTp3ziDDPDnKLQUzi8.jpg","genre_ids":[878,28],"id":373571,"title":"Godzilla: King of the Monsters","vote_count":4001,"vote_average":6.7,"video":false,"release_date":"2019-05-29","overview":"Follows the heroic efforts of the crypto-zoological agency Monarch as its members face off against a battery of god-sized monsters, including the mighty Godzilla, who collides with Mothra, Rodan, and his ultimate nemesis, the three-headed King Ghidorah. When these ancient super-species, thought to be mere myths, rise again, they all vie for supremacy, leaving humanity's very existence hanging in the balance.","original_title":"Godzilla: King of the Monsters","poster_path":"/pU3bnutJU91u3b4IeRPQTOP8jhV.jpg","original_language":"en","popularity":393.494},{"adult":false,"backdrop_path":"/z8TvnEVRenMSTemxYZwLGqFofgF.jpg","genre_ids":[14,28,12],"id":458576,"title":"Monster Hunter","vote_count":1472,"vote_average":7.1,"video":false,"release_date":"2020-12-03","overview":"A portal transports Cpt. Artemis and an elite unit of soldiers to a strange world where powerful monsters rule with deadly ferocity. Faced with relentless danger, the team encounters a mysterious hunter who may be their only hope to find a way home.","original_title":"Monster Hunter","poster_path":"/1UCOF11QCw8kcqvce8LKOO6pimh.jpg","original_language":"en","popularity":1456.473},{"poster_path":"/9kg73Mg8WJKlB9Y2SAJzeDKAnuB.jpg","adult":false,"backdrop_path":"/5NxjLfs7Bi07bfZCRl9CCnUw7AA.jpg","id":412656,"vote_count":395,"vote_average":7.4,"title":"Chaos Walking","video":false,"release_date":"2021-02-24","genre_ids":[878,28,12,53],"original_language":"en","overview":"Two unlikely companions embark on a perilous adventure through the badlands of an unexplored planet as they try to escape a dangerous and disorienting reality, where all inner thoughts are seen and heard by everyone.","original_title":"Chaos Walking","popularity":2589.774},{"genre_ids":[53,80],"original_language":"en","original_title":"The Little Things","poster_path":"/c7VlGCCgM9GZivKSzBgzuOVxQn7.jpg","video":false,"vote_average":6.4,"vote_count":759,"overview":"Deputy Sheriff Joe \"Deke\" Deacon joins forces with Sgt. Jim Baxter to search for a serial killer who's terrorizing Los Angeles. As they track the culprit, Baxter is unaware that the investigation is dredging up echoes of Deke's past, uncovering disturbing secrets that could threaten more than his case.","id":602269,"title":"The Little Things","release_date":"2021-01-28","adult":false,"backdrop_path":"/vfuzELmhBjBTswXj2Vqxnu5ge4g.jpg","popularity":919.844},{"title":"Raya and the Last Dragon","vote_average":8.3,"overview":"Long ago, in the fantasy world of Kumandra, humans and dragons lived together in harmony. But when an evil force threatened the land, the dragons sacrificed themselves to save humanity. Now, 500 years later, that same evil has returned and it\u2019s up to a lone warrior, Raya, to track down the legendary last dragon to restore the fractured land and its divided people.","release_date":"2021-03-03","adult":false,"backdrop_path":"/7prYzufdIOy1KCTZKVWpjBFqqNr.jpg","vote_count":2325,"genre_ids":[16,12,14,10751,28],"id":527774,"original_language":"en","original_title":"Raya and the Last Dragon","poster_path":"/lPsD10PP4rgUGiGR4CCXA6iY0QQ.jpg","video":false,"popularity":2162.785},{"backdrop_path":"/lrNbt21hRirjyTK0SeLA0L4RAVS.jpg","genre_ids":[28,27,878],"original_language":"en","original_title":"The New Mutants","poster_path":"/xZNw9xxtwbEf25NYoz52KdbXHPM.jpg","video":false,"vote_average":6.3,"vote_count":1822,"overview":"Five young mutants, just discovering their abilities while held in a secret facility against their will, fight to escape their past sins and save themselves.","release_date":"2020-08-26","title":"The New Mutants","id":340102,"adult":false,"popularity":315.327},{"poster_path":"/wKTsXAQvDy6uip7EiCvHUuCSQJX.jpg","adult":false,"backdrop_path":"/iueb8P2aSE2JL21kgoyhnmmeFb5.jpg","id":513310,"vote_count":190,"vote_average":6.9,"title":"Boss Level","video":false,"release_date":"2021-02-19","genre_ids":[28,878,53,9648],"original_language":"en","overview":"A retired special forces officer is trapped in a never-ending time loop on the day of his death.","original_title":"Boss Level","popularity":84.385},{"original_language":"en","original_title":"Love and Monsters","poster_path":"/r4Lm1XKP0VsTgHX4LG4syAwYA2I.jpg","title":"Love and Monsters","video":false,"vote_average":7.5,"overview":"Seven years after the Monsterpocalypse, Joel Dawson, along with the rest of humanity, has been living underground ever since giant creatures took control of the land. After reconnecting over radio with his high school girlfriend Aimee, who is now 80 miles away at a coastal colony, Joel begins to fall for her again. As Joel realizes that there\u2019s nothing left for him underground, he decides against all logic to venture out to Aimee, despite all the dangerous monsters that stand in his way.","release_date":"2020-10-16","vote_count":1253,"adult":false,"backdrop_path":"/lA5fOBqTOQBQ1s9lEYYPmNXoYLi.jpg","id":590223,"genre_ids":[35,878,28,12],"popularity":468.098},{"adult":false,"backdrop_path":"/wzJRB4MKi3yK138bJyuL9nx47y6.jpg","genre_ids":[28,53,878],"id":577922,"original_language":"en","original_title":"Tenet","poster_path":"/k68nPLbIST6NP96JmTxmZijEvCA.jpg","video":false,"title":"Tenet","overview":"Armed with only one word - Tenet - and fighting for the survival of the entire world, the Protagonist journeys through a twilight world of international espionage on a mission that will unfold in something beyond real time.","release_date":"2020-08-22","vote_count":5024,"vote_average":7.3,"popularity":528.331},{"genre_ids":[27,53,35,14],"title":"Freaky","original_language":"en","original_title":"Freaky","poster_path":"/8xC6QSyxrpm0D5A6iyHNemEWBVe.jpg","video":false,"vote_average":6.8,"overview":"A mystical, ancient dagger causes a notorious serial killer to magically switch bodies with a 17-year-old girl.","release_date":"2020-11-12","vote_count":583,"id":551804,"adult":false,"backdrop_path":"/eShw0LB5CkoEfYtpUcXPD85oz5Q.jpg","popularity":77.19},{"poster_path":"/iIgr75GoqFxe1X5Wz9siOODGe9u.jpg","adult":false,"backdrop_path":"/fatz1aegtBGh7KS0gipcsw9MqUn.jpg","id":583406,"vote_count":401,"vote_average":7.5,"title":"Judas and the Black Messiah","video":false,"release_date":"2021-02-12","genre_ids":[18,36],"original_language":"en","overview":"Bill O'Neal infiltrates the Black Panthers on the orders of FBI Agent Mitchell and J. Edgar Hoover. As Black Panther Chairman Fred Hampton ascends\u2014falling for a fellow revolutionary en route\u2014a battle wages for O\u2019Neal\u2019s soul.","original_title":"Judas and the Black Messiah","popularity":105.441},{"vote_average":6.8,"overview":"Prince Akeem Joffer is set to become King of Zamunda when he discovers he has a son he never knew about in America \u2013 a street savvy Queens native named Lavelle. Honoring his royal father's dying wish to groom this son as the crown prince, Akeem and Semmi set off to America once again.","release_date":"2021-03-05","id":484718,"adult":false,"backdrop_path":"/vKzbIoHhk1z9DWYi8kyFe9Gg0HF.jpg","genre_ids":[35],"vote_count":1229,"original_language":"en","original_title":"Coming 2 America","poster_path":"/nWBPLkqNApY5pgrJFMiI9joSI30.jpg","video":false,"title":"Coming 2 America","popularity":573.916},{"adult":false,"backdrop_path":"/fev8UFNFFYsD5q7AcYS8LyTzqwl.jpg","genre_ids":[35,10751,16],"original_language":"en","original_title":"Tom & Jerry","poster_path":"/6KErczPBROQty7QoIsaa6wJYXZi.jpg","video":false,"vote_average":7.3,"id":587807,"overview":"Tom the cat and Jerry the mouse get kicked out of their home and relocate to a fancy New York hotel, where a scrappy employee named Kayla will lose her job if she can\u2019t evict Jerry before a high-class wedding at the hotel. Her solution? Hiring Tom to get rid of the pesky mouse.","release_date":"2021-02-11","vote_count":1211,"title":"Tom & Jerry","popularity":1405.251},{"adult":false,"backdrop_path":"/rWrvcsrvISKXdMOzCdkvU3Jtg0j.jpg","genre_ids":[53,80,18],"id":582014,"original_language":"en","original_title":"Promising Young Woman","poster_path":"/cjzU4g6SlScnP4MdkleyI25KGlR.jpg","video":false,"title":"Promising Young Woman","overview":"A young woman, traumatized by a tragic event in her past, seeks out vengeance against those who crossed her path.","release_date":"2020-12-13","vote_count":724,"vote_average":7.6,"popularity":136.074},{"adult":false,"backdrop_path":"/tweDJNQzBGgsWVF5MC8JhSAk07p.jpg","genre_ids":[53,878,27],"id":570670,"title":"The Invisible Man","vote_count":3676,"vote_average":7.2,"video":false,"release_date":"2020-02-26","overview":"When Cecilia's abusive ex takes his own life and leaves her his fortune, she suspects his death was a hoax. As a series of coincidences turn lethal, Cecilia works to prove that she is being hunted by someone nobody can see.","original_title":"The Invisible Man","poster_path":"/5EufsDwXdY2CVttYOk2WtYhgKpa.jpg","original_language":"en","popularity":51.095},{"poster_path":"/ilHG4EayOVoYeKqslspY3pR4wzC.jpg","adult":false,"backdrop_path":"/DnjwdbjdR2c5MFhKv5ZSRf8rDU.jpg","id":546121,"vote_count":804,"vote_average":7.5,"title":"Run","video":false,"release_date":"2020-11-20","genre_ids":[53,27,18],"original_language":"en","overview":"Chloe, a teenager who is confined to a wheelchair, is homeschooled by her mother, Diane. Chloe soon becomes suspicious of her mother and begins to suspect that she may be harboring a dark secret.","original_title":"Run","popularity":135.317},{"genre_ids":[878,18,27],"original_language":"ru","original_title":"Спутник","poster_path":"/eAUzmhP54bE1vPXaY7FbuZREJlR.jpg","video":false,"vote_average":6.6,"vote_count":269,"overview":"At the height of the Cold War, a Soviet spacecraft crash lands after a mission gone awry, leaving the commander as its only survivor. After a renowned Russian psychologist is brought in to evaluate the commander\u2019s mental state, it becomes clear that something dangerous may have come back to Earth with him\u2026","id":594718,"title":"Sputnik","release_date":"2020-09-08","adult":false,"backdrop_path":"/mBbA77FyzhU0Tz9tmbKG8heGmh3.jpg","popularity":275.509},{"overview":"John Garrity, his estranged wife and their young son embark on a perilous journey to find sanctuary as a planet-killing comet hurtles toward Earth. Amid terrifying accounts of cities getting levelled, the Garrity's experience the best and worst in humanity. As the countdown to the global apocalypse approaches zero, their incredible trek culminates in a desperate and last-minute flight to a possible safe haven.","release_date":"2020-07-29","adult":false,"backdrop_path":"/2Fk3AB8E9dYIBc2ywJkxk8BTyhc.jpg","vote_count":2454,"genre_ids":[28],"vote_average":7.2,"original_language":"en","original_title":"Greenland","poster_path":"/bNo2mcvSwIvnx8K6y1euAc1TLVq.jpg","title":"Greenland","video":false,"id":524047,"popularity":105.888}]
     * total_pages : 2
     * total_results : 40
     */

    private int page;
    private int total_pages;
    private int total_results;
    private List<ResultsBean> results;

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotal_pages() {
        return total_pages;
    }

    public void setTotal_pages(int total_pages) {
        this.total_pages = total_pages;
    }

    public int getTotal_results() {
        return total_results;
    }

    public void setTotal_results(int total_results) {
        this.total_results = total_results;
    }

    public List<ResultsBean> getResults() {
        return results;
    }

    public void setResults(List<ResultsBean> results) {
        this.results = results;
    }

    public static class ResultsBean {
        /**
         * poster_path : /tnAuB8q5vv7Ax9UAEje5Xi4BXik.jpg
         * adult : false
         * backdrop_path : /pcDc2WJAYGJTTvRSEIpRZwM3Ola.jpg
         * id : 791373
         * vote_count : 4991
         * vote_average : 8.5
         * title : Zack Snyder's Justice League
         * video : false
         * release_date : 2021-03-18
         * genre_ids : [28,12,14,878]
         * original_language : en
         * overview : Determined to ensure Superman's ultimate sacrifice was not in vain, Bruce Wayne aligns forces with Diana Prince with plans to recruit a team of metahumans to protect the world from an approaching threat of catastrophic proportions.
         * original_title : Zack Snyder's Justice League
         * popularity : 3573.498
         */

        private String poster_path;
        private boolean adult;
        private String backdrop_path;
        private int id;
        private int vote_count;
        private double vote_average;
        private String title;
        private boolean video;
        private String release_date;
        private String original_language;
        private String overview;
        private String original_title;
        private double popularity;
        private List<Integer> genre_ids;

        public String getPoster_path() {
            return poster_path;
        }

        public void setPoster_path(String poster_path) {
            this.poster_path = poster_path;
        }

        public boolean isAdult() {
            return adult;
        }

        public void setAdult(boolean adult) {
            this.adult = adult;
        }

        public String getBackdrop_path() {
            return backdrop_path;
        }

        public void setBackdrop_path(String backdrop_path) {
            this.backdrop_path = backdrop_path;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getVote_count() {
            return vote_count;
        }

        public void setVote_count(int vote_count) {
            this.vote_count = vote_count;
        }

        public double getVote_average() {
            return vote_average;
        }

        public void setVote_average(double vote_average) {
            this.vote_average = vote_average;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public boolean isVideo() {
            return video;
        }

        public void setVideo(boolean video) {
            this.video = video;
        }

        public String getRelease_date() {
            return release_date;
        }

        public void setRelease_date(String release_date) {
            this.release_date = release_date;
        }

        public String getOriginal_language() {
            return original_language;
        }

        public void setOriginal_language(String original_language) {
            this.original_language = original_language;
        }

        public String getOverview() {
            return overview;
        }

        public void setOverview(String overview) {
            this.overview = overview;
        }

        public String getOriginal_title() {
            return original_title;
        }

        public void setOriginal_title(String original_title) {
            this.original_title = original_title;
        }

        public double getPopularity() {
            return popularity;
        }

        public void setPopularity(double popularity) {
            this.popularity = popularity;
        }

        public List<Integer> getGenre_ids() {
            return genre_ids;
        }

        public void setGenre_ids(List<Integer> genre_ids) {
            this.genre_ids = genre_ids;
        }
    }
}
