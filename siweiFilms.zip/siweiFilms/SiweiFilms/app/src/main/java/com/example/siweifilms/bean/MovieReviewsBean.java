package com.example.uscfilms.bean;

import java.io.Serializable;
import java.util.List;

public class MovieReviewsBean implements Serializable {


    /**
     * id : 399566
     * page : 1
     * results : [{"author":"SWITCH.","author_details":{"name":"SWITCH.","username":"maketheSWITCH","avatar_path":"/klZ9hebmc8biG1RC4WmzNFnciJN.jpg","rating":8},"content":"As pure popcorn entertainment and the culmination of the Monsterverse saga, 'Godzilla vs. Kong' delivers the goods in an unexpectedly big way. This film is essential viewing for those who might like to watch a lizard punch an ape.\r\n- Jake Watt\r\n\r\nRead Jake's full article...\r\nhttps://www.maketheswitch.com.au/article/review-godzilla-vs-kong-hugely-entertaining","created_at":"2021-03-24T22:20:16.047Z","id":"605bbb20988afd003d996bb3","updated_at":"2021-03-24T22:20:16.047Z","url":"https://www.themoviedb.org/review/605bbb20988afd003d996bb3"},{"author":"JPV852","author_details":{"name":"","username":"JPV852","avatar_path":"/xNLOqXXVJf9m7WngUMLIMFsjKgh.jpg","rating":7},"content":"Satisfying through and through. Also they seemed to learn from the past mistakes (with Godzilla and Godzilla: King of the Monsters) of doing too much with the human characters, here they are thankfully just window dressing for the battle between the two titans. **3.75/5**","created_at":"2021-03-31T19:36:54.492Z","id":"6064cf562476f20057ced28c","updated_at":"2021-03-31T19:36:54.492Z","url":"https://www.themoviedb.org/review/6064cf562476f20057ced28c"},{"author":"sykobanana","author_details":{"name":"","username":"sykobanana","avatar_path":"/j2KpvD880J95lqf3ct4u1MmWZhE.jpg","rating":8},"content":"Oh Yeah!  \r\nTHE monster movie of the year is here and just how good is it!  \r\n\r\nIs the plot predictable?  Yep - I'd guessed 80% of it 2 months ago.  \r\nIs it silly?  You bet. \r\n\r\nAre the humans essential? Nah, but we didnt come here for them.\r\nWe came to see Kong and Godzilla slug it out.  And we got that!  \r\n\r\nThe scenes with the Kaiju are well thought out and choreographed (can we say that for digital fights?).  And do they ever deck it out.  \r\nThe devastation you see on the poster gives away how much of Hong Kong gets destroyed (there will be extra land available for building now). \r\n\r\nThe movie is directed and paced well - the first half sets things up for the multiple confrontation between the Kaiju; and the second half lets loose.  \r\n\r\nNone of the actors are given much to do and most seem to sleepwalk through it, but Rebecca Hall is easily the best (she is always a delight to watch), Kyle Chandler channels Coach Taylor for a couple of scenes, Julian Dennison (from Hunt for the Wilderpeople) gets some good lines and Demian Bichir is having fun as the evil rich dude (never trust rich people...in movies or real life). \r\n\r\nThe sound design and score are both on point, but everything here subsides when the Kaiju are around.  The CGI is great - and like Peter Jackson's Kong, you actually feel for the great big monkey.  \r\n\r\nThis movie is some first class popcorn, needing to be enjoyed on the biggest screen you can find.","created_at":"2021-04-01T11:24:13.690Z","id":"6065ad5db84f94006f4b9363","updated_at":"2021-04-01T11:24:13.690Z","url":"https://www.themoviedb.org/review/6065ad5db84f94006f4b9363"}]
     * total_pages : 1
     * total_results : 3
     */

    private int id;
    private int page;
    private int total_pages;
    private int total_results;
    private List<ResultsBean> results;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotal_pages() {
        return total_pages;
    }

    public void setTotal_pages(int total_pages) {
        this.total_pages = total_pages;
    }

    public int getTotal_results() {
        return total_results;
    }

    public void setTotal_results(int total_results) {
        this.total_results = total_results;
    }

    public List<ResultsBean> getResults() {
        return results;
    }

    public void setResults(List<ResultsBean> results) {
        this.results = results;
    }

    public static class ResultsBean implements Serializable{
        /**
         * author : SWITCH.
         * author_details : {"name":"SWITCH.","username":"maketheSWITCH","avatar_path":"/klZ9hebmc8biG1RC4WmzNFnciJN.jpg","rating":8}
         * content : As pure popcorn entertainment and the culmination of the Monsterverse saga, 'Godzilla vs. Kong' delivers the goods in an unexpectedly big way. This film is essential viewing for those who might like to watch a lizard punch an ape.
         - Jake Watt

         Read Jake's full article...
         https://www.maketheswitch.com.au/article/review-godzilla-vs-kong-hugely-entertaining
         * created_at : 2021-03-24T22:20:16.047Z
         * id : 605bbb20988afd003d996bb3
         * updated_at : 2021-03-24T22:20:16.047Z
         * url : https://www.themoviedb.org/review/605bbb20988afd003d996bb3
         */

        private String author;
        private AuthorDetailsBean author_details;
        private String content;
        private String created_at;
        private String id;
        private String updated_at;
        private String url;

        public String getAuthor() {
            return author;
        }

        public void setAuthor(String author) {
            this.author = author;
        }

        public AuthorDetailsBean getAuthor_details() {
            return author_details;
        }

        public void setAuthor_details(AuthorDetailsBean author_details) {
            this.author_details = author_details;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getCreated_at() {
            return created_at;
        }

        public void setCreated_at(String created_at) {
            this.created_at = created_at;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getUpdated_at() {
            return updated_at;
        }

        public void setUpdated_at(String updated_at) {
            this.updated_at = updated_at;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public static class AuthorDetailsBean implements Serializable{
            /**
             * name : SWITCH.
             * username : maketheSWITCH
             * avatar_path : /klZ9hebmc8biG1RC4WmzNFnciJN.jpg
             * rating : 8
             */

            private String name;
            private String username;
            private String avatar_path;
            private double rating;

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getUsername() {
                return username;
            }

            public void setUsername(String username) {
                this.username = username;
            }

            public String getAvatar_path() {
                return avatar_path;
            }

            public void setAvatar_path(String avatar_path) {
                this.avatar_path = avatar_path;
            }

            public double getRating() {
                return rating;
            }

            public void setRating(int rating) {
                this.rating = rating;
            }
        }
    }
}
