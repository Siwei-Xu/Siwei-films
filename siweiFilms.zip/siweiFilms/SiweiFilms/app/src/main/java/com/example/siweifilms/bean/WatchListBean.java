package com.example.uscfilms.bean;

public class WatchListBean {

    private String id;
    private String type;
    private String imgUrl;

    public WatchListBean(String id, String type, String imgUrl) {
        this.id = id;
        this.type = type;
        this.imgUrl = imgUrl;
    }

    public WatchListBean() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }


    @Override
    public String toString() {
        return "WatchListBean{" +
                "id='" + id + '\'' +
                ", type='" + type + '\'' +
                ", imgUrl='" + imgUrl + '\'' +
                '}';
    }
}
