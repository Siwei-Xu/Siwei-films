package com.example.uscfilms.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.uscfilms.MyApplication;
import com.example.uscfilms.R;
import com.example.uscfilms.activity.DetailActivity;
import com.example.uscfilms.adapter.MovieImageNetAdapter;
import com.example.uscfilms.adapter.MoviePoplarAdapter;
import com.example.uscfilms.adapter.MovieTopRateAdapter;
import com.example.uscfilms.adapter.TvImageNetAdapter;
import com.example.uscfilms.adapter.TvPoplarAdapter;
import com.example.uscfilms.adapter.TvTopRateAdapter;
import com.example.uscfilms.bean.MoviePoplarBean;
import com.example.uscfilms.bean.MovieTopRateBean;
import com.example.uscfilms.bean.TvPoplarBean;
import com.example.uscfilms.bean.TvTopRateBean;
import com.example.uscfilms.bean.WatchListBean;
import com.example.uscfilms.dragview.DataUtils;
import com.example.uscfilms.http.ApiConfig;
import com.google.gson.Gson;
import com.youth.banner.Banner;
import com.youth.banner.indicator.CircleIndicator;
import com.youth.banner.util.LogUtils;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.List;

import okhttp3.Call;

public class HomeFragment extends Fragment implements View.OnClickListener {
    Banner banner;
    Gson gson;
    private RecyclerView rvTopRate;
    private RecyclerView rvPopular;
    private MovieTopRateAdapter mMovieTopRateAdapter;
    private MoviePoplarAdapter mMoviePoplarAdapter;
    private TvTopRateAdapter mTvTopRateAdapter;
    private TvPoplarAdapter mTvPoplarAdapter;
    private TextView tvMovie;
    private TextView tvTvShow;
    private TextView tvPoweredBy;
    List<WatchListBean> mFilm;
    private String mType = "Movie";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        initView(view);
        return view;
    }


    private void initView(View view) {
        mFilm = DataUtils.getData(DataUtils.DEFAULT_SP_NAME, getActivity());
        banner = view.findViewById(R.id.banner);
        rvTopRate = view.findViewById(R.id.rvTopRate);
        rvPopular = view.findViewById(R.id.rvPopular);
        tvMovie = view.findViewById(R.id.tvMovie);
        tvTvShow = view.findViewById(R.id.tvTvShow);
        tvPoweredBy = view.findViewById(R.id.tvPoweredBy);
        gson = new Gson();

        LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(getActivity());
        linearLayoutManager1.setOrientation(LinearLayoutManager.HORIZONTAL);

        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(getActivity());
        linearLayoutManager2.setOrientation(LinearLayoutManager.HORIZONTAL);

        rvPopular.setLayoutManager(linearLayoutManager1);
        rvTopRate.setLayoutManager(linearLayoutManager2);

        tvMovie.setOnClickListener(this);
        tvTvShow.setOnClickListener(this);
        tvPoweredBy.setOnClickListener(this);
        tvMovie.setSelected(true);
        showMovieData();
        FragmentActivity activity = getActivity();
        DataUtils.tool(activity);
    }

    private void showMovieData() {
        OkHttpUtils
                .get()
                .url(ApiConfig.MOVIE_POPLAR_URL)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Log.e("response", e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e("response", response);
                        MoviePoplarBean moviePoplarBean = gson.fromJson(response, MoviePoplarBean.class);
                        List<MoviePoplarBean.ResultsBean> resultsBeans = moviePoplarBean.getResults().subList(0, 6);
                        MovieImageNetAdapter adapter = new MovieImageNetAdapter(resultsBeans, MyApplication.getApplication());
                        banner.setAdapter(adapter)
                                .addBannerLifecycleObserver(getActivity())//添加生命周期观察者
                                .setIndicator(new CircleIndicator(getActivity()))//设置指示器
                                .setOnBannerListener((data, position) -> {
                                    Intent intent = new Intent(getActivity(), DetailActivity.class);
                                    intent.putExtra("DetailId", resultsBeans.get(position).getId() + "");
                                    intent.putExtra("Type", mType);
                                    startActivity(intent);
                                });

                        mMoviePoplarAdapter = new MoviePoplarAdapter(moviePoplarBean.getResults().subList(0, 10), getActivity());
                        rvPopular.setAdapter(mMoviePoplarAdapter);

                        mMoviePoplarAdapter.setOperationClickListener(new MoviePoplarAdapter.OnOperationClickListener() {
                            @Override
                            public void OnClick(MoviePoplarBean.ResultsBean resultsBean, View view1) {
                                boolean isExits = false;
                                int index = -1;
                                for (int i = 0; i < mFilm.size(); i++) {
                                    Log.e("对比", "Film.get(i).getId() " + mFilm.get(i).getId() + "  resultsBean.getId() " + resultsBean.getId() + "  " + mFilm.get(i).getId().equals(resultsBean.getId() + ""));
                                    if (mFilm.get(i).getId().equals(resultsBean.getId() + "")) {
                                        isExits = true;
                                        index = i;
                                    }
                                }
                                showPopupMenu(resultsBean.getOriginal_title(), resultsBean.getId() + "", resultsBean.getPoster_path(), view1, isExits, index);
                            }

                            @Override
                            public void OnDetailClick(MoviePoplarBean.ResultsBean resultsBean, View view) {
                                Intent intent = new Intent(getActivity(), DetailActivity.class);
                                intent.putExtra("DetailId", resultsBean.getId() + "");
                                intent.putExtra("Type", mType);
                                startActivity(intent);
                            }
                        });
                    }
                });

        OkHttpUtils
                .get()
                .url(ApiConfig.MOVIE_TOP_RATED_URL)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Log.e("response", e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e("MOVIE_TOP_RATED_URL", response);
                        MovieTopRateBean movieTopRateBean = gson.fromJson(response, MovieTopRateBean.class);
                        mMovieTopRateAdapter = new MovieTopRateAdapter(movieTopRateBean.getResults().subList(0, 10), getActivity());
                        rvTopRate.setAdapter(mMovieTopRateAdapter);

                        mMovieTopRateAdapter.setOperationClickListener(new MovieTopRateAdapter.OnOperationClickListener() {
                            @Override
                            public void OnDetailClick(MovieTopRateBean.ResultsBean resultsBean, View view) {
                                Intent intent = new Intent(getActivity(), DetailActivity.class);
                                intent.putExtra("DetailId", resultsBean.getId() + "");
                                intent.putExtra("Type", mType);
                                startActivity(intent);
                            }

                            @Override
                            public void OnClick(MovieTopRateBean.ResultsBean resultsBean, View view1) {
                                boolean isExits = false;
                                int index = -1;
                                for (int i = 0; i < mFilm.size(); i++) {
                                    if (mFilm.get(i).getId().equals(resultsBean.getId() + "")) {
                                        isExits = true;
                                        index = i;
                                    }
                                }
                                showPopupMenu(resultsBean.getOriginal_title(), resultsBean.getId() + "", resultsBean.getPoster_path(), view1, isExits, index);
                            }
                        });

                    }
                });

    }


    private void showTvData() {
        OkHttpUtils
                .get()
                .url(ApiConfig.TV_POPLAR_URL)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Log.e("response", e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e("response", response);
                        TvPoplarBean tvPoplarBean = gson.fromJson(response, TvPoplarBean.class);
                        List<TvPoplarBean.ResultsBean> resultsBeans = tvPoplarBean.getResults().subList(0, 6);
                        TvImageNetAdapter adapter = new TvImageNetAdapter(resultsBeans, MyApplication.getApplication());
                        banner.setAdapter(adapter)
                                .addBannerLifecycleObserver(getActivity())//添加生命周期观察者
                                .setIndicator(new CircleIndicator(getActivity()))//设置指示器
                                .setOnBannerListener((data, position) -> {
                                    Intent intent = new Intent(getActivity(), DetailActivity.class);
                                    intent.putExtra("DetailId", resultsBeans.get(position).getId() + "");
                                    intent.putExtra("Type", mType);
                                    startActivity(intent);
                                });

                        mTvPoplarAdapter = new TvPoplarAdapter(tvPoplarBean.getResults(), MyApplication.getApplication());
                        rvPopular.setAdapter(mTvPoplarAdapter);

                        mTvPoplarAdapter.setOperationClickListener(new TvPoplarAdapter.OnOperationClickListener() {
                            @Override
                            public void OnDetailClick(TvPoplarBean.ResultsBean resultsBean, View view) {
                                Intent intent = new Intent(getActivity(), DetailActivity.class);
                                intent.putExtra("DetailId", resultsBean.getId() + "");
                                intent.putExtra("Type", mType);
                                startActivity(intent);
                            }

                            @Override
                            public void OnClick(TvPoplarBean.ResultsBean resultsBean, View view) {
                                boolean isExits = false;
                                int index = -1;
                                for (int i = 0; i < mFilm.size(); i++) {
                                    if (mFilm.get(i).getId().equals(resultsBean.getId() + "")) {
                                        isExits = true;
                                        index = i;
                                    }
                                }
                                showPopupMenu(resultsBean.getOriginal_name(), resultsBean.getId() + "", resultsBean.getPoster_path(), view, isExits, index);
                            }
                        });
                    }
                });

        OkHttpUtils
                .get()
                .url(ApiConfig.TV_TOP_RATED_URL)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Log.e("response", e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e("TV_TOP_RATED_URL", response);
                        TvTopRateBean tvTopRateBean = gson.fromJson(response, TvTopRateBean.class);
                        mTvTopRateAdapter = new TvTopRateAdapter(tvTopRateBean.getResults().subList(0, 10), MyApplication.getApplication());
                        rvTopRate.setAdapter(mTvTopRateAdapter);

                        mTvTopRateAdapter.setOperationClickListener(new TvTopRateAdapter.OnOperationClickListener() {
                            @Override
                            public void OnClick(TvTopRateBean.ResultsBean resultsBean, View view) {
                                boolean isExits = false;
                                int index = -1;
                                for (int i = 0; i < mFilm.size(); i++) {
                                    if (mFilm.get(i).getId().equals(resultsBean.getId() + "")) {
                                        isExits = true;
                                        index = i;
                                    }
                                }
                                showPopupMenu(resultsBean.getOriginal_name(), resultsBean.getId() + "", resultsBean.getPoster_path(), view, isExits, index);
                            }

                            @Override
                            public void OnDetailClick(TvTopRateBean.ResultsBean resultsBean, View view) {
                                Intent intent = new Intent(getActivity(), DetailActivity.class);
                                intent.putExtra("DetailId", resultsBean.getId() + "");
                                intent.putExtra("Type", mType);
                                startActivity(intent);
                            }
                        });

                    }
                });

    }

    private void showPopupMenu(String filmName, String id, String posterPath, View view, boolean isExits, int index) {
        // View当前PopupMenu显示的相对View的位置
        PopupMenu popupMenu = new PopupMenu(getActivity(), view);
        Log.e("isExits", isExits + " " + index);
        // menu布局
        if (isExits) {
            popupMenu.getMenuInflater().inflate(R.menu.menu_home2, popupMenu.getMenu());
        } else {
            popupMenu.getMenuInflater().inflate(R.menu.menu_home1, popupMenu.getMenu());
        }
        // menu的item点击事件
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.option_open_tmdb:
                        String url = "";
                        if (mType.equals("Movie")) {
                            url = "https://www.themoviedb.org/movie/" + id;
                        } else if (mType.equals("Tv")) {
                            url = "https://www.themoviedb.org/tv/" + id;
                        }
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(url));
                        startActivity(i);
                        break;
                    case R.id.option_share_FaceBook:
                        url = ApiConfig.FACEBOOK_SHARE+mType.toLowerCase()+"/"+id;
                        i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(url));
                        startActivity(i);
                        break;
                    case R.id.option_share_twitter:
                        url = ApiConfig.TWITTER_SHARE+mType.toLowerCase()+"/"+id;
                        i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(url));
                        startActivity(i);
                        break;
                    case R.id.option_add_watchlist:
                        mFilm.add(new WatchListBean(id, mType, posterPath));
                        DataUtils.saveData(mFilm, DataUtils.DEFAULT_SP_NAME, getActivity());
                        Toast.makeText(getActivity(), filmName + " was added to Collection", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.option_remove_watchlist:
                        mFilm.remove(index);
                        DataUtils.saveData(mFilm, DataUtils.DEFAULT_SP_NAME, getActivity());
                        Toast.makeText(getActivity(), filmName + " was removed from Collection", Toast.LENGTH_SHORT).show();
                        break;
                }
                return false;
            }
        });
        popupMenu.show();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvMovie:
                mType = "Movie";
                tvMovie.setSelected(true);
                tvTvShow.setSelected(false);
                showMovieData();
                break;
            case R.id.tvTvShow:
                mType = "Tv";
                tvMovie.setSelected(false);
                tvTvShow.setSelected(true);
                showTvData();
                break;
            case R.id.tvPoweredBy:
                String url = "https://www.themoviedb.org/";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
                break;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        mType = "Movie";

    }

    @Override
    public void onPause() {
        super.onPause();
    }
}
