package com.example.uscfilms.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTabHost;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TextView;

import com.example.uscfilms.R;
import com.example.uscfilms.bean.Person;
import com.example.uscfilms.bean.Tab;
import com.example.uscfilms.dragview.DataUtils;
import com.example.uscfilms.fragment.HomeFragment;
import com.example.uscfilms.fragment.SearchFragment;
import com.example.uscfilms.fragment.WatchlistFragment;

import java.util.ArrayList;
import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.QueryListener;

public class MainActivity extends AppCompatActivity {
    private LayoutInflater mInflater;
    private FragmentTabHost mTabhost;
    private List<Tab> mTabs = new ArrayList<>(2);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initTab();
    }

    private void initTab() {
        Tab tab_home = new Tab(HomeFragment.class, R.string.string_home, R.drawable.ic_home_selector);
        Tab tab_search = new Tab(SearchFragment.class, R.string.string_search, R.drawable.ic_search_selector);
        Tab tab_watchlist = new Tab(WatchlistFragment.class, R.string.string_watchlist, R.drawable.ic_watch_later_selector);


        mTabs.add(tab_home);
        mTabs.add(tab_search);
        mTabs.add(tab_watchlist);

        mInflater = LayoutInflater.from(this);
        mTabhost = (FragmentTabHost) this.findViewById(android.R.id.tabhost);
        mTabhost.setup(this, getSupportFragmentManager(), R.id.realtabcontent);
        for (Tab tab : mTabs) {
            TabHost.TabSpec tabSpec = mTabhost.newTabSpec(getString(tab.getTitle()));
            tabSpec.setIndicator(buildIndicator(tab));
            mTabhost.addTab(tabSpec, tab.getFragment(), null);
        }
        //去掉分隔线
        mTabhost.getTabWidget().setShowDividers(LinearLayout.SHOW_DIVIDER_NONE);
        mTabhost.setCurrentTab(0);

    }

        private View buildIndicator(Tab tab) {
            View view = mInflater.inflate(R.layout.tab_indicator, null);
            TextView text = (TextView) view.findViewById(R.id.txt_indicator);
            ImageView imageView = (ImageView) view.findViewById(R.id.iv_indicator);
            imageView.setBackground(getResources().getDrawable(tab.getImage()));
        text.setText(tab.getTitle());

        return view;
    }
}
