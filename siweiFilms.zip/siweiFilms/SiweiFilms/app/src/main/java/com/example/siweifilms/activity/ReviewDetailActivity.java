package com.example.uscfilms.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.uscfilms.R;
import com.example.uscfilms.bean.MovieReviewsBean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ReviewDetailActivity extends Activity {

    private TextView tvRating;
    private TextView tvUsernameDate;
    private TextView tvContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_detail);
        initView();
    }

    private void initView() {
        tvRating = (TextView) findViewById(R.id.tvRating);
        tvUsernameDate = (TextView) findViewById(R.id.tvUsernameDate);
        tvContent = (TextView) findViewById(R.id.tvContent);

        Intent intent = getIntent();
        MovieReviewsBean.ResultsBean review = (MovieReviewsBean.ResultsBean) intent.getSerializableExtra("review");
        String username = review.getAuthor_details().getUsername();
        int rating = (int) review.getAuthor_details().getRating();
        String content = review.getContent();
        String created_at = review.getCreated_at();
        String substring = created_at.substring(0, 10);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        Date time = null;
        try {
            time = format.parse(substring);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        String[] split = time.toString().split("\\s+");
//        tvUsernameDate.setText("by " + username + " on " + time.toString().substring(0, 3) + "," + time.toString().substring(4, 10) + " " + time.toString().substring(30, 34));
        tvUsernameDate.setText("by " + username + " on " + split[0] + "," + split[1] + " " +  split[2] + " " + split[5]);
        tvContent.setText(content);
        tvRating.setText((rating / 2) + "/5");

    }
}
