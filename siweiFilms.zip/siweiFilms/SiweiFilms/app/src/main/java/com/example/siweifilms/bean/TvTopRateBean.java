package com.example.uscfilms.bean;

import java.io.Serializable;
import java.util.List;

public class TvTopRateBean implements Serializable {


    /**
     * page : 1
     * results : [{"backdrop_path":null,"first_air_date":"2004-05-10","genre_ids":[16,35],"id":100,"name":"I Am Not an Animal","origin_country":["GB"],"original_language":"en","original_name":"I Am Not an Animal","overview":"I Am Not An Animal is an animated comedy series about the only six talking animals in the world, whose cosseted existence in a vivisection unit is turned upside down when they are liberated by animal rights activists.","popularity":10.972,"poster_path":"/qG59J1Q7rpBc1dvku4azbzcqo8h.jpg","vote_average":9.4,"vote_count":611},{"backdrop_path":"/7gbmM2NWcqZONbp65HUWDf4wr0Q.jpg","first_air_date":"2019-07-12","genre_ids":[16,18],"id":88040,"name":"Given","origin_country":["JP"],"original_language":"ja","original_name":"ギヴン","overview":"Tightly clutching his Gibson guitar, Mafuyu Satou steps out of his dark apartment to begin another day of his high school life. While taking a nap in a quiet spot on the gymnasium staircase, he has a chance encounter with fellow student Ritsuka Uenoyama, who berates him for letting his guitar's strings rust and break. Noticing Uenoyama's knowledge of the instrument, Satou pleads for him to fix it and to teach him how to play. Uenoyama eventually agrees and invites him to sit in on a jam session with his two band mates: bassist Haruki Nakayama and drummer Akihiko Kaji.","popularity":26.67,"poster_path":"/pdDCcAq8RNSZNk81PXYoHNUPHjn.jpg","vote_average":9.2,"vote_count":434},{"backdrop_path":"/uAjMQlbPkVHmUahhCouANlHSDW2.jpg","first_air_date":"2019-01-11","genre_ids":[16,9648,10765,10759,18],"id":83097,"name":"The Promised Neverland","origin_country":["JP"],"original_language":"ja","original_name":"約束のネバーランド","overview":"Surrounded by a forest and a gated entrance, the Grace Field House is inhabited by orphans happily living together as one big family, looked after by their \"Mama,\" Isabella. Although they are required to take tests daily, the children are free to spend their time as they see fit, usually playing outside, as long as they do not venture too far from the orphanage \u2014 a rule they are expected to follow no matter what. However, all good times must come to an end, as every few months, a child is adopted and sent to live with their new family... never to be heard from again.\n\nHowever, the three oldest siblings have their suspicions about what is actually happening at the orphanage, and they are about to discover the cruel fate that awaits the children living at Grace Field, including the twisted nature of their beloved Mama.","popularity":100.191,"poster_path":"/oBgRCpAbtMpk1v8wfdsIph7lPQE.jpg","vote_average":9.1,"vote_count":596},{"backdrop_path":"/qSgBzXdu6QwVVeqOYOlHolkLRxZ.jpg","first_air_date":"2019-01-09","genre_ids":[16,10759,10765,18],"id":83095,"name":"The Rising of the Shield Hero","origin_country":["JP"],"original_language":"ja","original_name":"盾の勇者の成り上がり","overview":"Iwatani Naofumi was summoned into a parallel world along with 3 other people to become the world's Heroes. Each of the heroes respectively equipped with their own legendary equipment when summoned, Naofumi received the Legendary Shield as his weapon. Due to Naofumi's lack of charisma and experience he's labeled as the weakest, only to end up betrayed, falsely accused, and robbed by on the third day of adventure. Shunned by everyone from the king to peasants, Naofumi's thoughts were filled with nothing but vengeance and hatred. Thus, his destiny in a parallel World begins...","popularity":23.432,"poster_path":"/6cXf5EDwVhsRv8GlBzUTVnWuk8Z.jpg","vote_average":9.1,"vote_count":495},{"backdrop_path":"/3qQFa8n5sFmrxMhcjUnKdg2CCOU.jpg","first_air_date":"2014-10-10","genre_ids":[16,35,18],"id":61663,"name":"Your Lie in April","origin_country":["JP"],"original_language":"ja","original_name":"四月は君の嘘","overview":"Kousei Arima was a genius pianist until his mother's sudden death took away his ability to play. Each day was dull for Kousei. But, then he meets a violinist named Kaori Miyazono who has an eccentric playing style. Can the heartfelt sounds of the girl's violin lead the boy to play the piano again?","popularity":41.891,"poster_path":"/nksFLYTydth9OYVpMuMbtOBkvMO.jpg","vote_average":9,"vote_count":441},{"backdrop_path":"/ci7jTekDFEx6U48XUCl3vBMdrns.jpg","first_air_date":"2018-07-06","genre_ids":[10759,18,9648,16],"id":80564,"name":"Banana Fish","origin_country":["JP"],"original_language":"ja","original_name":"BANANA FISH","overview":"Nature made Ash Lynx beautiful; nurture made him a cold ruthless killer. A runaway brought up as the adopted heir and sex toy of \"Papa\" Dino Golzine, Ash, now at the rebellious age of seventeen, forsakes the kingdom held out by the devil who raised him. But the hideous secret that drove Ash's older brother mad in Vietnam has suddenly fallen into Papa's insatiably ambitious hands\u2014and it's exactly the wrong time for Eiji Okamura, a pure-hearted young photographer from Japan, to make Ash Lynx's acquaintance...","popularity":43.592,"poster_path":"/1UV5di9UIXwrpCW3xQ4RNli5hEV.jpg","vote_average":9,"vote_count":451},{"backdrop_path":"/lHcScx9Qpj6OkTmnzPRGIRhn3FR.jpg","first_air_date":"2019-10-03","genre_ids":[16,35,18],"id":93019,"name":"ORESUKI: Are you the only one who loves me?","origin_country":["JP"],"original_language":"ja","original_name":"俺を好きなのはお前だけかよ","overview":"Kisaragi Amatsuyu is invited out alone by the cool beauty upperclassman Cosmos and his childhood friend Himawari. Expecting to hear their confessions, he triumphantly goes to meet each of them in turn. But Cosmos and Himawari both instead confess to Amatsuyu that they like his friend. Amatsuyu fights this lonely battle, but there is another girl who is looking at him. She is a gloomy girl with glasses and braids. Amatsuyu finds that he hates her, because she's always turning her sharp tongue only on him and finding enjoyment in his troubles. But it turns out that she's the only one who actually does like him.","popularity":30.411,"poster_path":"/4MojZik5N62IShd2BFVEHyaRBLP.jpg","vote_average":9,"vote_count":179},{"backdrop_path":"/ftpjln5qa8xAqnDGamIHtYweRHY.jpg","first_air_date":"2020-07-11","genre_ids":[35,16],"id":96316,"name":"Rent-a-Girlfriend","origin_country":["JP"],"original_language":"ja","original_name":"彼女、お借りします","overview":"In today\u2019s Japan, \"rental\" services can deliver an afternoon with a \"friend,\" a \"parent,\" even a fake girlfriend! Kinoshita Kazuya is a 20-year-old failure of a college student. He managed to kiss his girlfriend once, but was dumped after a month.  Completely spiteful, Kazuya gets just desperate enough to give it a try. But he quickly discovers how complicated it can be to \"rent\" an emotional connection\u2026 and his new \"girlfriend,\" Mizuhara Chizuru, who\u2019s trying to keep her side hustle secret, will panic when she finds out her real life and Kazuya\u2019s are intertwined in surprising ways! A reckless rom-com filled with love and excitement is about to begin!","popularity":98.972,"poster_path":"/4rqyyM0R3a0EeSlEvdpxDKbjiKB.jpg","vote_average":9,"vote_count":483},{"backdrop_path":"/4sSzTvk200BQyYjRJq69mLwE9xG.jpg","first_air_date":"2018-04-25","genre_ids":[16,35,18,10759],"id":79141,"name":"Scissor Seven","origin_country":["CN"],"original_language":"zh","original_name":"刺客伍六七","overview":"Seeking to recover his memory, a scissor-wielding, hairdressing, bungling quasi-assassin stumbles into a struggle for power among feuding factions.","popularity":37.248,"poster_path":"/A39DWUIrf9WDRHCg7QTR8seWUvi.jpg","vote_average":9,"vote_count":110},{"backdrop_path":"/e30T3teKp6VZlIXhI0AhTDksvoy.jpg","first_air_date":"2021-01-13","genre_ids":[16,10759,10765],"id":99071,"name":"Redo of Healer","origin_country":["JP"],"original_language":"ja","original_name":"回復術士のやり直し","overview":"In a world of monsters, adventurers and magic, some of the most gifted healers are subjugated to brute force. Keyaru gains the ability to rewind time and turns the tables on those who\u2019ve exploited him in this dark fantasy tale of vengeance and fury.","popularity":94.329,"poster_path":"/hynFI7MltF1BBvroh3iJplnBZyc.jpg","vote_average":9,"vote_count":300},{"backdrop_path":"/bPySXNfMaBhjwSlCaqQxIcDUqOm.jpg","first_air_date":"2019-04-05","genre_ids":[99],"id":83880,"name":"Our Planet","origin_country":["GB"],"original_language":"en","original_name":"Our Planet","overview":"Experience our planet's natural beauty and examine how climate change impacts all living creatures in this ambitious documentary of spectacular scope.","popularity":13.517,"poster_path":"/wRSnArnQBmeUYb5GWDU595bGsBr.jpg","vote_average":9,"vote_count":108},{"backdrop_path":"/rXXC22YUo31QfOsavy0jUbqdxFc.jpg","first_air_date":"2014-12-09","genre_ids":[10765,10759,16],"id":73055,"name":"Attack on Titan: No Regrets","origin_country":["JP"],"original_language":"ja","original_name":"進撃の巨人 悔いなき選択","overview":"Many years before becoming the famed captain of the Survey Corps, a young Levi struggles to survive in the capital's garbage dump, the Underground. As the boss of his own criminal operation, Levi attempts to get by with meager earnings while aided by fellow criminals, Isabel Magnolia and Farlan Church. With little hope for the future, Levi accepts a deal from the anti-expedition faction leader Nicholas Lobov, who promises the trio citizenship aboveground if they are able to successfully assassinate Erwin Smith, a squad leader of the Survey Corps.\n\nAs Levi and Erwin cross paths, Erwin acknowledges Levi's agility and skill and gives him the option to either become part of the expedition team, or be turned over to the Military Police, to atone for his crimes. Now closer to the man they are tasked to kill, the group plans to complete their mission and save themselves from a grim demise in the dim recesses of their past home. However, they are about to learn that the surface world is not as liberating as they had thought and that sometimes, freedom can come at a heavy price.\n\nBased on the popular spin-off manga of the same name, Attack on Titan: No Regrets illustrates the encounter between two of Attack on Titan's pivotal characters, as well as the events of the 23rd expedition beyond the walls.","popularity":104.58,"poster_path":"/xGdz67d5WHIU7kIqVHO2TxIpmhZ.jpg","vote_average":8.9,"vote_count":1223},{"backdrop_path":"/2f8OLO6UYp78dIQMs0oi7ja15Bl.jpg","first_air_date":"2010-04-02","genre_ids":[16,35,18],"id":65648,"name":"Maid Sama!","origin_country":["JP"],"original_language":"ja","original_name":"会長はメイド様！","overview":"Misaki Ayuzawa is the first female student council president at a once all-boys school turned co-ed. She rules the school with strict discipline demeanor. But she has a secret\u2014she works at a maid cafe due to her families circumstances. One day the popular A-student and notorious heart breaker Takumi Usui finds out her secret and makes a deal with her to keep it hush from the school in exchange for spending some time with him.","popularity":24.291,"poster_path":"/igkn0M1bgMeATz59LShvVxZNdVd.jpg","vote_average":8.9,"vote_count":350},{"backdrop_path":"/6tbyZtMYtiNzBy200VXku8jO9ws.jpg","first_air_date":"2019-04-07","genre_ids":[16,35],"id":87432,"name":"We Never Learn: BOKUBEN","origin_country":["JP"],"original_language":"ja","original_name":"ぼくたちは勉強ができない","overview":"Nariyuki Yuiga is in his last and most painful year of high school. In order to gain the \u201cspecial VIP recommendation\u201d which would grant him a full scholarship to college, he must now tutor his classmates as they struggle to prepare for entrance exams.\n\nAmong his pupils are \u201cthe sleeping beauty of the literary forest,\u201d Fumino Furuhashi, and \u201cthe Thumbelina supercomputer,\u201d Rizu Ogata\u2013two of the most beautiful super-geniuses at the school! While these two were thought to be academically flawless, it turns out that they\u2019re completely clueless outside of their pet subjects\u2026!?\n\nAs Nariyuki\u2019s life is turned upside down by these quirky girls who just never learn, he must do everything he can to get them accepted into college! The stage is set for this romantic comedy featuring prodigies who never learn when it comes to studying and love!","popularity":28.083,"poster_path":"/fG3VClLXTvE6MpR0x8fv2q4cpGD.jpg","vote_average":8.9,"vote_count":161},{"backdrop_path":"/dwEkNoGFZJWqiwJrnzVfmtmVhfU.jpg","first_air_date":"2019-01-11","genre_ids":[16,35,18],"id":84669,"name":"The Quintessential Quintuplets","origin_country":["JP"],"original_language":"ja","original_name":"五等分の花嫁","overview":"Fuutarou Uesugi is a poor, antisocial ace student who one day meets the rich transfer student Itsuki Nakano. They argue but when Uesugi realizes he is to be her tutor, he tries to get on better terms. While trying to do so he meets four other girls.","popularity":90.19,"poster_path":"/mrahUSmFjae8UHtlOcZ58ytmAGu.jpg","vote_average":8.9,"vote_count":337},{"backdrop_path":"/uzp513qTcHsAavlCJ58x5d73bzy.jpg","first_air_date":"2017-07-07","genre_ids":[16,18,10759,10765],"id":72636,"name":"Made In Abyss","origin_country":["JP"],"original_language":"ja","original_name":"メイドインアビス","overview":"Located in the center of a remote island, the Abyss is the last unexplored region, a huge and treacherous fathomless hole inhabited by strange creatures where only the bravest adventurers descend in search of ancient relics. In the upper levels of the Abyss, Riko, a girl who dreams of becoming an explorer, stumbles upon a mysterious little boy.","popularity":38.491,"poster_path":"/5ICCEOKdqHFGp03zNMZmi95q9WB.jpg","vote_average":8.9,"vote_count":188},{"backdrop_path":"/sWghoJDqMRHDnkmk7fr3By5XPnf.jpg","first_air_date":"2019-10-05","genre_ids":[16,35,10765],"id":91801,"name":"Welcome to Demon School! Iruma-kun","origin_country":["JP"],"original_language":"ja","original_name":"魔入りました！入間くん","overview":"Fourteen-year-old Suzuki Iruma has just been abandoned and sold to a demon by his irresponsible parents! Surprisingly, the next thing he knows he's living with the demon who has adopted him as his new grandson, and has been transferred into a school in the demon world where his new \"demon\" grandfather works as the principal. Thus begins the cowardly Iruma-kun's extraordinary school life among the otherworldly as he faces his true self, takes on challenges, and rises to become someone great.","popularity":108.849,"poster_path":"/aed6I1EMR4Lbk8bdikWrndbn5Og.jpg","vote_average":8.9,"vote_count":112},{"backdrop_path":"/vP6jiaPmzgHF5YyvrkK44PJGmyR.jpg","first_air_date":"2020-12-12","genre_ids":[18,35,10765],"id":108261,"name":"Mr. Queen","origin_country":["KR"],"original_language":"ko","original_name":"철인왕후","overview":"In the present day, Jang Bong Hwan works as a chef at the President's Blue House. She has a free spirit, but her spirit somehow finds its way into the body of Queen Kim So Yong in the Joseon period.\n\nKing Cheol Jong has secrets. He seems like a figurehead, who is gentle and easygoing. In fact, he hides his strong aspects. Queen Sunwon is the late King Sunjo\u2019s wife. She wields the true power in the country and, thus, relegates King Cheol Jong as just a figurehead. Kim Jwa Geun is Queen Sunwon\u2019s younger brother. He is extremely ambitious.","popularity":76.136,"poster_path":"/ozuyMnOO5pekDklyPpUL1Htkuzy.jpg","vote_average":8.9,"vote_count":121},{"backdrop_path":"/mWwWhDiQWONiSS4Go12TTjNw0E5.jpg","first_air_date":"2016-10-06","genre_ids":[16,35,18],"id":68129,"name":"Yuri!!! on Ice","origin_country":["JP"],"original_language":"ja","original_name":"ユーリ!!! on ICE","overview":"Yūri Katsuki carried all of Japan's hopes on his shoulders to win at the Gran Prix Finale ice skating competition, but suffered a crushing defeat. He returns home to Kyushu and half feels like he wants to retire, and half feels like he wants to continue ice skating. Suddenly the five-time consecutive world championship ice skater Victor Nikiforov appears before him with Yuri Plisetsky, a young Russian figure skater who is already defeating his seniors. Victor and both Yuris take up the challenge on an unprecedented Gran Prix series.","popularity":40.335,"poster_path":"/oKVFf2uNCLMsovWBxAW14MmhHUm.jpg","vote_average":8.9,"vote_count":375},{"backdrop_path":"/qCPusV7wkA2PkwSeFNYgIgda5yc.jpg","first_air_date":"2020-01-07","genre_ids":[16,35],"id":96150,"name":"Seton Academy: Join the Pack!","origin_country":["JP"],"original_language":"ja","original_name":"群れなせ！シートン学園","overview":"Seton Academy, a school full of animals where, thanks to population decline, there are fewer humans than any other creature. Mazama Jin, an animal hater and the only human male in his class, falls in love with Hino Hitomi, the only female human, the moment he lays eyes her. However he soon finds himself entangled with various other creatures after he reluctantly joins the 'pack' of Lanka the wolf, the only other member of her pack. After getting to know each other, the two decide to create a cooking club, and after a few bad-blooded misunderstandings, Ranka soon joins the club as well.\n\nThus begins the howl-some and howl-arious story of two normal humans; an adorable wolf; a cheerful koala; a sluggish, blonde sloth; and a feline with cattitude in their newfound club\u2014in a story that teaches that friendship can be forged by creatures of different kinds.","popularity":26.965,"poster_path":"/yXSH5BYOhYt26S5x7Aqz2VXj6P1.jpg","vote_average":8.9,"vote_count":180}]
     * total_pages : 89
     * total_results : 1771
     */

    private int page;
    private int total_pages;
    private int total_results;
    private List<ResultsBean> results;

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotal_pages() {
        return total_pages;
    }

    public void setTotal_pages(int total_pages) {
        this.total_pages = total_pages;
    }

    public int getTotal_results() {
        return total_results;
    }

    public void setTotal_results(int total_results) {
        this.total_results = total_results;
    }

    public List<ResultsBean> getResults() {
        return results;
    }

    public void setResults(List<ResultsBean> results) {
        this.results = results;
    }

    public static class ResultsBean {
        /**
         * backdrop_path : null
         * first_air_date : 2004-05-10
         * genre_ids : [16,35]
         * id : 100
         * name : I Am Not an Animal
         * origin_country : ["GB"]
         * original_language : en
         * original_name : I Am Not an Animal
         * overview : I Am Not An Animal is an animated comedy series about the only six talking animals in the world, whose cosseted existence in a vivisection unit is turned upside down when they are liberated by animal rights activists.
         * popularity : 10.972
         * poster_path : /qG59J1Q7rpBc1dvku4azbzcqo8h.jpg
         * vote_average : 9.4
         * vote_count : 611
         */

        private Object backdrop_path;
        private String first_air_date;
        private int id;
        private String name;
        private String original_language;
        private String original_name;
        private String overview;
        private double popularity;
        private String poster_path;
        private double vote_average;
        private int vote_count;
        private List<Integer> genre_ids;
        private List<String> origin_country;

        public Object getBackdrop_path() {
            return backdrop_path;
        }

        public void setBackdrop_path(Object backdrop_path) {
            this.backdrop_path = backdrop_path;
        }

        public String getFirst_air_date() {
            return first_air_date;
        }

        public void setFirst_air_date(String first_air_date) {
            this.first_air_date = first_air_date;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getOriginal_language() {
            return original_language;
        }

        public void setOriginal_language(String original_language) {
            this.original_language = original_language;
        }

        public String getOriginal_name() {
            return original_name;
        }

        public void setOriginal_name(String original_name) {
            this.original_name = original_name;
        }

        public String getOverview() {
            return overview;
        }

        public void setOverview(String overview) {
            this.overview = overview;
        }

        public double getPopularity() {
            return popularity;
        }

        public void setPopularity(double popularity) {
            this.popularity = popularity;
        }

        public String getPoster_path() {
            return poster_path;
        }

        public void setPoster_path(String poster_path) {
            this.poster_path = poster_path;
        }

        public double getVote_average() {
            return vote_average;
        }

        public void setVote_average(double vote_average) {
            this.vote_average = vote_average;
        }

        public int getVote_count() {
            return vote_count;
        }

        public void setVote_count(int vote_count) {
            this.vote_count = vote_count;
        }

        public List<Integer> getGenre_ids() {
            return genre_ids;
        }

        public void setGenre_ids(List<Integer> genre_ids) {
            this.genre_ids = genre_ids;
        }

        public List<String> getOrigin_country() {
            return origin_country;
        }

        public void setOrigin_country(List<String> origin_country) {
            this.origin_country = origin_country;
        }
    }
}
