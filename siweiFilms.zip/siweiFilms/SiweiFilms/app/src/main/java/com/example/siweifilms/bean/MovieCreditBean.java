package com.example.uscfilms.bean;

import java.util.List;

public class MovieCreditBean {


    /**
     * id : 399566
     * cast : [{"adult":false,"gender":2,"id":28846,"known_for_department":"Acting","name":"Alexander Skarsgård","original_name":"Alexander Skarsgård","popularity":11.539,"profile_path":"/hIuDik6KDmHLrqZWxBVdXzUw1kq.jpg","cast_id":27,"character":"Dr. Nathan Lind","credit_id":"5bd27583c3a3687437003310","order":0},{"adult":false,"gender":1,"id":1356210,"known_for_department":"Acting","name":"Millie Bobby Brown","original_name":"Millie Bobby Brown","popularity":37.905,"profile_path":"/yzfxLMcBMusKzZp9f1Z9Ags8WML.jpg","cast_id":10,"character":"Madison Russell","credit_id":"5b154f5dc3a368533000d528","order":1},{"adult":false,"gender":1,"id":15556,"known_for_department":"Acting","name":"Rebecca Hall","original_name":"Rebecca Hall","popularity":15.211,"profile_path":"/cVZaQrUY7F5khCBYdKDlEppHnQi.jpg","cast_id":29,"character":"Dr. Ilene Andrews","credit_id":"5bd9b264925141156c00e024","order":2},{"adult":false,"gender":2,"id":226366,"known_for_department":"Acting","name":"Brian Tyree Henry","original_name":"Brian Tyree Henry","popularity":4.63,"profile_path":"/1h4sYFAc1inxcV0Ljrl5v2mMskI.jpg","cast_id":25,"character":"Bernie Hayes","credit_id":"5bbeafae9251413d51006008","order":3},{"adult":false,"gender":2,"id":46364,"known_for_department":"Acting","name":"Shun Oguri","original_name":"Shun Oguri","popularity":6.417,"profile_path":"/4tfrhvqp3IGHPATor0lYE9X9UD3.jpg","cast_id":32,"character":"Ren Serizawa","credit_id":"5be890c90e0a263c0a031146","order":4},{"adult":false,"gender":1,"id":1222992,"known_for_department":"Acting","name":"Eiza González","original_name":"Eiza González","popularity":19.264,"profile_path":"/w2pZ8gLqZNguj8cqrDGbMw2Ibj0.jpg","cast_id":28,"character":"Maia Simmons","credit_id":"5bd9b256925141155700e422","order":5},{"adult":false,"gender":2,"id":1139349,"known_for_department":"Acting","name":"Julian Dennison","original_name":"Julian Dennison","popularity":5.317,"profile_path":"/9wmT8RDfJL2yKuY5AeJuDTkHSJe.jpg","cast_id":9,"character":"Josh Valentine","credit_id":"5b1411640e0a262dca0000ac","order":6},{"adult":false,"gender":2,"id":129101,"known_for_department":"Acting","name":"Lance Reddick","original_name":"Lance Reddick","popularity":8.574,"profile_path":"/22mVtEXZbpt0J7S0LhIhdkfRrZV.jpg","cast_id":37,"character":"Guillermin","credit_id":"5becd66d9251413cdb009fcc","order":7},{"adult":false,"gender":2,"id":3497,"known_for_department":"Acting","name":"Kyle Chandler","original_name":"Kyle Chandler","popularity":10.853,"profile_path":"/12ycW6JwP51RJA36mbT7ietI4Ce.jpg","cast_id":11,"character":"Mark Russell","credit_id":"5b154f7c0e0a262dea00a185","order":8},{"adult":false,"gender":2,"id":76961,"known_for_department":"Acting","name":"Demián Bichir","original_name":"Demián Bichir","popularity":4.315,"profile_path":"/sw8TqPQLbMMgLbkNNUIW649THWJ.jpg","cast_id":26,"character":"Walter Simmons","credit_id":"5bc82e840e0a26362e01120e","order":9},{"adult":false,"gender":1,"id":2948491,"known_for_department":"Acting","name":"Kaylee Hottle","original_name":"Kaylee Hottle","popularity":3.083,"profile_path":"/xpQQZgptOUI6duMMBDyCiaJ4JUv.jpg","cast_id":60,"character":"Jia","credit_id":"600c0d153710970041a1a056","order":10},{"adult":false,"gender":2,"id":2603,"known_for_department":"Acting","name":"Hakeem Kae-Kazim","original_name":"Hakeem Kae-Kazim","popularity":3.623,"profile_path":"/sVNHRm51c9toG73FUQ5k1St0vju.jpg","cast_id":59,"character":"Admiral Wilcox","credit_id":"600c0cedc86b3a003fbe0ca3","order":11},{"adult":false,"gender":2,"id":1319469,"known_for_department":"Acting","name":"Ronny Chieng","original_name":"Ronny Chieng","popularity":1.7,"profile_path":"/haFPocRfiud0Miw45HlknGMaLG5.jpg","cast_id":58,"character":"Jay Wayne","credit_id":"600c0cd2dd83fa0040909c38","order":12},{"adult":false,"gender":2,"id":1178193,"known_for_department":"Acting","name":"John Pirruccello","original_name":"John Pirruccello","popularity":2.922,"profile_path":"/5fHP9q7bLbOGpeyoKpkz6MaunMN.jpg","cast_id":57,"character":"Horace","credit_id":"600c0cb7813cb600427c006c","order":13},{"adult":false,"gender":2,"id":172096,"known_for_department":"Acting","name":"Chris Chalk","original_name":"Chris Chalk","popularity":6.526,"profile_path":"/j8IpJkLTAhalh5Q356VNojcIAtx.jpg","cast_id":56,"character":"Ben","credit_id":"600c0c95c86b3a003fbe0c83","order":14},{"adult":false,"gender":2,"id":2545317,"known_for_department":"Acting","name":"Conlan Casal","original_name":"Conlan Casal","popularity":0.6,"profile_path":"/nBbRXpuiufIXeXhHR3v9I2kEymP.jpg","cast_id":72,"character":"Apex Cybernetics Security Guard","credit_id":"601624c0976a23003ca463e2","order":15},{"adult":false,"gender":2,"id":123540,"known_for_department":"Acting","name":"Brad McMurray","original_name":"Brad McMurray","popularity":1.422,"profile_path":"/bfsTsUwYajWlVPgkcY9QzrWuVbi.jpg","cast_id":73,"character":"Apex Cybernetics Security Guard","credit_id":"601624cebc8657003e6c16e9","order":16},{"adult":false,"gender":2,"id":1371541,"known_for_department":"Acting","name":"Benjamin Rigby","original_name":"Benjamin Rigby","popularity":1.4,"profile_path":"/le5qTKDolOJBZ5mWjnx5QwNbCPA.jpg","cast_id":74,"character":"Sonar Operator","credit_id":"601624f10816c7003f84c7e6","order":17},{"adult":false,"gender":2,"id":2272452,"known_for_department":"Crew","name":"Nick Turello","original_name":"Nick Turello","popularity":0.6,"profile_path":"/hKlnldINN0J6bY3Rj9PXvjSzjMb.jpg","cast_id":75,"character":"Apex Cybernetics Armed Guard","credit_id":"6016250dbf0f63003e0f1642","order":18},{"adult":false,"gender":2,"id":2881089,"known_for_department":"Acting","name":"Daniel Nelson","original_name":"Daniel Nelson","popularity":1.162,"profile_path":"/jfVtAqELfncHRHomUrTuVVYXrg.jpg","cast_id":51,"character":"Hayworth","credit_id":"5fca3f64dcf875003f40b2f5","order":19},{"adult":false,"gender":1,"id":2102960,"known_for_department":"Acting","name":"Priscilla Doueihy","original_name":"Priscilla Doueihy","popularity":1.312,"profile_path":"/it4g13EMcqsXXggG1DYcOxQZwsA.jpg","cast_id":54,"character":"Monarch Mission Tech","credit_id":"600a0673d55c3d00406c465e","order":20},{"adult":false,"gender":0,"id":2958901,"known_for_department":"Acting","name":"Kei Kudo","original_name":"Kei Kudo","popularity":1.009,"profile_path":null,"cast_id":76,"character":"HEAV Pilot","credit_id":"6016254428723c003dabf6c7","order":21},{"adult":false,"gender":2,"id":1871679,"known_for_department":"Crew","name":"Bradd Buckley","original_name":"Bradd Buckley","popularity":0.84,"profile_path":null,"cast_id":77,"character":"HEAV Pilot","credit_id":"601625512d3721003fc35858","order":22},{"adult":false,"gender":2,"id":1265157,"known_for_department":"Acting","name":"John Walton","original_name":"John Walton","popularity":0.6,"profile_path":null,"cast_id":163,"character":"HEAV Co-Pilot","credit_id":"606a97e512c6040029621ca3","order":23},{"adult":false,"gender":2,"id":2612144,"known_for_department":"Acting","name":"Daniel Tuiara","original_name":"Daniel Tuiara","popularity":0.6,"profile_path":"/7FQS4v8pa84ojcCuRfOzqI64NC0.jpg","cast_id":164,"character":"HEAV Co-Pilot","credit_id":"606a97efa14bef00792a4109","order":24},{"adult":false,"gender":2,"id":1696636,"known_for_department":"Crew","name":"David Castillo","original_name":"David Castillo","popularity":1.38,"profile_path":"/jlQLRRhOJB3bkXNMletYPio8pS4.jpg","cast_id":78,"character":"Maia Apex Cybernetics Guard","credit_id":"6016256fd96c3c00410ec397","order":25},{"adult":false,"gender":2,"id":1298704,"known_for_department":"Acting","name":"Kofi Yiadom","original_name":"Kofi Yiadom","popularity":0.75,"profile_path":"/uvVMFFmg26p1sd9mQaclczyunx.jpg","cast_id":79,"character":"Maia Apex Cybernetics Guard","credit_id":"6016257cbc8657003d6be201","order":26},{"adult":false,"gender":2,"id":9568,"known_for_department":"Acting","name":"Jim Palmer","original_name":"Jim Palmer","popularity":1.4,"profile_path":"/oFaoyxX8EPY6VxBJ3pVyMezseuZ.jpg","cast_id":55,"character":"Maia Apex Cybernetics Guard","credit_id":"600a0685d70594003d1d76af","order":27},{"adult":false,"gender":2,"id":2958904,"known_for_department":"Acting","name":"Drew Walton","original_name":"Drew Walton","popularity":0.982,"profile_path":"/g8byyulAZcXW5heefanHMG227pY.jpg","cast_id":80,"character":"David Lind (uncredited)","credit_id":"601625a7cb802800411054e7","order":28},{"adult":false,"gender":1,"id":1692993,"known_for_department":"Acting","name":"Tara Wraith","original_name":"Tara Wraith","popularity":0.98,"profile_path":"/7hxplRWMQy0iQPLIBVQyWL9fD6R.jpg","cast_id":182,"character":"Monarch Flight Crew (uncredited)","credit_id":"607b87d07a97ab0040a07b2d","order":29},{"adult":false,"gender":1,"id":3057274,"known_for_department":"Acting","name":"Felicia Wickliff","original_name":"Felicia Wickliff","popularity":0.6,"profile_path":null,"cast_id":183,"character":"Apex Guard (uncredited)","credit_id":"607b880eae281100294246c9","order":30},{"adult":false,"gender":2,"id":2185168,"known_for_department":"Acting","name":"Ken Watanabe","original_name":"Ken Watanabe","popularity":0.6,"profile_path":null,"cast_id":184,"character":"Bar Patron (uncredited)","credit_id":"607b88a1713ed4007d0a59ab","order":31},{"adult":false,"gender":1,"id":3057275,"known_for_department":"Acting","name":"Amber Walls","original_name":"Amber Walls","popularity":0.6,"profile_path":null,"cast_id":185,"character":"Refugee (uncredited)","credit_id":"607b88be7e34830058aa90a0","order":32},{"adult":false,"gender":2,"id":2112181,"known_for_department":"Acting","name":"Scott Wallace","original_name":"Scott Wallace","popularity":0.6,"profile_path":null,"cast_id":186,"character":"Monarch Guard (uncredited)","credit_id":"607b88ff746457006e9203bd","order":33},{"adult":false,"gender":2,"id":2027791,"known_for_department":"Acting","name":"Jason Virgil","original_name":"Jason Virgil","popularity":0.6,"profile_path":"/4rMBW2yVt4uH8xrHSt9ORu3bc2C.jpg","cast_id":187,"character":"Bartender (uncredited)","credit_id":"607b892aab68490029ca5f05","order":34},{"adult":false,"gender":1,"id":2524631,"known_for_department":"Acting","name":"Grisel Toledo","original_name":"Grisel Toledo","popularity":1.4,"profile_path":null,"cast_id":188,"character":"Apex Guard (uncredited)","credit_id":"607b896a746457005892f336","order":35},{"adult":false,"gender":1,"id":3057280,"known_for_department":"Acting","name":"Lara Thomas","original_name":"Lara Thomas","popularity":0.6,"profile_path":null,"cast_id":189,"character":"News Reporter (uncredited)","credit_id":"607b899d01b1ca002a5a39b4","order":36},{"adult":false,"gender":2,"id":2265521,"known_for_department":"Acting","name":"Jason Szabo","original_name":"Jason Szabo","popularity":0.6,"profile_path":null,"cast_id":190,"character":"Monarch Tactical Guard","credit_id":"607b89b5ae281100404a8bbb","order":37},{"adult":false,"gender":2,"id":1486626,"known_for_department":"Production","name":"Jason Speer","original_name":"Jason Speer","popularity":0.6,"profile_path":null,"cast_id":191,"character":"Monarch Board Member (uncredited)","credit_id":"607b89eb29c626007990af2a","order":38},{"adult":false,"gender":1,"id":2213356,"known_for_department":"Acting","name":"Andrea Elizabeth Sikkink","original_name":"Andrea Elizabeth Sikkink","popularity":0.6,"profile_path":null,"cast_id":192,"character":"Driver / Passerby (uncredited)","credit_id":"607b8a0229c626004127d23d","order":39},{"adult":false,"gender":2,"id":2030686,"known_for_department":"Acting","name":"Sen Shao","original_name":"Sen Shao","popularity":0.6,"profile_path":null,"cast_id":193,"character":"Thug (uncredited)","credit_id":"607b8a26746457005892f4dc","order":40},{"adult":false,"gender":2,"id":3057286,"known_for_department":"Acting","name":"Rob Schyff","original_name":"Rob Schyff","popularity":0.6,"profile_path":null,"cast_id":194,"character":"Cafe Patron (uncredited)","credit_id":"607b8a3caa659e0057ebc776","order":41},{"adult":false,"gender":2,"id":1879911,"known_for_department":"Acting","name":"Scott M. Schewe","original_name":"Scott M. Schewe","popularity":0.6,"profile_path":null,"cast_id":195,"character":"Fisherman (uncredited)","credit_id":"607b8a6143d9b10057d93ed8","order":42},{"adult":false,"gender":2,"id":3057287,"known_for_department":"Acting","name":"Daniel Santana Jr.","original_name":"Daniel Santana Jr.","popularity":0.6,"profile_path":null,"cast_id":196,"character":"Party Goer (uncredited)","credit_id":"607b8a77713ed4007d0a5dd4","order":43},{"adult":false,"gender":2,"id":2965914,"known_for_department":"Acting","name":"Charles Sans","original_name":"Charles Sans","popularity":0.6,"profile_path":null,"cast_id":197,"character":"Apex Guard (uncredited)","credit_id":"607b8a9cf263ba007094aff8","order":44},{"adult":false,"gender":1,"id":1244248,"known_for_department":"Acting","name":"Tasneem Roc","original_name":"Tasneem Roc","popularity":2.912,"profile_path":"/ilkyHt7YpN7bNTYzhODXWR0QnwN.jpg","cast_id":198,"character":"Reporter (uncredited)","credit_id":"607b8b24aa659e0078dccbde","order":45},{"adult":false,"gender":2,"id":2573855,"known_for_department":"Acting","name":"Diezel Ramos","original_name":"Diezel Ramos","popularity":1.38,"profile_path":"/uoMRnPYtWbKSgTY7LdeUPblruP1.jpg","cast_id":199,"character":"Monarch Military (uncredited)","credit_id":"607b8b41ab68490029ca6270","order":46},{"adult":false,"gender":2,"id":1840497,"known_for_department":"Acting","name":"Jon Quested","original_name":"Jon Quested","popularity":1.4,"profile_path":"/7tpHhDx4I9ysdcBKa8OXKdxH8Uj.jpg","cast_id":200,"character":"Construction Worker (uncredited)","credit_id":"607b8b5a29c626004127d4dc","order":47},{"adult":false,"gender":2,"id":2269093,"known_for_department":"Acting","name":"Joel Pierce","original_name":"Joel Pierce","popularity":1.932,"profile_path":"/n1CwK63h1wgYozM9nMt2KPdQI5z.jpg","cast_id":201,"character":"Monarch Tech #2 (uncredited)","credit_id":"607b8b859408ec0057c12215","order":48},{"adult":false,"gender":1,"id":2537658,"known_for_department":"Acting","name":"Sofia Nolan","original_name":"Sofia Nolan","popularity":0.6,"profile_path":"/jKTdzMjfSXqlxj9vkHqG4wVj3BS.jpg","cast_id":202,"character":"Mean Girl (uncredited)","credit_id":"607b8c329661fc005883cddb","order":49},{"adult":false,"gender":2,"id":3057288,"known_for_department":"Acting","name":"Austin Morrison","original_name":"Austin Morrison","popularity":0.6,"profile_path":null,"cast_id":203,"character":"Monarch Military (uncredited)","credit_id":"607b8c67ab68490058bec214","order":50},{"adult":false,"gender":2,"id":1879895,"known_for_department":"Acting","name":"Shawn McBride","original_name":"Shawn McBride","popularity":1.4,"profile_path":null,"cast_id":204,"character":"Fisherman (uncredited)","credit_id":"607b8c86713ed40058d7677e","order":51},{"adult":false,"gender":2,"id":2078523,"known_for_department":"Acting","name":"Niam Mayes","original_name":"Niam Mayes","popularity":0.728,"profile_path":null,"cast_id":205,"character":"US Navy Crew Member (uncredited)","credit_id":"607b8ca5c2823a0029e843b3","order":52},{"adult":false,"gender":2,"id":2545358,"known_for_department":"Acting","name":"Clay Mason","original_name":"Clay Mason","popularity":0.6,"profile_path":null,"cast_id":206,"character":"Refugee (uncredited)","credit_id":"607b8cc501b1ca0077a40cf4","order":53},{"adult":false,"gender":2,"id":3057289,"known_for_department":"Acting","name":"Steve Maggs","original_name":"Steve Maggs","popularity":0.6,"profile_path":null,"cast_id":208,"character":"Bar Patron (uncredited)","credit_id":"607b8cf0ae28110057e67f51","order":55},{"adult":false,"gender":1,"id":1338706,"known_for_department":"Acting","name":"Victoria Liu","original_name":"Victoria Liu","popularity":0.6,"profile_path":null,"cast_id":209,"character":"HEAV Pilot #3 (uncredited)","credit_id":"607b8d162b8a43003fc56f24","order":56},{"adult":false,"gender":1,"id":3043220,"known_for_department":"Acting","name":"Jasmine Liew","original_name":"Jasmine Liew","popularity":0.6,"profile_path":null,"cast_id":210,"character":"Asian Kid (uncredited)","credit_id":"607b8d34ae28110057e67fca","order":57},{"adult":false,"gender":2,"id":2267140,"known_for_department":"Acting","name":"Sonny Le","original_name":"Sonny Le","popularity":0.6,"profile_path":"/6ADWAGjO5ANMpp19Y7AlkWxNC8C.jpg","cast_id":211,"character":"Thug (uncredited)","credit_id":"607b8d55713ed40058d768a5","order":58},{"adult":false,"gender":1,"id":2969884,"known_for_department":"Acting","name":"Santi Lawson","original_name":"Santi Lawson","popularity":0.6,"profile_path":"/sJyDK4U2984rtybdhh2rqZPbAAX.jpg","cast_id":212,"character":"Apex Lab Tech (uncredited)","credit_id":"607b8d7a7e34830058aa98fd","order":59}]
     * crew : [{"adult":false,"gender":2,"id":1706,"known_for_department":"Writing","name":"Terry Rossio","original_name":"Terry Rossio","popularity":5.545,"profile_path":null,"credit_id":"600dae670b5fd6003e5ddb86","department":"Writing","job":"Story"},{"adult":false,"gender":2,"id":2445,"known_for_department":"Production","name":"Eric McLeod","original_name":"Eric McLeod","popularity":1.4,"profile_path":null,"credit_id":"600dae52813cb600407edaa6","department":"Production","job":"Producer"},{"adult":false,"gender":2,"id":2445,"known_for_department":"Production","name":"Eric McLeod","original_name":"Eric McLeod","popularity":1.4,"profile_path":null,"credit_id":"606a95e3a14bef00792a3ddc","department":"Production","job":"Unit Production Manager"},{"adult":false,"gender":2,"id":2529,"known_for_department":"Art","name":"Ronald R. Reiss","original_name":"Ronald R. Reiss","popularity":0.98,"profile_path":null,"credit_id":"60162698bc8657003f6c2ee2","department":"Art","job":"Set Decoration"},{"adult":false,"gender":1,"id":7232,"known_for_department":"Production","name":"Sarah Halley Finn","original_name":"Sarah Halley Finn","popularity":4.054,"profile_path":null,"credit_id":"5c4434b5c3a3681a00242113","department":"Production","job":"Casting"},{"adult":false,"gender":2,"id":9343,"known_for_department":"Art","name":"Owen Paterson","original_name":"Owen Paterson","popularity":0.6,"profile_path":null,"credit_id":"5b18eed3c3a3684913004ccc","department":"Art","job":"Production Design"},{"adult":false,"gender":2,"id":11012,"known_for_department":"Writing","name":"Michael Dougherty","original_name":"Michael Dougherty","popularity":2.917,"profile_path":"/spyEbbR2ySIfYY6onH0E4a26Dpo.jpg","credit_id":"600dae8dcb80280040008156","department":"Writing","job":"Story"},{"adult":false,"gender":2,"id":21036,"known_for_department":"Production","name":"Roy Lee","original_name":"Roy Lee","popularity":1.4,"profile_path":"/fMY0MiVyrGaK44ejqWzT2txcRVI.jpg","credit_id":"5bdc15469251417855008898","department":"Production","job":"Executive Producer"},{"adult":false,"gender":2,"id":52452,"known_for_department":"Sound","name":"Peter Afterman","original_name":"Peter Afterman","popularity":1.237,"profile_path":null,"credit_id":"60162ca33009aa003eb8d290","department":"Sound","job":"Music Supervisor"},{"adult":false,"gender":0,"id":54211,"known_for_department":"Production","name":"Thomas Tull","original_name":"Thomas Tull","popularity":1.4,"profile_path":"/5UG4FK7rsmhzJDYxpU28acqfxtu.jpg","credit_id":"5b18ef8a0e0a261f8d004ccf","department":"Production","job":"Producer"},{"adult":false,"gender":2,"id":56827,"known_for_department":"Sound","name":"Junkie XL","original_name":"Junkie XL","popularity":0.912,"profile_path":"/oRxT9sySUewNqcfmLT8OC9ffytx.jpg","credit_id":"5ee147d297eab4001fdf761b","department":"Sound","job":"Original Music Composer"},{"adult":false,"gender":2,"id":61091,"known_for_department":"Production","name":"Jon Jashni","original_name":"Jon Jashni","popularity":1.053,"profile_path":null,"credit_id":"5b18ef4d9251414b920046f6","department":"Production","job":"Producer"},{"adult":false,"gender":2,"id":62484,"known_for_department":"Art","name":"Richard Hobbs","original_name":"Richard Hobbs","popularity":1.051,"profile_path":null,"credit_id":"6016264f8a88b2003f99f58c","department":"Art","job":"Supervising Art Director"},{"adult":false,"gender":0,"id":62723,"known_for_department":"Editing","name":"Stefan Sonnenfeld","original_name":"Stefan Sonnenfeld","popularity":1.657,"profile_path":null,"credit_id":"5f32dcab71f095003697ce4a","department":"Editing","job":"Digital Intermediate Colorist"},{"adult":false,"gender":2,"id":62739,"known_for_department":"Production","name":"Herb Gains","original_name":"Herb Gains","popularity":1.974,"profile_path":null,"credit_id":"600dade9d70594003e219f78","department":"Production","job":"Executive Producer"},{"adult":false,"gender":0,"id":62740,"known_for_department":"Production","name":"Richard Mirisch","original_name":"Richard Mirisch","popularity":0.6,"profile_path":null,"credit_id":"606a96ba025764005946cf08","department":"Production","job":"Co-Producer"},{"adult":false,"gender":2,"id":63310,"known_for_department":"Camera","name":"Ben Seresin","original_name":"Ben Seresin","popularity":0.6,"profile_path":"/AnzjkOFIDLbEuOMimwH2NtjGHNG.jpg","credit_id":"5bea32580e0a264c3e01cbde","department":"Camera","job":"Director of Photography"},{"adult":false,"gender":2,"id":112690,"known_for_department":"Production","name":"Dan Lin","original_name":"Dan Lin","popularity":1.411,"profile_path":null,"credit_id":"5b18efb10e0a261faa004e5b","department":"Production","job":"Executive Producer"},{"adult":false,"gender":0,"id":75292,"known_for_department":"Art","name":"Rebecca Cohen","original_name":"Rebecca Cohen","popularity":0.98,"profile_path":null,"credit_id":"60162689a9117f0040e5a9ab","department":"Art","job":"Set Decoration"},{"adult":false,"gender":2,"id":90281,"known_for_department":"Production","name":"Alex Garcia","original_name":"Alex Garcia","popularity":1.186,"profile_path":null,"credit_id":"600dae3522e480003e045194","department":"Production","job":"Producer"},{"adult":false,"gender":2,"id":109870,"known_for_department":"Costume & Make-Up","name":"Tom Woodruff Jr.","original_name":"Tom Woodruff Jr.","popularity":1.686,"profile_path":"/o5MW7KiROaA5uf9zzJmpHJfUjh3.jpg","credit_id":"6016271ebc8657003d6be36f","department":"Visual Effects","job":"Creature Design"},{"adult":false,"gender":2,"id":98631,"known_for_department":"Directing","name":"Adam Wingard","original_name":"Adam Wingard","popularity":3.08,"profile_path":"/3Dk4vAmhdb59VTnNRnW1ln52wG6.jpg","credit_id":"592e202b92514130e300294c","department":"Directing","job":"Director"},{"adult":false,"gender":1,"id":114408,"known_for_department":"Production","name":"Mary Parent","original_name":"Mary Parent","popularity":1.432,"profile_path":null,"credit_id":"5b18ef650e0a261fa700495e","department":"Production","job":"Producer"},{"adult":false,"gender":2,"id":235715,"known_for_department":"Production","name":"Yoshimitsu Banno","original_name":"Yoshimitsu Banno","popularity":1.616,"profile_path":"/c8eLKTXFgzBtTRO0szgdjsrxzHA.jpg","credit_id":"5f5998770e44190037f8637e","department":"Production","job":"Executive Producer"},{"adult":false,"gender":0,"id":574042,"known_for_department":"Acting","name":"Brian Rogers","original_name":"Brian Rogers","popularity":0.6,"profile_path":null,"credit_id":"5b18ef7b0e0a261f8a004be5","department":"Production","job":"Producer"},{"adult":false,"gender":2,"id":579281,"known_for_department":"Writing","name":"Eric Pearson","original_name":"Eric Pearson","popularity":3.194,"profile_path":"/zcDkJjHu28TcrgBi1X4VClUk8Hx.jpg","credit_id":"600daed6d55c3d003e72fcac","department":"Writing","job":"Screenplay"},{"adult":false,"gender":2,"id":1042114,"known_for_department":"Acting","name":"Matt Mullins","original_name":"Matt Mullins","popularity":1.17,"profile_path":"/jexgSbiOL44RPZUpaTgPoBsyrjL.jpg","credit_id":"5fce4cbf6af8f8003d0920a5","department":"Crew","job":"Stunts"},{"adult":false,"gender":2,"id":1080778,"known_for_department":"Writing","name":"Max Borenstein","original_name":"Max Borenstein","popularity":2.782,"profile_path":null,"credit_id":"600daee20b5fd6003d5cfee7","department":"Writing","job":"Screenplay"},{"adult":false,"gender":2,"id":1098783,"known_for_department":"Art","name":"Thomas S. Hammock","original_name":"Thomas S. Hammock","popularity":0.6,"profile_path":null,"credit_id":"600dad58813cb600427e3fd7","department":"Art","job":"Production Design"},{"adult":false,"gender":2,"id":1121584,"known_for_department":"Camera","name":"Andrew Jackson","original_name":"Andrew Jackson","popularity":0.6,"profile_path":null,"credit_id":"60162b79d7cd06003e07d0f5","department":"Crew","job":"Video Assist Operator"},{"adult":false,"gender":0,"id":1263443,"known_for_department":"Sound","name":"Brandon Jones","original_name":"Brandon Jones","popularity":0.6,"profile_path":null,"credit_id":"601628f12d37210040c3286c","department":"Sound","job":"Sound Designer"},{"adult":false,"gender":2,"id":1298704,"known_for_department":"Acting","name":"Kofi Yiadom","original_name":"Kofi Yiadom","popularity":0.75,"profile_path":"/uvVMFFmg26p1sd9mQaclczyunx.jpg","credit_id":"606a9b7512c604006eaee5cc","department":"Crew","job":"Stunts"},{"adult":false,"gender":0,"id":1324035,"known_for_department":"Editing","name":"Josh Schaeffer","original_name":"Josh Schaeffer","popularity":1.788,"profile_path":null,"credit_id":"5bea32cb0e0a263bf804e2da","department":"Editing","job":"Editor"},{"adult":false,"gender":2,"id":1338372,"known_for_department":"Sound","name":"Dan O'Connell","original_name":"Dan O'Connell","popularity":1.052,"profile_path":null,"credit_id":"601629010816c7004188d9b2","department":"Sound","job":"Foley Artist"},{"adult":false,"gender":2,"id":1339453,"known_for_department":"Crew","name":"Thomas Robinson Harper","original_name":"Thomas Robinson Harper","popularity":0.6,"profile_path":"/xPFdDSXceVebYdcYOKpkTpncWoC.jpg","credit_id":"606a990d7f2d4a0058cb16e7","department":"Crew","job":"Stunt Coordinator"},{"adult":false,"gender":2,"id":1339453,"known_for_department":"Crew","name":"Thomas Robinson Harper","original_name":"Thomas Robinson Harper","popularity":0.6,"profile_path":"/xPFdDSXceVebYdcYOKpkTpncWoC.jpg","credit_id":"606a974098f1f1002965ae23","department":"Directing","job":"Second Unit Director"},{"adult":false,"gender":0,"id":1352958,"known_for_department":"Art","name":"A. Todd Holland","original_name":"A. Todd Holland","popularity":0.607,"profile_path":null,"credit_id":"6016265d7f0540003dc84934","department":"Camera","job":"Additional Photography"},{"adult":false,"gender":1,"id":1355532,"known_for_department":"Directing","name":"Kerry Lyn McKissick","original_name":"Kerry Lyn McKissick","popularity":1.4,"profile_path":"/5IAKLVCEBwqWBmMG0JEYgjfDaO0.jpg","credit_id":"60162ce63e09f3003d42c36d","department":"Directing","job":"Script Supervisor"},{"adult":false,"gender":0,"id":1355604,"known_for_department":"Production","name":"Kenji Okuhira","original_name":"Kenji Okuhira","popularity":0.6,"profile_path":null,"credit_id":"600dae090cd4460040e12388","department":"Production","job":"Executive Producer"},{"adult":false,"gender":2,"id":1364427,"known_for_department":"Sound","name":"Clint Bennett","original_name":"Clint Bennett","popularity":0.728,"profile_path":null,"credit_id":"60162cbabb1057003d9334ee","department":"Sound","job":"Music Editor"},{"adult":false,"gender":0,"id":1376888,"known_for_department":"Art","name":"Luke Caska","original_name":"Luke Caska","popularity":0.6,"profile_path":null,"credit_id":"601628a82d3721003dc30fbd","department":"Art","job":"Set Designer"},{"adult":false,"gender":0,"id":1394454,"known_for_department":"Crew","name":"Yoshinao Aonuma","original_name":"Yoshinao Aonuma","popularity":0.6,"profile_path":null,"credit_id":"60162a4ded96bc0040fb9255","department":"Crew","job":"Stunts"},{"adult":false,"gender":0,"id":1401362,"known_for_department":"Visual Effects","name":"John 'D.J.' Des Jardin","original_name":"John 'D.J.' Des Jardin","popularity":5.843,"profile_path":"/7on8qoGS5DR0fkdVCEHNg9dwuoY.jpg","credit_id":"5bea33ab0e0a263c0604bbee","department":"Visual Effects","job":"Visual Effects Supervisor"},{"adult":false,"gender":2,"id":1401739,"known_for_department":"Lighting","name":"Shaun Conway","original_name":"Shaun Conway","popularity":0.6,"profile_path":null,"credit_id":"60162aaa2d3721003ec34530","department":"Lighting","job":"Gaffer"},{"adult":false,"gender":2,"id":1402902,"known_for_department":"Lighting","name":"Paul Johnstone","original_name":"Paul Johnstone","popularity":0.98,"profile_path":null,"credit_id":"60162b93d266a200400e7c7e","department":"Lighting","job":"Electrician"},{"adult":false,"gender":0,"id":1403425,"known_for_department":"Costume & Make-Up","name":"Mahealani Diego","original_name":"Mahealani Diego","popularity":1.4,"profile_path":null,"credit_id":"601626fa907f26003f55e6a5","department":"Costume & Make-Up","job":"Key Hair Stylist"},{"adult":false,"gender":0,"id":1404845,"known_for_department":"Visual Effects","name":"Tamara Watts Kent","original_name":"Tamara Watts Kent","popularity":0.6,"profile_path":null,"credit_id":"606a966744ea5400400f8af2","department":"Visual Effects","job":"Visual Effects Producer"},{"adult":false,"gender":0,"id":1404845,"known_for_department":"Visual Effects","name":"Tamara Watts Kent","original_name":"Tamara Watts Kent","popularity":0.6,"profile_path":null,"credit_id":"606a963409c24c002a3eae62","department":"Production","job":"Co-Producer"},{"adult":false,"gender":0,"id":1412734,"known_for_department":"Production","name":"Jennifer Cornwell","original_name":"Jennifer Cornwell","popularity":0.828,"profile_path":null,"credit_id":"606a95eed48cee00590ba119","department":"Production","job":"Unit Production Manager"},{"adult":false,"gender":0,"id":1412753,"known_for_department":"Production","name":"Jamie Whitfield","original_name":"Jamie Whitfield","popularity":0.6,"profile_path":null,"credit_id":"6016278928723c0044ac9702","department":"Production","job":"Assistant Unit Manager"},{"adult":false,"gender":0,"id":1443683,"known_for_department":"Writing","name":"Zach Shields","original_name":"Zach Shields","popularity":2.099,"profile_path":null,"credit_id":"600daeadc8113d003f90d3ed","department":"Writing","job":"Story"},{"adult":false,"gender":0,"id":1463403,"known_for_department":"Crew","name":"Chris Brenczewski","original_name":"Chris Brenczewski","popularity":0.6,"profile_path":null,"credit_id":"60162946cb80280041105b12","department":"Crew","job":"Special Effects Coordinator"},{"adult":false,"gender":0,"id":1525547,"known_for_department":"Crew","name":"Bruce Bright","original_name":"Bruce Bright","popularity":1.15,"profile_path":null,"credit_id":"60162958bf0f63003f0d21bf","department":"Visual Effects","job":"Special Effects Supervisor"},{"adult":false,"gender":0,"id":1526465,"known_for_department":"Costume & Make-Up","name":"Ann Foley","original_name":"Ann Foley","popularity":0.6,"profile_path":null,"credit_id":"5b9e234dc3a3684408016530","department":"Costume & Make-Up","job":"Costume Design"},{"adult":false,"gender":0,"id":1559163,"known_for_department":"Visual Effects","name":"Nathan Abbot","original_name":"Nathan Abbot","popularity":0.6,"profile_path":null,"credit_id":"601629c5bf0f63003e0f1ee0","department":"Visual Effects","job":"Compositing Lead"},{"adult":false,"gender":2,"id":1635449,"known_for_department":"Crew","name":"Terry Ahue","original_name":"Terry Ahue","popularity":0.6,"profile_path":null,"credit_id":"606a9ba2124c8d003f385c99","department":"Crew","job":"Stunts"},{"adult":false,"gender":2,"id":1635506,"known_for_department":"Art","name":"Christopher Bruce","original_name":"Christopher Bruce","popularity":0.6,"profile_path":null,"credit_id":"6016289b3e09f3003f41be60","department":"Art","job":"Leadman"},{"adult":false,"gender":0,"id":1654216,"known_for_department":"Visual Effects","name":"Jubey Jose","original_name":"Jubey Jose","popularity":0.6,"profile_path":null,"credit_id":"60162bd6cb8028003f1310af","department":"Visual Effects","job":"Animation"},{"adult":false,"gender":0,"id":1683351,"known_for_department":"Directing","name":"Nick Satriano","original_name":"Nick Satriano","popularity":1.167,"profile_path":null,"credit_id":"606a9609d3d3870070a12279","department":"Directing","job":"First Assistant Director"},{"adult":false,"gender":2,"id":1685460,"known_for_department":"Crew","name":"David Paris","original_name":"David Paris","popularity":1.935,"profile_path":null,"credit_id":"606a9b5d44ea54005933317c","department":"Crew","job":"Pilot"},{"adult":false,"gender":0,"id":1699151,"known_for_department":"Production","name":"Jennifer Conroy","original_name":"Jennifer Conroy","popularity":0.98,"profile_path":null,"credit_id":"601627584df291003e204485","department":"Production","job":"Unit Production Manager"},{"adult":false,"gender":0,"id":1699151,"known_for_department":"Production","name":"Jennifer Conroy","original_name":"Jennifer Conroy","popularity":0.98,"profile_path":null,"credit_id":"606a96253429ff00592c10f4","department":"Production","job":"Co-Producer"},{"adult":false,"gender":0,"id":1709353,"known_for_department":"Crew","name":"Jason Beale","original_name":"Jason Beale","popularity":0.6,"profile_path":null,"credit_id":"60162c25d96c3c0040102b1d","department":"Crew","job":"Post Production Assistant"},{"adult":false,"gender":1,"id":1737819,"known_for_department":"Crew","name":"Jenny Fumarolo","original_name":"Jenny Fumarolo","popularity":0.6,"profile_path":null,"credit_id":"6016276687a27a003ee1587b","department":"Production","job":"Production Supervisor"},{"adult":false,"gender":0,"id":1737940,"known_for_department":"Acting","name":"Damien Bryson","original_name":"Damien Bryson","popularity":0.6,"profile_path":null,"credit_id":"606a9bc4124c8d00575f700c","department":"Crew","job":"Stunts"},{"adult":false,"gender":2,"id":1738113,"known_for_department":"Crew","name":"Frédéric North","original_name":"Frédéric North","popularity":1.22,"profile_path":"/6Y9Us44RyRwFi2wqEqYckX6VBjz.jpg","credit_id":"606a9b500d2f53006e0ac54a","department":"Crew","job":"Pilot"},{"adult":false,"gender":0,"id":1746431,"known_for_department":"Camera","name":"Toby Copping","original_name":"Toby Copping","popularity":0.6,"profile_path":null,"credit_id":"60162ab6dd731b00405780b7","department":"Camera","job":"Key Grip"},{"adult":false,"gender":0,"id":1759809,"known_for_department":"Costume & Make-Up","name":"Ralph Malani","original_name":"Ralph Malani","popularity":0.98,"profile_path":null,"credit_id":"6016270cd7cd06003d08155d","department":"Costume & Make-Up","job":"Hairstylist"},{"adult":false,"gender":2,"id":1765209,"known_for_department":"Crew","name":"Carlos A. Herzer","original_name":"Carlos A. Herzer","popularity":0.6,"profile_path":null,"credit_id":"60162a5d907f2600405613ad","department":"Crew","job":"Driver"},{"adult":false,"gender":0,"id":1769079,"known_for_department":"Sound","name":"Joel Reidy","original_name":"Joel Reidy","popularity":0.6,"profile_path":null,"credit_id":"60162911b5bc21003c9c1cab","department":"Sound","job":"Boom Operator"},{"adult":false,"gender":2,"id":1787802,"known_for_department":"Directing","name":"Brian Avery Galligan","original_name":"Brian Avery Galligan","popularity":1.88,"profile_path":null,"credit_id":"601627b22d3721003ec33e5a","department":"Directing","job":"Second Assistant Director"},{"adult":false,"gender":2,"id":1830633,"known_for_department":"Crew","name":"Kyle Gardiner","original_name":"Kyle Gardiner","popularity":0.6,"profile_path":null,"credit_id":"606a991d0c3ec8006e817007","department":"Crew","job":"Stunt Coordinator"},{"adult":false,"gender":0,"id":1866293,"known_for_department":"Crew","name":"Peter Wyborn","original_name":"Peter Wyborn","popularity":0.6,"profile_path":null,"credit_id":"6016267487a27a003ee15700","department":"Art","job":"Art Direction"},{"adult":false,"gender":0,"id":1899694,"known_for_department":"Camera","name":"Jack Glenn","original_name":"Jack Glenn","popularity":0.605,"profile_path":null,"credit_id":"60162adc956658003e5a3ece","department":"Camera","job":"Dolly Grip"},{"adult":false,"gender":2,"id":1914663,"known_for_department":"Sound","name":"Malte Bieler","original_name":"Malte Bieler","popularity":0.6,"profile_path":null,"credit_id":"601628e02d37210040c32851","department":"Sound","job":"Sound Editor"},{"adult":false,"gender":0,"id":1958110,"known_for_department":"Editing","name":"John St. Laurent","original_name":"John St. Laurent","popularity":0.6,"profile_path":null,"credit_id":"60162c48bc8657003d6be9f7","department":"Editing","job":"Colorist"},{"adult":false,"gender":0,"id":1973245,"known_for_department":"Visual Effects","name":"Zack Fox","original_name":"Zack Fox","popularity":0.6,"profile_path":null,"credit_id":"5c13bc880e0a2603823b9fd7","department":"Visual Effects","job":"Visual Effects Coordinator"},{"adult":false,"gender":0,"id":2001871,"known_for_department":"Sound","name":"Tom Pigott Smith","original_name":"Tom Pigott Smith","popularity":0.6,"profile_path":null,"credit_id":"60162cd9cb802800400a62a5","department":"Sound","job":"Musician"},{"adult":false,"gender":0,"id":2020807,"known_for_department":"Production","name":"Djinous Rowling","original_name":"Djinous Rowling","popularity":0.6,"profile_path":null,"credit_id":"60162bfaa9117f003ee5fb53","department":"Production","job":"Casting Assistant"},{"adult":false,"gender":0,"id":2030700,"known_for_department":"Costume & Make-Up","name":"Katrina Anger","original_name":"Katrina Anger","popularity":0.6,"profile_path":null,"credit_id":"601626e5976a23003ea37f14","department":"Costume & Make-Up","job":"Additional Wardrobe Assistant"},{"adult":false,"gender":0,"id":2033412,"known_for_department":"Lighting","name":"Charlie Adams","original_name":"Charlie Adams","popularity":0.6,"profile_path":null,"credit_id":"60162a6d976a23003da408db","department":"Lighting","job":"Lighting Technician"},{"adult":false,"gender":0,"id":2045341,"known_for_department":"Editing","name":"Jesse Chapman","original_name":"Jesse Chapman","popularity":0.6,"profile_path":null,"credit_id":"60162c36956658003f5a80ef","department":"Editing","job":"Additional Editor"},{"adult":false,"gender":0,"id":2057527,"known_for_department":"Art","name":"Richard Bennett","original_name":"Richard Bennett","popularity":0.6,"profile_path":null,"credit_id":"60162878d96c3c003f0f5991","department":"Art","job":"Storyboard Artist"},{"adult":false,"gender":0,"id":2107433,"known_for_department":"Lighting","name":"Sami Gustafsson","original_name":"Sami Gustafsson","popularity":0.6,"profile_path":null,"credit_id":"60162aea55b0c0003e788cd2","department":"Lighting","job":"Lighting Technician"},{"adult":false,"gender":0,"id":2123788,"known_for_department":"Sound","name":"Sara Barone","original_name":"Sara Barone","popularity":0.6,"profile_path":null,"credit_id":"60162caf1b70ae003c623400","department":"Sound","job":"Orchestrator"},{"adult":false,"gender":0,"id":2125916,"known_for_department":"Camera","name":"Stu Carl","original_name":"Stu Carl","popularity":0.694,"profile_path":null,"credit_id":"60162a9bb5bc21003b9db1e0","department":"Camera","job":"Grip"},{"adult":false,"gender":0,"id":2161927,"known_for_department":"Crew","name":"Debajit Barman","original_name":"Debajit Barman","popularity":0.98,"profile_path":null,"credit_id":"60162c13dd731b003f573397","department":"Editing","job":"Editorial Manager"},{"adult":false,"gender":0,"id":2213360,"known_for_department":"Costume & Make-Up","name":"Jordann Aguon","original_name":"Jordann Aguon","popularity":0.6,"profile_path":null,"credit_id":"601626bad96c3c00410ec4de","department":"Costume & Make-Up","job":"Makeup Artist"},{"adult":false,"gender":0,"id":2271245,"known_for_department":"Production","name":"Jay Ashenfelter","original_name":"Jay Ashenfelter","popularity":0.6,"profile_path":null,"credit_id":"600daddc813cb600417f440a","department":"Production","job":"Executive Producer"},{"adult":false,"gender":2,"id":2460805,"known_for_department":"Visual Effects","name":"Daniel Alvite","original_name":"Daniel Alvite","popularity":0.6,"profile_path":null,"credit_id":"60162ba8873f00003ca6b404","department":"Visual Effects","job":"Animation"},{"adult":false,"gender":0,"id":2476640,"known_for_department":"Lighting","name":"Eric Arnold Cortez","original_name":"Eric Arnold Cortez","popularity":0.6,"profile_path":null,"credit_id":"60162aca87a27a003ee15dac","department":"Lighting","job":"Lighting Technician"},{"adult":false,"gender":2,"id":2635023,"known_for_department":"Acting","name":"Jace Lee","original_name":"Jace Lee","popularity":0.6,"profile_path":"/oXW5PnwyNT565EYBOYL38yYnuXC.jpg","credit_id":"606a9b8a699fb70058824d66","department":"Crew","job":"Stunts"},{"adult":false,"gender":2,"id":2725433,"known_for_department":"Visual Effects","name":"Joe Howes","original_name":"Joe Howes","popularity":0.6,"profile_path":"/kMnlQ0V9LmSm9nhpDzpG3K5qQm3.jpg","credit_id":"5f24d73bf0647c003223984d","department":"Visual Effects","job":"Visual Effects"},{"adult":false,"gender":0,"id":2735583,"known_for_department":"Art","name":"Michael Elvidge","original_name":"Michael Elvidge","popularity":0.983,"profile_path":null,"credit_id":"601628c7873f00003ea659bc","department":"Crew","job":"Prop Maker"},{"adult":false,"gender":2,"id":2762067,"known_for_department":"Crew","name":"Jason Tubbs","original_name":"Jason Tubbs","popularity":0.6,"profile_path":null,"credit_id":"606a9b1b124c8d0078d4638d","department":"Crew","job":"Driver"},{"adult":false,"gender":0,"id":2808013,"known_for_department":"Visual Effects","name":"Reetu Aggarwal","original_name":"Reetu Aggarwal","popularity":0.6,"profile_path":null,"credit_id":"601629e2873f00003da6de00","department":"Visual Effects","job":"Visual Effects"},{"adult":false,"gender":0,"id":2823305,"known_for_department":"Crew","name":"Lee Adamson","original_name":"Lee Adamson","popularity":1.96,"profile_path":null,"credit_id":"606a9b975507e90029b2f40f","department":"Crew","job":"Stunts"},{"adult":false,"gender":0,"id":2836855,"known_for_department":"Visual Effects","name":"Rod Dimayuga","original_name":"Rod Dimayuga","popularity":0.6,"profile_path":null,"credit_id":"60162bc75b4fed0040a26dd5","department":"Visual Effects","job":"Senior Animator"},{"adult":false,"gender":0,"id":2841895,"known_for_department":"Art","name":"Kyle Brown","original_name":"Kyle Brown","popularity":1.388,"profile_path":null,"credit_id":"6016288c4df291003e2047f5","department":"Art","job":"Concept Artist"},{"adult":false,"gender":1,"id":2847225,"known_for_department":"Sound","name":"Jane Berry","original_name":"Jane Berry","popularity":1.001,"profile_path":null,"credit_id":"60162cc9aafebd003dd9c98b","department":"Sound","job":"Music Coordinator"},{"adult":false,"gender":0,"id":2854931,"known_for_department":"Lighting","name":"Lorenza Amato","original_name":"Lorenza Amato","popularity":0.997,"profile_path":null,"credit_id":"60162a79ed96bc0041fbe674","department":"Lighting","job":"Electrician"},{"adult":false,"gender":2,"id":2881089,"known_for_department":"Acting","name":"Daniel Nelson","original_name":"Daniel Nelson","popularity":1.162,"profile_path":"/jfVtAqELfncHRHomUrTuVVYXrg.jpg","credit_id":"606a99319ca759004099d9a8","department":"Crew","job":"Stunt Double"},{"adult":false,"gender":0,"id":2958909,"known_for_department":"Directing","name":"Ashley Douglass","original_name":"Ashley Douglass","popularity":0.6,"profile_path":null,"credit_id":"6016279a7f0540003fc831f5","department":"Directing","job":"Assistant Director"},{"adult":false,"gender":0,"id":2958910,"known_for_department":"Visual Effects","name":"Matt Allsopp","original_name":"Matt Allsopp","popularity":0.6,"profile_path":null,"credit_id":"601627d0907f26003f55e787","department":"Visual Effects","job":"Visual Development"},{"adult":false,"gender":0,"id":2958910,"known_for_department":"Visual Effects","name":"Matt Allsopp","original_name":"Matt Allsopp","popularity":0.6,"profile_path":null,"credit_id":"606a96e1ce5d820058ed34a3","department":"Production","job":"Co-Producer"},{"adult":false,"gender":0,"id":2958911,"known_for_department":"Art","name":"Kohen Barry","original_name":"Kohen Barry","popularity":0.6,"profile_path":null,"credit_id":"601627e1976a23003fa4b92a","department":"Art","job":"Sculptor"},{"adult":false,"gender":0,"id":2958912,"known_for_department":"Art","name":"Matt Boug","original_name":"Matt Boug","popularity":0.6,"profile_path":null,"credit_id":"601628b887a27a003ee15a80","department":"Art","job":"Set Dresser"},{"adult":false,"gender":0,"id":2958915,"known_for_department":"Crew","name":"Cyrus Apeles","original_name":"Cyrus Apeles","popularity":0.6,"profile_path":null,"credit_id":"60162935956658003d5a644a","department":"Crew","job":"Special Effects"},{"adult":false,"gender":0,"id":2958922,"known_for_department":"Crew","name":"Brenden Barry Brown","original_name":"Brenden Barry Brown","popularity":0.6,"profile_path":null,"credit_id":"601629693e09f3003e42588e","department":"Crew","job":"Special Effects Technician"},{"adult":false,"gender":0,"id":2958924,"known_for_department":"Crew","name":"Shaun Friedberg 'Pyrokinesis'","original_name":"Shaun Friedberg 'Pyrokinesis'","popularity":0.6,"profile_path":null,"credit_id":"6016299787a27a003ee15b7b","department":"Crew","job":"Motion Capture Artist"},{"adult":false,"gender":0,"id":2958927,"known_for_department":"Visual Effects","name":"Guillaume Barre","original_name":"Guillaume Barre","popularity":0.6,"profile_path":null,"credit_id":"601629f6ed96bc003ffb008a","department":"Visual Effects","job":"CG Artist"},{"adult":false,"gender":0,"id":2958929,"known_for_department":"Visual Effects","name":"Ben Bigiel","original_name":"Ben Bigiel","popularity":0.6,"profile_path":null,"credit_id":"60162a05d96c3c0040102745","department":"Visual Effects","job":"Modeling"},{"adult":false,"gender":0,"id":2958930,"known_for_department":"Crew","name":"Phil Chornohus","original_name":"Phil Chornohus","popularity":0.6,"profile_path":null,"credit_id":"60162a1c1511aa004053fc1e","department":"Crew","job":"Compositor"},{"adult":false,"gender":0,"id":2958931,"known_for_department":"Lighting","name":"Sheila Placiego","original_name":"Sheila Placiego","popularity":0.6,"profile_path":null,"credit_id":"60162a3a956658003d5a65c1","department":"Lighting","job":"Lighting Artist"},{"adult":false,"gender":0,"id":2958932,"known_for_department":"Lighting","name":"Jack Cale","original_name":"Jack Cale","popularity":0.6,"profile_path":null,"credit_id":"60162a90cb8028003f130ecc","department":"Lighting","job":"Lighting Artist"},{"adult":false,"gender":0,"id":2958933,"known_for_department":"Visual Effects","name":"Chakkarin Chansuk","original_name":"Chakkarin Chansuk","popularity":1.38,"profile_path":null,"credit_id":"60162bb73009aa003eb8ceb0","department":"Visual Effects","job":"Key Animation"},{"adult":false,"gender":0,"id":2958935,"known_for_department":"Visual Effects","name":"Alice Joubin","original_name":"Alice Joubin","popularity":0.6,"profile_path":null,"credit_id":"60162be2ed96bc0041fbe8fe","department":"Visual Effects","job":"Animation"},{"adult":false,"gender":0,"id":2958937,"known_for_department":"Production","name":"Nicolai Aladieff","original_name":"Nicolai Aladieff","popularity":0.6,"profile_path":null,"credit_id":"60162c5dd266a2003d108db2","department":"Production","job":"Location Assistant"},{"adult":false,"gender":0,"id":2958939,"known_for_department":"Production","name":"Jessica Cole","original_name":"Jessica Cole","popularity":0.6,"profile_path":null,"credit_id":"60162c6c907f26003d55d67c","department":"Production","job":"Location Manager"},{"adult":false,"gender":0,"id":2958940,"known_for_department":"Production","name":"Chelsea Genova","original_name":"Chelsea Genova","popularity":0.98,"profile_path":null,"credit_id":"60162c84956658003e5a40be","department":"Production","job":"Location Coordinator"},{"adult":false,"gender":0,"id":2958941,"known_for_department":"Production","name":"Emily Thallon","original_name":"Emily Thallon","popularity":0.6,"profile_path":null,"credit_id":"60162c96d96c3c003e10d344","department":"Production","job":"Location Assistant"},{"adult":false,"gender":0,"id":2958942,"known_for_department":"Crew","name":"Neil Brice","original_name":"Neil Brice","popularity":0.6,"profile_path":null,"credit_id":"60162cf62d3721003ec349e6","department":"Crew","job":"Driver"},{"adult":false,"gender":1,"id":3038336,"known_for_department":"Crew","name":"Holly McCredden","original_name":"Holly McCredden","popularity":0.6,"profile_path":null,"credit_id":"606a996744ea5400400f8f53","department":"Crew","job":"Stunt Double"},{"adult":false,"gender":1,"id":3038337,"known_for_department":"Crew","name":"Xanthia Marinelli","original_name":"Xanthia Marinelli","popularity":0.6,"profile_path":null,"credit_id":"606a99f0699fb70058824b70","department":"Crew","job":"Stunt Double"},{"adult":false,"gender":0,"id":3038340,"known_for_department":"Crew","name":"Makua Rothman","original_name":"Makua Rothman","popularity":0.6,"profile_path":null,"credit_id":"606a9a46ad59b5002ab93f75","department":"Crew","job":"Stunt Double"},{"adult":false,"gender":0,"id":3038345,"known_for_department":"Crew","name":"Kaillie Keaulana","original_name":"Kaillie Keaulana","popularity":0.6,"profile_path":null,"credit_id":"606a9aadebb99d00702b5ea7","department":"Crew","job":"Stunt Double"},{"adult":false,"gender":0,"id":3038348,"known_for_department":"Crew","name":"Hannah Shin","original_name":"Hannah Shin","popularity":0.6,"profile_path":null,"credit_id":"606a9aed9ca759004099dc57","department":"Crew","job":"Stunts"},{"adult":false,"gender":0,"id":3038348,"known_for_department":"Crew","name":"Hannah Shin","original_name":"Hannah Shin","popularity":0.6,"profile_path":null,"credit_id":"606a9ad0d29bdd006e3860be","department":"Crew","job":"Stunt Double"}]
     */

    private int id;
    private List<CastBean> cast;
    private List<CrewBean> crew;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<CastBean> getCast() {
        return cast;
    }

    public void setCast(List<CastBean> cast) {
        this.cast = cast;
    }

    public List<CrewBean> getCrew() {
        return crew;
    }

    public void setCrew(List<CrewBean> crew) {
        this.crew = crew;
    }

    public static class CastBean {
        /**
         * adult : false
         * gender : 2
         * id : 28846
         * known_for_department : Acting
         * name : Alexander Skarsgård
         * original_name : Alexander Skarsgård
         * popularity : 11.539
         * profile_path : /hIuDik6KDmHLrqZWxBVdXzUw1kq.jpg
         * cast_id : 27
         * character : Dr. Nathan Lind
         * credit_id : 5bd27583c3a3687437003310
         * order : 0
         */

        private boolean adult;
        private int gender;
        private int id;
        private String known_for_department;
        private String name;
        private String original_name;
        private double popularity;
        private String profile_path;
        private int cast_id;
        private String character;
        private String credit_id;
        private int order;

        public boolean isAdult() {
            return adult;
        }

        public void setAdult(boolean adult) {
            this.adult = adult;
        }

        public int getGender() {
            return gender;
        }

        public void setGender(int gender) {
            this.gender = gender;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getKnown_for_department() {
            return known_for_department;
        }

        public void setKnown_for_department(String known_for_department) {
            this.known_for_department = known_for_department;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getOriginal_name() {
            return original_name;
        }

        public void setOriginal_name(String original_name) {
            this.original_name = original_name;
        }

        public double getPopularity() {
            return popularity;
        }

        public void setPopularity(double popularity) {
            this.popularity = popularity;
        }

        public String getProfile_path() {
            return profile_path;
        }

        public void setProfile_path(String profile_path) {
            this.profile_path = profile_path;
        }

        public int getCast_id() {
            return cast_id;
        }

        public void setCast_id(int cast_id) {
            this.cast_id = cast_id;
        }

        public String getCharacter() {
            return character;
        }

        public void setCharacter(String character) {
            this.character = character;
        }

        public String getCredit_id() {
            return credit_id;
        }

        public void setCredit_id(String credit_id) {
            this.credit_id = credit_id;
        }

        public int getOrder() {
            return order;
        }

        public void setOrder(int order) {
            this.order = order;
        }
    }

    public static class CrewBean {
        /**
         * adult : false
         * gender : 2
         * id : 1706
         * known_for_department : Writing
         * name : Terry Rossio
         * original_name : Terry Rossio
         * popularity : 5.545
         * profile_path : null
         * credit_id : 600dae670b5fd6003e5ddb86
         * department : Writing
         * job : Story
         */

        private boolean adult;
        private int gender;
        private int id;
        private String known_for_department;
        private String name;
        private String original_name;
        private double popularity;
        private Object profile_path;
        private String credit_id;
        private String department;
        private String job;

        public boolean isAdult() {
            return adult;
        }

        public void setAdult(boolean adult) {
            this.adult = adult;
        }

        public int getGender() {
            return gender;
        }

        public void setGender(int gender) {
            this.gender = gender;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getKnown_for_department() {
            return known_for_department;
        }

        public void setKnown_for_department(String known_for_department) {
            this.known_for_department = known_for_department;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getOriginal_name() {
            return original_name;
        }

        public void setOriginal_name(String original_name) {
            this.original_name = original_name;
        }

        public double getPopularity() {
            return popularity;
        }

        public void setPopularity(double popularity) {
            this.popularity = popularity;
        }

        public Object getProfile_path() {
            return profile_path;
        }

        public void setProfile_path(Object profile_path) {
            this.profile_path = profile_path;
        }

        public String getCredit_id() {
            return credit_id;
        }

        public void setCredit_id(String credit_id) {
            this.credit_id = credit_id;
        }

        public String getDepartment() {
            return department;
        }

        public void setDepartment(String department) {
            this.department = department;
        }

        public String getJob() {
            return job;
        }

        public void setJob(String job) {
            this.job = job;
        }
    }
}
