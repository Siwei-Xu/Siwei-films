package com.example.uscfilms.adapter;

import android.content.Context;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.fragment.app.FragmentActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.uscfilms.R;
import com.example.uscfilms.bean.MoviePoplarBean;
import com.example.uscfilms.http.ApiConfig;
import com.example.uscfilms.viewHolder.ImageHolder;
import com.youth.banner.adapter.BannerAdapter;
import com.youth.banner.util.BannerUtils;

import java.util.List;

/**
 * 自定义布局，网络图片
 */
public class MovieImageNetAdapter extends BannerAdapter<MoviePoplarBean.ResultsBean, ImageHolder> {

    private Context mContext;

    public MovieImageNetAdapter(List<MoviePoplarBean.ResultsBean> mDatas, Context context) {
        super(mDatas);
        mContext = context;
    }

    @Override
    public ImageHolder onCreateHolder(ViewGroup parent, int viewType) {
        ImageView imageView = (ImageView) BannerUtils.getView(parent, R.layout.banner_image);
        //通过裁剪实现圆角
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            BannerUtils.setBannerRound(imageView, 20);
        }
        return new ImageHolder(imageView);
    }

    @Override
    public void onBindView(ImageHolder holder, MoviePoplarBean.ResultsBean data, int position, int size) {
        //通过图片加载器实现圆角，你也可以自己使用圆角的imageview，实现圆角的方法很多，自己尝试哈
        Glide.with(mContext)
                .load(ApiConfig.PICTURE_URL + data.getPoster_path())
                .apply(RequestOptions.bitmapTransform(new RoundedCorners(30)))
                .into(holder.imageView);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mListener != null){
                    mListener.OnDetailClick(data,view);
                }
            }
        });
    }

    public OnOperationClickListener mListener = null;

    public interface OnOperationClickListener {
        void OnDetailClick(MoviePoplarBean.ResultsBean resultsBean,View view);
    }

    public void setOperationClickListener(OnOperationClickListener listener) {
        this.mListener = listener;
    }

}
