package com.example.uscfilms.fragment;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.example.uscfilms.R;
import com.example.uscfilms.activity.DetailActivity;
import com.example.uscfilms.adapter.WatchListAdapter;
import com.example.uscfilms.bean.WatchListBean;
import com.example.uscfilms.dragview.DataUtils;
import com.example.uscfilms.dragview.IDragListener;
import com.example.uscfilms.dragview.OnItemTouchCallbackListener;
import com.example.uscfilms.dragview.RecyclerViewUtil;
import com.example.uscfilms.dragview.TouchCallback;
import com.example.uscfilms.dragview.TouchHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class WatchlistFragment extends Fragment implements OnItemTouchCallbackListener, IDragListener {
    List<WatchListBean> mFilm = new ArrayList<>();
    private RecyclerView rvWatchList;
    private TextView tvNoData;
    private TouchHelper touchHelper;//拖拽操作帮助类
    private WatchListAdapter mWatchListAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_watchlist, container, false);
        mFilm = DataUtils.getData(DataUtils.DEFAULT_SP_NAME, getActivity());
        initView(view);

        return view;
    }

    private void initView(View view) {
        rvWatchList = view.findViewById(R.id.rvWatchList);
        tvNoData = view.findViewById(R.id.tvNoData);

        RecyclerViewUtil.grid(getActivity(),3,rvWatchList);
        rvWatchList.setHasFixedSize(true);
        DataUtils.tool(getActivity());
        mWatchListAdapter = new WatchListAdapter(mFilm,getActivity(),this::startDrag);
//        mWatchListAdapter.setListener(this::startDrag);
        mWatchListAdapter.setWatchListClickListener(new WatchListAdapter.OnWatchListClickListener() {
            @Override
            public void OnClick(WatchListBean watchListBean) {
                Intent intent = new Intent(getActivity(), DetailActivity.class);
                intent.putExtra("DetailId",watchListBean.getId()+"");
                intent.putExtra("Type",watchListBean.getType().toLowerCase());
                startActivity(intent);
            }
        });
        rvWatchList.setAdapter(mWatchListAdapter);

        touchHelper = new TouchHelper(new TouchCallback(this));
        touchHelper.setEnableDrag(false);
        touchHelper.setEnableSwipe(false);
        touchHelper.attachToRecyclerView(rvWatchList);

        if(mFilm != null && mFilm.size() > 0){
            rvWatchList.setVisibility(View.VISIBLE);
            tvNoData.setVisibility(View.GONE);
        }else {
            rvWatchList.setVisibility(View.GONE);
            tvNoData.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        mFilm = DataUtils.getData(DataUtils.DEFAULT_SP_NAME, getActivity());
        mWatchListAdapter.setWatchListBeans(mFilm);
    }

    @Override
    public void onPause() {
        super.onPause();
        DataUtils.saveData(mFilm,DataUtils.DEFAULT_SP_NAME,getActivity());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
//        DataUtils.saveData(mFilm,DataUtils.DEFAULT_SP_NAME,getActivity());
    }

    @Override
    public void startDrag(RecyclerView.ViewHolder holder) {
        //获取系统震动服务
        Vibrator vib = (Vibrator) getActivity().getSystemService(Service.VIBRATOR_SERVICE);
        //震动70毫秒
        vib.vibrate(70);
        touchHelper.startDrag(holder);
    }

    @Override
    public void onSwiped(int adapterPosition) {

    }

    @Override
    public boolean onMove(int srcPosition, int targetPosition) {
        //处理拖拽事件
        if(mFilm == null || mFilm.size() == 0) {
            return false;
        }
        if(srcPosition >= 0 && srcPosition < mFilm.size() && targetPosition >= 0 && targetPosition < mFilm.size()) {
            //交换数据源两个数据的位置
            Collections.swap(mFilm,srcPosition,targetPosition);
            //更新视图
            mWatchListAdapter.notifyItemMoved(srcPosition,targetPosition);
            //消费事件
            return true;
        } else {
            return false;
        }
    }


}
