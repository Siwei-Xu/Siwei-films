package com.example.uscfilms.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.borjabravo.readmoretextview.ReadMoreTextView;
import com.bumptech.glide.Glide;
import com.example.uscfilms.MyApplication;
import com.example.uscfilms.R;
import com.example.uscfilms.adapter.CastAdapter;
import com.example.uscfilms.adapter.RecommendAdapter;
import com.example.uscfilms.adapter.ReviewAdapter;
import com.example.uscfilms.bean.MovieCreditBean;
import com.example.uscfilms.bean.MovieDetailBean;
import com.example.uscfilms.bean.MovieRecommendBean;
import com.example.uscfilms.bean.MovieReviewsBean;
import com.example.uscfilms.bean.MovieVideoBean;
import com.example.uscfilms.bean.TvDetailBean;
import com.example.uscfilms.bean.WatchListBean;
import com.example.uscfilms.dragview.DataUtils;
import com.example.uscfilms.http.ApiConfig;
import com.google.gson.Gson;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;

public class DetailActivity extends Activity implements View.OnClickListener {

    private YouTubePlayerView youtube_player_view;
    private ImageView ivPoster;
    private ReadMoreTextView readMoreTextView;
    private TextView tvGenres;
    private TextView tvYear;
    private ImageView ivAddWatchList;
    private ImageView ivDeleteWatchList;
    private ImageView ivFacebook;
    private ImageView ivTwitter;
    private RecyclerView rvCast;
    private RecyclerView rvReviews;
    private RecyclerView rvRecommended;

    private Gson mGson;
    private String mDetailId;
    private String mType;

    private String mHeadUrl;
    private TextView tvDetailName;
    private TextView tvReviews;
    private TextView tvRecommended;
    private TextView tvCast;
    List<WatchListBean> mFilm = new ArrayList<>();
    private String mPosterPath;
    private String mFilmName;
    private WatchListBean mCurrentWatchListBean;
    private int mCurrentIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        mFilm = DataUtils.getData(DataUtils.DEFAULT_SP_NAME, MyApplication.getApplication());
        initView();
    }

    private void initView() {
        youtube_player_view = (YouTubePlayerView) findViewById(R.id.youtube_player_view);
        youtube_player_view.setEnableAutomaticInitialization(false);
        ivPoster = (ImageView) findViewById(R.id.ivPoster);
        readMoreTextView = (ReadMoreTextView) findViewById(R.id.readMoreTextView);
        tvGenres = (TextView) findViewById(R.id.tvGenres);
        tvYear = (TextView) findViewById(R.id.tvYear);
        ivAddWatchList = (ImageView) findViewById(R.id.ivAddWatchList);
        ivDeleteWatchList = (ImageView) findViewById(R.id.ivDeleteWatchList);
        ivFacebook = (ImageView) findViewById(R.id.ivFacebook);
        ivTwitter = (ImageView) findViewById(R.id.ivTwitter);
        rvCast = (RecyclerView) findViewById(R.id.rvCast);
        rvReviews = (RecyclerView) findViewById(R.id.rvReviews);
        rvRecommended = (RecyclerView) findViewById(R.id.rvRecommended);
        tvDetailName = (TextView) findViewById(R.id.tvDetailName);
        tvReviews = (TextView) findViewById(R.id.tvReviews);
        tvRecommended = (TextView) findViewById(R.id.tvRecommended);

        tvCast = (TextView) findViewById(R.id.tvCast);
        ivAddWatchList.setOnClickListener(this);
        ivDeleteWatchList.setOnClickListener(this);
        ivFacebook.setOnClickListener(this);
        ivTwitter.setOnClickListener(this);

        rvCast.setLayoutManager(new GridLayoutManager(this, 3));
        rvReviews.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, true));
        rvRecommended.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, true));

        mGson = new Gson();
        Intent intent = getIntent();
        mDetailId = intent.getStringExtra("DetailId");
        mType = intent.getStringExtra("Type").toLowerCase();
        if (mType.equals("movie")) {
            mHeadUrl = ApiConfig.MOVIE_URL;
        } else if (mType.equals("tv")) {
            mHeadUrl = ApiConfig.TV_URL;
        }
        Log.e("mSearchItemAdapter", "DetailId    " + mDetailId + " " + intent.getStringExtra("DetailId") + "   " + "Type   " + mType);

        initDetail();
        initVideo();
        initCast();
        initReviews();
        initRecommend();
        Log.e("mFile.size oncreate",mFilm.size()+"");
        for (int i = 0; i < mFilm.size(); i++) {
            if (mFilm.get(i).getId().equals(mDetailId)) {
                ivAddWatchList.setVisibility(View.GONE);
                ivDeleteWatchList.setVisibility(View.VISIBLE);
                mCurrentIndex = i;
            }
        }
//        for (WatchListBean watchListBean : mFilm) {
//            if (watchListBean.getId().equals(mDetailId)) {
//                ivAddWatchList.setVisibility(View.GONE);
//                ivDeleteWatchList.setVisibility(View.VISIBLE);
//                mCurrentWatchListBean = watchListBean;
//                Log.e("mCurrentWatchListBean", mCurrentWatchListBean.toString());
//            }
//        }

    }

    private void initRecommend() {
        OkHttpUtils
                .get()
                .url(mHeadUrl + mDetailId + ApiConfig.RECOMMEND_AFTER_URL)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e("initRecommend", mHeadUrl + mDetailId + ApiConfig.RECOMMEND_AFTER_URL);
                        Log.e("initRecommend", response + "  ");
                        MovieRecommendBean movieRecommendBean = mGson.fromJson(response, MovieRecommendBean.class);
                        if (movieRecommendBean != null) {
                            List<MovieRecommendBean.ResultsBean> results = movieRecommendBean.getResults();
                            if (results.size() == 0) {
                                tvRecommended.setVisibility(View.GONE);
                                rvRecommended.setVisibility(View.GONE);
                            }
                            RecommendAdapter recommendAdapter = new RecommendAdapter(results, DetailActivity.this);
                            rvRecommended.setAdapter(recommendAdapter);
                            recommendAdapter.setOperationClickListener(new RecommendAdapter.OnOperationClickListener() {
                                @Override
                                public void OnClick(MovieRecommendBean.ResultsBean resultsBean, View view) {
                                    Intent intent = new Intent(DetailActivity.this, DetailActivity.class);
                                    intent.putExtra("DetailId", resultsBean.getId() + "");
                                    intent.putExtra("Type", mType);
                                    startActivity(intent);
                                }
                            });
                        }

                    }
                });
    }

    private void initReviews() {
        OkHttpUtils
                .get()
                .url(mHeadUrl + mDetailId + ApiConfig.REVIEWS_AFTER_URL)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e("initReviews", response);
                        MovieReviewsBean movieReviewsBean = mGson.fromJson(response, MovieReviewsBean.class);
                        if (movieReviewsBean != null) {
                            List<MovieReviewsBean.ResultsBean> results = movieReviewsBean.getResults();
                            ;
                            if (results.size() == 0) {
                                tvReviews.setVisibility(View.GONE);
                                rvReviews.setVisibility(View.GONE);
                            } else if (results.size() < 3) {
                                ReviewAdapter reviewAdapter = new ReviewAdapter(results, DetailActivity.this);
                                rvReviews.setAdapter(reviewAdapter);

                                reviewAdapter.setReviewContentClickListener(new ReviewAdapter.OnReviewContentClickListener() {
                                    @Override
                                    public void OnClick(MovieReviewsBean.ResultsBean resultsBean) {
                                        Intent intent = new Intent(DetailActivity.this, ReviewDetailActivity.class);
                                        intent.putExtra("review", resultsBean);
                                        startActivity(intent);
                                    }
                                });
                            } else {
                                List<MovieReviewsBean.ResultsBean> resultsBeans = results.subList(0, 3);
                                ReviewAdapter reviewAdapter = new ReviewAdapter(resultsBeans, DetailActivity.this);
                                rvReviews.setAdapter(reviewAdapter);

                                reviewAdapter.setReviewContentClickListener(new ReviewAdapter.OnReviewContentClickListener() {
                                    @Override
                                    public void OnClick(MovieReviewsBean.ResultsBean resultsBean) {
                                        Intent intent = new Intent(DetailActivity.this, ReviewDetailActivity.class);
                                        intent.putExtra("review", resultsBean);
                                        startActivity(intent);
                                    }
                                });
                            }

                        }
                    }
                });
    }

    private void initCast() {
        OkHttpUtils
                .get()
                .url(mHeadUrl + mDetailId + ApiConfig.CAST_AFTER_URL)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        MovieCreditBean movieCreditBean = mGson.fromJson(response, MovieCreditBean.class);
                        if (movieCreditBean != null) {
                            if (movieCreditBean.getCast().size() > 6) {
                                List<MovieCreditBean.CastBean> cast = movieCreditBean.getCast().subList(0, 6);
                                CastAdapter castAdapter = new CastAdapter(cast, DetailActivity.this);
                                rvCast.setAdapter(castAdapter);
                            } else if (movieCreditBean.getCast().size() <= 6) {
                                List<MovieCreditBean.CastBean> cast = movieCreditBean.getCast();
                                CastAdapter castAdapter = new CastAdapter(cast, DetailActivity.this);
                                rvCast.setAdapter(castAdapter);
                            } else if (movieCreditBean.getCast().size() == 0) {
                                tvCast.setVisibility(View.GONE);
                                rvCast.setVisibility(View.GONE);
                            }

                        }
                    }
                });
    }

    private void initDetail() {
        OkHttpUtils
                .get()
                .url(mHeadUrl + mDetailId + ApiConfig.DETAIL_AFTER_URL)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        if (mType.equals("movie")) {
                            MovieDetailBean movieDetailBean = mGson.fromJson(response, MovieDetailBean.class);
                            if (movieDetailBean != null) {
                                ivPoster.setVisibility(View.VISIBLE);
                                youtube_player_view.setVisibility(View.GONE);
                                Glide.with(DetailActivity.this).load(ApiConfig.PICTURE_URL + movieDetailBean.getPoster_path()).into(ivPoster);
                                tvDetailName.setText(movieDetailBean.getTitle());
                                readMoreTextView.setText(movieDetailBean.getOverview());
                                String genres = "";
                                for (MovieDetailBean.GenresBean genre : movieDetailBean.getGenres()) {
                                    genres += genre.getName() + " ";
                                }
                                tvGenres.setText(genres);
                                Log.e("detial", mDetailId);
                                tvYear.setText(movieDetailBean.getRelease_date().substring(0, 4));
                                mPosterPath = movieDetailBean.getPoster_path();
                                mFilmName = movieDetailBean.getTitle();
                            }
                        } else if (mType.equals("tv")) {
                            TvDetailBean tvDetailBean = mGson.fromJson(response, TvDetailBean.class);
                            if (tvDetailBean != null) {
                                ivPoster.setVisibility(View.VISIBLE);
                                youtube_player_view.setVisibility(View.GONE);
                                Glide.with(DetailActivity.this).load(ApiConfig.PICTURE_URL + tvDetailBean.getPoster_path()).into(ivPoster);
                                tvDetailName.setText(tvDetailBean.getName());
                                readMoreTextView.setText(tvDetailBean.getOverview());
                                String genres = "";
                                for (TvDetailBean.GenresBean genre : tvDetailBean.getGenres()) {
                                    genres += genre.getName() + " ";
                                }

                                tvGenres.setText(genres);
                                Log.e("detial", mDetailId);
                                tvYear.setText(tvDetailBean.getFirst_air_date().substring(0, 4));

                            }
                        }
                    }
                });
    }

    private void initVideo() {
        OkHttpUtils
                .get()
                .url(mHeadUrl + mDetailId + ApiConfig.VIDEO_AFTER_URL)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        MovieVideoBean movieVideoBean = mGson.fromJson(response, MovieVideoBean.class);
                        if (movieVideoBean.getResults().size() > 0) {
                            youtube_player_view.setVisibility(View.VISIBLE);
                            ivPoster.setVisibility(View.GONE);
                            youtube_player_view.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
                                @Override
                                public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                                    youTubePlayer.loadVideo(movieVideoBean.getResults().get(0).getKey(), 0);
                                }
                            });
                        }
                    }
                });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivDeleteWatchList:
//                if (mCurrentWatchListBean != null) {
//                    mFilm.remove(mCurrentWatchListBean);
//                    Toast.makeText(DetailActivity.this, mFilmName + " was removed from Watchlist", Toast.LENGTH_SHORT).show();
//                    mCurrentWatchListBean = null;
//                    ivDeleteWatchList.setVisibility(View.GONE);
//                    ivAddWatchList.setVisibility(View.VISIBLE);
//                }
                if (mCurrentIndex != -1) {
                    mFilm.remove(mCurrentIndex);
                    Log.e("mFile.size",mFilm.size()+"");
                    Toast.makeText(DetailActivity.this, mFilmName + " was removed from Collection", Toast.LENGTH_SHORT).show();
                    mCurrentIndex = -1;
                    ivDeleteWatchList.setVisibility(View.GONE);
                    ivAddWatchList.setVisibility(View.VISIBLE);
                    DataUtils.saveData(mFilm, DataUtils.DEFAULT_SP_NAME, MyApplication.getApplication());
                }

                break;
            case R.id.ivFacebook:
                String url = ApiConfig.FACEBOOK_SHARE+mType.toLowerCase()+"/"+mDetailId;
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
                break;
            case R.id.ivTwitter:
                url = ApiConfig.TWITTER_SHARE+mType.toLowerCase()+"/"+mDetailId;
                i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
                break;
            case R.id.ivAddWatchList:
                mFilm.add(new WatchListBean(mDetailId, mType, mPosterPath));
                DataUtils.saveData(mFilm, DataUtils.DEFAULT_SP_NAME, MyApplication.getApplication());
                Log.e("mFilm",mFilm.size()+"");
                Toast.makeText(DetailActivity.this, mFilmName + " was added to Collection", Toast.LENGTH_SHORT).show();
                ivDeleteWatchList.setVisibility(View.VISIBLE);
                ivAddWatchList.setVisibility(View.GONE);
                break;
        }
    }


    @Override
    protected void onPause() {
        super.onPause();
        Log.e("mFilm onPause",mFilm.size()+"");
        DataUtils.saveData(mFilm, DataUtils.DEFAULT_SP_NAME, MyApplication.getApplication());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("mFilm onDestroy",mFilm.size()+"");
        youtube_player_view.release();
//        DataUtils.saveData(mFilm, DataUtils.DEFAULT_SP_NAME, "film", MyApplication.getApplication());
//        DataUtils.saveData(mFilm, DataUtils.DEFAULT_SP_NAME, "film", DetailActivity.this);
    }



}
