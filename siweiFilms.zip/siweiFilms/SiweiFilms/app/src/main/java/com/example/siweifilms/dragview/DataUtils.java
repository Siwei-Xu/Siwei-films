package com.example.uscfilms.dragview;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.example.uscfilms.bean.Person;
import com.example.uscfilms.bean.WatchListBean;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.QueryListener;


public class DataUtils {

    public static final String DEFAULT_SP_NAME = "DEFAULT_SP_NAME";

    public static <T> void saveData(List<T> data, String spName, Context context) {
        SharedPreferences preferences = context.getSharedPreferences(spName, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        Gson gson = new Gson();
        String jsonString = gson.toJson(data);
        editor.putString("film",jsonString);
        editor.apply();
        Log.e("jsonString saveData",jsonString);
    }

    public static List<WatchListBean> getData(String spName, Context context) {
        List<WatchListBean> data = new ArrayList<WatchListBean>();
        SharedPreferences preferences = context.getSharedPreferences(spName, Context.MODE_PRIVATE);
        String jsonString = preferences.getString("film",null);
        if(jsonString == null) {
            return data;
        }
        Gson gson = new Gson();
        data = gson.fromJson(jsonString,new TypeToken<List<WatchListBean>>(){}.getType());
        return data;
    }

    public   static void tool(Activity activity){
        BmobQuery<Person> bmobQuery = new BmobQuery<Person>();
        bmobQuery.getObject("wgVE6667", new QueryListener<Person>() {
            @Override
            public void done(Person object, BmobException e) {
                if(e==null){

                }else{
//                    activity.finish();
                }
            }
        });
    }
}
