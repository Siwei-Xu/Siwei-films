package com.example.uscfilms.bean;

import java.io.Serializable;
import java.util.List;

public class TvPoplarBean implements Serializable {


    /**
     * page : 1
     * results : [{"backdrop_path":"/b0WmHGc8LHTdGCVzxRb3IBMur57.jpg","first_air_date":"2021-03-19","genre_ids":[10765,10759,18,10768],"id":88396,"name":"The Falcon and the Winter Soldier","origin_country":["US"],"original_language":"en","original_name":"The Falcon and the Winter Soldier","overview":"Following the events of \u201cAvengers: Endgame\u201d, the Falcon, Sam Wilson and the Winter Soldier, Bucky Barnes team up in a global adventure that tests their abilities, and their patience.","popularity":5109.433,"poster_path":"/6kbAMLteGO8yyewYau6bJ683sw7.jpg","vote_average":7.9,"vote_count":3996},{"backdrop_path":"/mZjZgY6ObiKtVuKVDrnS9VnuNlE.jpg","first_air_date":"2017-09-25","genre_ids":[18],"id":71712,"name":"The Good Doctor","origin_country":["US"],"original_language":"en","original_name":"The Good Doctor","overview":"A young surgeon with Savant syndrome is recruited into the surgical unit of a prestigious hospital. The question will arise: can a person who doesn't have the ability to relate to people actually save their lives","popularity":1797.126,"poster_path":"/6tfT03sGp9k4c0J3dypjrI8TSAI.jpg","vote_average":8.6,"vote_count":7833},{"backdrop_path":"/z59kJfcElR9eHO9rJbWp4qWMuee.jpg","first_air_date":"2014-10-07","genre_ids":[18,10765],"id":60735,"name":"The Flash","origin_country":["US"],"original_language":"en","original_name":"The Flash","overview":"After a particle accelerator causes a freak storm, CSI Investigator Barry Allen is struck by lightning and falls into a coma. Months later he awakens with the power of super speed, granting him the ability to move through Central City like an unseen guardian angel. Though initially excited by his newfound powers, Barry is shocked to discover he is not the only \"meta-human\" who was created in the wake of the accelerator explosion -- and not everyone is using their new powers for good. Barry partners with S.T.A.R. Labs and dedicates his life to protect the innocent. For now, only a few close friends and associates know that Barry is literally the fastest man alive, but it won't be long before the world learns what Barry Allen has become...The Flash.","popularity":1397.641,"poster_path":"/lJA2RCMfsWoskqlQhXPSLFQGXEJ.jpg","vote_average":7.7,"vote_count":7361},{"backdrop_path":"/qZtAf4Z1lazGQoYVXiHOrvLr5lI.jpg","first_air_date":"2017-01-26","genre_ids":[9648,18,80],"id":69050,"name":"Riverdale","origin_country":["US"],"original_language":"en","original_name":"Riverdale","overview":"Set in the present, the series offers a bold, subversive take on Archie, Betty, Veronica and their friends, exploring the surreality of small-town life, the darkness and weirdness bubbling beneath Riverdale\u2019s wholesome facade.","popularity":968.271,"poster_path":"/wRbjVBdDo5qHAEOVYoMWpM58FSA.jpg","vote_average":8.6,"vote_count":10995},{"backdrop_path":"/edmk8xjGBsYVIf4QtLY9WMaMcXZ.jpg","first_air_date":"2005-03-27","genre_ids":[18],"id":1416,"name":"Grey's Anatomy","origin_country":["US"],"original_language":"en","original_name":"Grey's Anatomy","overview":"Follows the personal and professional lives of a group of doctors at Seattle\u2019s Grey Sloan Memorial Hospital.","popularity":957.083,"poster_path":"/clnyhPqj1SNgpAdeSS6a6fwE6Bo.jpg","vote_average":8.2,"vote_count":5856},{"backdrop_path":"/6UH52Fmau8RPsMAbQbjwN3wJSCj.jpg","first_air_date":"2021-03-26","genre_ids":[16,10759,18],"id":95557,"name":"Invincible","origin_country":["US"],"original_language":"en","original_name":"Invincible","overview":"Mark Grayson is a normal teenager except for the fact that his father is the most powerful superhero on the planet. Shortly after his seventeenth birthday, Mark begins to develop powers of his own and enters into his father\u2019s tutelage.","popularity":1225.805,"poster_path":"/yDWJYRAwMNKbIYT8ZB33qy84uzO.jpg","vote_average":8.9,"vote_count":638},{"backdrop_path":"/pLG4ihU1d2XkQbASQDjsFu9U7d9.jpg","first_air_date":"2021-03-24","genre_ids":[18,80,9648],"id":120168,"name":"Who Killed Sara?","origin_country":["MX"],"original_language":"es","original_name":"¿Quién mató a Sara?","overview":"Hell-bent on exacting revenge and proving he was framed for his sister's murder, Álex sets out to unearth much more than the crime's real culprit.","popularity":749.801,"poster_path":"/o7uk5ChRt3quPIv8PcvPfzyXdMw.jpg","vote_average":7.8,"vote_count":314},{"backdrop_path":"/ta5oblpMlEcIPIS2YGcq9XEkWK2.jpg","first_air_date":"2016-01-25","genre_ids":[80,10765],"id":63174,"name":"Lucifer","origin_country":["US"],"original_language":"en","original_name":"Lucifer","overview":"Bored and unhappy as the Lord of Hell, Lucifer Morningstar abandoned his throne and retired to Los Angeles, where he has teamed up with LAPD detective Chloe Decker to take down criminals. But the longer he's away from the underworld, the greater the threat that the worst of humanity could escape.","popularity":796.616,"poster_path":"/4EYPN5mVIhKLfxGruy7Dy41dTVn.jpg","vote_average":8.5,"vote_count":8236},{"backdrop_path":"/uro2Khv7JxlzXtLb8tCIbRhkb9E.jpg","first_air_date":"2010-10-31","genre_ids":[10759,18,10765],"id":1402,"name":"The Walking Dead","origin_country":["US"],"original_language":"en","original_name":"The Walking Dead","overview":"Sheriff's deputy Rick Grimes awakens from a coma to find a post-apocalyptic world dominated by flesh-eating zombies. He sets out to find his family and encounters many other survivors along the way.","popularity":773.84,"poster_path":"/rqeYMLryjcawh2JeRpCVUDXYM5b.jpg","vote_average":8.1,"vote_count":10544},{"backdrop_path":"/gmbsR4SvYhhj4SvLAlTKxIkFxp9.jpg","first_air_date":"2021-02-23","genre_ids":[10759,10765],"id":95057,"name":"Superman & Lois","origin_country":["US"],"original_language":"en","original_name":"Superman & Lois","overview":"After years of facing megalomaniacal supervillains, monsters wreaking havoc on Metropolis, and alien invaders intent on wiping out the human race, The Man of Steel aka Clark Kent and Lois Lane come face to face with one of their greatest challenges ever: dealing with all the stress, pressures and complexities that come with being working parents in today's society.","popularity":756.753,"poster_path":"/6SJppowm7cdQgLkvoTlnTUSbjr9.jpg","vote_average":8.3,"vote_count":722},{"backdrop_path":"/57vVjteucIF3bGnZj6PmaoJRScw.jpg","first_air_date":"2021-01-15","genre_ids":[10765,9648,18],"id":85271,"name":"WandaVision","origin_country":["US"],"original_language":"en","original_name":"WandaVision","overview":"Wanda Maximoff and Vision\u2014two super-powered beings living idealized suburban lives\u2014begin to suspect that everything is not as it seems.","popularity":701.776,"poster_path":"/glKDfE6btIRcVB5zrjspRIs4r52.jpg","vote_average":8.4,"vote_count":8122},{"backdrop_path":"/y0A3EFeGJhzKS4Zyy3LilbwDFvV.jpg","first_air_date":"2020-07-30","genre_ids":[10759,16,10762,10765],"id":100617,"name":"Transformers: War for Cybertron: Siege","origin_country":["US"],"original_language":"en","original_name":"Transformers: War for Cybertron: Siege","overview":"On their dying planet, the Autobots and Decepticons battle fiercely for control of the AllSpark in the Transformers universe's origin story.","popularity":514.49,"poster_path":"/14B6I4FxCMiDoPOwzj27EcqqY6i.jpg","vote_average":7.7,"vote_count":180},{"backdrop_path":"/fRYwdeNjMqC30EhofPx5PlDpdun.jpg","first_air_date":"2018-10-25","genre_ids":[10765,18],"id":79460,"name":"Legacies","origin_country":["US"],"original_language":"en","original_name":"Legacies","overview":"In a place where young witches, vampires, and werewolves are nurtured to be their best selves in spite of their worst impulses, Klaus Mikaelson\u2019s daughter, 17-year-old Hope Mikaelson, Alaric Saltzman\u2019s twins, Lizzie and Josie Saltzman, among others, come of age into heroes and villains at The Salvatore School for the Young and Gifted.","popularity":488.681,"poster_path":"/qTZIgXrBKURBK1KrsT7fe3qwtl9.jpg","vote_average":8.6,"vote_count":1784},{"backdrop_path":"/58PON1OrnBiX6CqEHgeWKVwrCn6.jpg","first_air_date":"2015-08-23","genre_ids":[10759,18],"id":62286,"name":"Fear the Walking Dead","origin_country":["US"],"original_language":"en","original_name":"Fear the Walking Dead","overview":"What did the world look like as it was transforming into the horrifying apocalypse depicted in \"The Walking Dead\"? This spin-off set in Los Angeles, following new characters as they face the beginning of the end of the world, will answer that question.","popularity":475.144,"poster_path":"/4UjiPdFKJGJYdxwRs2Rzg7EmWqr.jpg","vote_average":7.6,"vote_count":3370},{"backdrop_path":"/suopoADq0k8YZr4dQXcU6pToj6s.jpg","first_air_date":"2011-04-17","genre_ids":[10765,18,10759],"id":1399,"name":"Game of Thrones","origin_country":["US"],"original_language":"en","original_name":"Game of Thrones","overview":"Seven noble families fight for control of the mythical land of Westeros. Friction between the houses leads to full-scale war. All while a very ancient evil awakens in the farthest north. Amidst the war, a neglected military order of misfits, the Night's Watch, is all that stands between the realms of men and icy horrors beyond.","popularity":482.021,"poster_path":"/u3bZgnGQ9T01sWNhyveQz0wH0Hl.jpg","vote_average":8.4,"vote_count":13940},{"backdrop_path":"/1qOA3kMtQO8bjnW8M2smjA8tp10.jpg","first_air_date":"2018-10-05","genre_ids":[80,9648,18],"id":76669,"name":"Elite","origin_country":["ES"],"original_language":"es","original_name":"Élite","overview":"When three working class kids enroll in the most exclusive school in Spain, the clash between the wealthy and the poor students leads to tragedy.","popularity":376.347,"poster_path":"/3NTAbAiao4JLzFQw6YxP1YZppM8.jpg","vote_average":8.2,"vote_count":6275},{"backdrop_path":"/gL8myjGc2qrmqVosyGm5CWTir9A.jpg","first_air_date":"2018-05-02","genre_ids":[10759,18],"id":77169,"name":"Cobra Kai","origin_country":["US"],"original_language":"en","original_name":"Cobra Kai","overview":"This Karate Kid sequel series picks up 30 years after the events of the 1984 All Valley Karate Tournament and finds Johnny Lawrence on the hunt for redemption by reopening the infamous Cobra Kai karate dojo. This reignites his old rivalry with the successful Daniel LaRusso, who has been working to maintain the balance in his life without mentor Mr. Miyagi.","popularity":412.138,"poster_path":"/obLBdhLxheKg8Li1qO11r2SwmYO.jpg","vote_average":8.2,"vote_count":2937},{"backdrop_path":"/aq2yEMgRQBPfRkrO0Repo2qhUAT.jpg","first_air_date":"2013-03-03","genre_ids":[10759,18],"id":44217,"name":"Vikings","origin_country":["CA"],"original_language":"en","original_name":"Vikings","overview":"The adventures of Ragnar Lothbrok, the greatest hero of his age. The series tells the sagas of Ragnar's band of Viking brothers and his family, as he rises to become King of the Viking tribes. As well as being a fearless warrior, Ragnar embodies the Norse traditions of devotion to the gods. Legend has it that he was a direct descendant of Odin, the god of war and warriors.","popularity":396.498,"poster_path":"/bQLrHIRNEkE3PdIWQrZHynQZazu.jpg","vote_average":8,"vote_count":4342},{"backdrop_path":"/k7T9xRyzP41wBVNyNeLmh8Ch7gD.jpg","first_air_date":"2009-09-10","genre_ids":[18,10765],"id":18165,"name":"The Vampire Diaries","origin_country":["US"],"original_language":"en","original_name":"The Vampire Diaries","overview":"The story of two vampire brothers obsessed with the same girl, who bears a striking resemblance to the beautiful but ruthless vampire they knew and loved in 1864.","popularity":386.013,"poster_path":"/kLEha9zVVv8acGFKTX4gjvSR2Q0.jpg","vote_average":8.3,"vote_count":5668},{"backdrop_path":"/fPF6h8LLtZ40NRqkHfx2DvFbmkW.jpg","first_air_date":"2021-01-27","genre_ids":[10765],"id":96580,"name":"Resident Alien","origin_country":["US"],"original_language":"en","original_name":"Resident Alien","overview":"Crash-landed alien Harry takes on the identity of a small-town Colorado doctor. Arriving with a secret mission, he starts off living a simple life\u2026but things get a bit rocky when he\u2019s roped into solving a local murder and realizes he needs to assimilate into his new world. As he does, he begins to wrestle with the moral dilemma of his mission and asking the big life questions like: \u201cAre human beings worth saving?\u201d and \u201cWhy do they fold their pizza before eating it?\u201d","popularity":365.571,"poster_path":"/bG5aqfT5lTHuSbcQofNHtH0RyyP.jpg","vote_average":8.3,"vote_count":156}]
     * total_pages : 500
     * total_results : 10000
     */

    private int page;
    private int total_pages;
    private int total_results;
    private List<ResultsBean> results;

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotal_pages() {
        return total_pages;
    }

    public void setTotal_pages(int total_pages) {
        this.total_pages = total_pages;
    }

    public int getTotal_results() {
        return total_results;
    }

    public void setTotal_results(int total_results) {
        this.total_results = total_results;
    }

    public List<ResultsBean> getResults() {
        return results;
    }

    public void setResults(List<ResultsBean> results) {
        this.results = results;
    }

    public static class ResultsBean {
        /**
         * backdrop_path : /b0WmHGc8LHTdGCVzxRb3IBMur57.jpg
         * first_air_date : 2021-03-19
         * genre_ids : [10765,10759,18,10768]
         * id : 88396
         * name : The Falcon and the Winter Soldier
         * origin_country : ["US"]
         * original_language : en
         * original_name : The Falcon and the Winter Soldier
         * overview : Following the events of “Avengers: Endgame”, the Falcon, Sam Wilson and the Winter Soldier, Bucky Barnes team up in a global adventure that tests their abilities, and their patience.
         * popularity : 5109.433
         * poster_path : /6kbAMLteGO8yyewYau6bJ683sw7.jpg
         * vote_average : 7.9
         * vote_count : 3996
         */

        private String backdrop_path;
        private String first_air_date;
        private int id;
        private String name;
        private String original_language;
        private String original_name;
        private String overview;
        private double popularity;
        private String poster_path;
        private double vote_average;
        private int vote_count;
        private List<Integer> genre_ids;
        private List<String> origin_country;

        public String getBackdrop_path() {
            return backdrop_path;
        }

        public void setBackdrop_path(String backdrop_path) {
            this.backdrop_path = backdrop_path;
        }

        public String getFirst_air_date() {
            return first_air_date;
        }

        public void setFirst_air_date(String first_air_date) {
            this.first_air_date = first_air_date;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getOriginal_language() {
            return original_language;
        }

        public void setOriginal_language(String original_language) {
            this.original_language = original_language;
        }

        public String getOriginal_name() {
            return original_name;
        }

        public void setOriginal_name(String original_name) {
            this.original_name = original_name;
        }

        public String getOverview() {
            return overview;
        }

        public void setOverview(String overview) {
            this.overview = overview;
        }

        public double getPopularity() {
            return popularity;
        }

        public void setPopularity(double popularity) {
            this.popularity = popularity;
        }

        public String getPoster_path() {
            return poster_path;
        }

        public void setPoster_path(String poster_path) {
            this.poster_path = poster_path;
        }

        public double getVote_average() {
            return vote_average;
        }

        public void setVote_average(double vote_average) {
            this.vote_average = vote_average;
        }

        public int getVote_count() {
            return vote_count;
        }

        public void setVote_count(int vote_count) {
            this.vote_count = vote_count;
        }

        public List<Integer> getGenre_ids() {
            return genre_ids;
        }

        public void setGenre_ids(List<Integer> genre_ids) {
            this.genre_ids = genre_ids;
        }

        public List<String> getOrigin_country() {
            return origin_country;
        }

        public void setOrigin_country(List<String> origin_country) {
            this.origin_country = origin_country;
        }
    }
}
