package com.example.uscfilms.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.uscfilms.R;
import com.example.uscfilms.bean.MovieReviewsBean;
import com.example.uscfilms.bean.TvPoplarBean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.ViewHolder> {

    private List<MovieReviewsBean.ResultsBean> mBeans = new ArrayList<>();
    private Context mContext;

    public ReviewAdapter(List<MovieReviewsBean.ResultsBean> beans, Context context) {
        mBeans = beans;
        mContext = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = View.inflate(mContext, R.layout.layout_review_item, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MovieReviewsBean.ResultsBean resultsBean = mBeans.get(position);
        String username = resultsBean.getAuthor_details().getUsername();
        int rating = (int) resultsBean.getAuthor_details().getRating();
        String content = resultsBean.getContent();
        String created_at = resultsBean.getCreated_at();

        String substring = created_at.substring(0, 10);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        Date time = null;
        try {
            time = format.parse(substring);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String[] split = time.toString().split("\\s+");
//        tvUsernameDate.setText("by " + username + " on " + time.toString().substring(0, 3) + "," + time.toString().substring(4, 10) + " " + time.toString().substring(30, 34));
        holder.tvUsernameDate.setText("by " + username + " on " + split[0] + "," + split[1] + " " +  split[2] + " " + split[5]);
        holder.tvContent.setText(content);
        holder.tvRating.setText((rating / 2) + "/5");

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) {
                    mListener.OnClick(resultsBean);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return mBeans.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView tvUsernameDate;
        private TextView tvRating;
        private TextView tvContent;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvUsernameDate = itemView.findViewById(R.id.tvUsernameDate);
            tvRating = itemView.findViewById(R.id.tvRating);
            tvContent = itemView.findViewById(R.id.tvContent);

        }
    }

    public OnReviewContentClickListener mListener = null;

    public interface OnReviewContentClickListener {
        void OnClick(MovieReviewsBean.ResultsBean resultsBean);
    }

    public void setReviewContentClickListener(OnReviewContentClickListener listener) {
        this.mListener = listener;
    }

}
