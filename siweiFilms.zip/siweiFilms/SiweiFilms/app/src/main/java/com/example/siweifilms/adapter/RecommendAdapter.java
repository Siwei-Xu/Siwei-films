package com.example.uscfilms.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.uscfilms.R;
import com.example.uscfilms.bean.MovieRecommendBean;
import com.example.uscfilms.bean.TvPoplarBean;
import com.example.uscfilms.http.ApiConfig;

import java.util.ArrayList;
import java.util.List;

public class RecommendAdapter extends RecyclerView.Adapter<RecommendAdapter.ViewHolder> {

    private List<MovieRecommendBean.ResultsBean> mBeans = new ArrayList<>();
    private Context mContext;

    public RecommendAdapter(List<MovieRecommendBean.ResultsBean> beans, Context context) {
        this.mBeans = beans;
        mContext = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = View.inflate(mContext, R.layout.layout_home_item, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MovieRecommendBean.ResultsBean resultsBean = mBeans.get(position);

        Log.e("RecommendAdapterURL",ApiConfig.PICTURE_URL + resultsBean.getPoster_path());
        Glide.with(mContext)
                .load(ApiConfig.PICTURE_URL + resultsBean.getPoster_path())
                .apply(RequestOptions.bitmapTransform(new RoundedCorners(30)))
                .into(holder.ivPoster);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mListener != null){
                    mListener.OnClick(resultsBean,view);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return mBeans.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView ivPoster;
        private ImageView ivOperation;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            ivPoster = itemView.findViewById(R.id.ivPoster);
            ivOperation = itemView.findViewById(R.id.ivOperation);
            ivOperation.setVisibility(View.GONE);

        }
    }

    public OnOperationClickListener mListener = null;

    public interface OnOperationClickListener {
        void OnClick(MovieRecommendBean.ResultsBean resultsBean, View view);
    }

    public void setOperationClickListener(OnOperationClickListener listener) {
        this.mListener = listener;
    }
}
