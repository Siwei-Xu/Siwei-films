package com.example.uscfilms.http;

public class ApiConfig {

    public static final String MOVIE_TOP_RATED_URL = "https://api.themoviedb.org/3/movie/top_rated?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US&page=1";
    public static final String MOVIE_POPLAR_URL = "https://api.themoviedb.org/3/movie/popular?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US&page=1";

    public static final String TV_TOP_RATED_URL = "https://api.themoviedb.org/3/tv/top_rated?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US&page=1";
    public static final String TV_POPLAR_URL = "https://api.themoviedb.org/3/tv/popular?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US&page=1";

//    public static final String SEARCH_URL = "https://api.themoviedb.org/3/search/multi?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US&query=Captain%20America&page=1&include_adult=false";
    public static final String SEARCH_URL = "https://api.themoviedb.org/3/search/multi?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US&query=";

    //https://www.themoviedb.org/t/p/w600_and_h900_bestv2/inJjDhCjfhh3RtrJWBmmDqeuSYC.jpg
    public static final String PICTURE_URL = "https://www.themoviedb.org/t/p/w600_and_h900_bestv2";


    public static final String TV_URL = "https://api.themoviedb.org/3/tv/";
    public static final String MOVIE_URL = "https://api.themoviedb.org/3/movie/";

    //https://api.themoviedb.org/3/tv/71712?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US
    public static final String DETAIL_AFTER_URL ="?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US";

    //https://api.themoviedb.org/3/movie/399566/videos?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US
    public static final String VIDEO_AFTER_URL = "/videos?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US";

    //https://api.themoviedb.org/3/movie/399566/credits?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US
    public static final String CAST_AFTER_URL = "/credits?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US";

    //https://api.themoviedb.org/3/movie/399566/reviews?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US&page=1
    public static final String REVIEWS_AFTER_URL = "/reviews?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US&page=1";

    //https://api.themoviedb.org/3/movie/399566/recommendations?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US&page=1
    public static final String RECOMMEND_AFTER_URL = "/recommendations?api_key=75a8b7ecc77cdec9634b5b2b68053d44&language=en-US&page=1";


    public static final String TWITTER_SHARE = "http://www.twitter.com/share?url=https://www.themoviedb.org/";

    public static final String FACEBOOK_SHARE = "http://www.facebook.com/sharer/sharer.php?u=https://www.themoviedb.org/";
}
