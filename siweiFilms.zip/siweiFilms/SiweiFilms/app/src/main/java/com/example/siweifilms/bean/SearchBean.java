package com.example.uscfilms.bean;

import java.util.List;

public class SearchBean {


    /**
     * page : 1
     * results : [{"adult":false,"backdrop_path":"/kvRT3GwcnqGHzPjXIVrVPhUix7Z.jpg","genre_ids":[12,28,878],"id":271110,"media_type":"movie","original_language":"en","original_title":"Captain America: Civil War","overview":"Following the events of Age of Ultron, the collective governments of the world pass an act designed to regulate all superhuman activity. This polarizes opinion amongst the Avengers, causing two factions to side with Iron Man or Captain America, which causes an epic battle between former allies.","popularity":130.101,"poster_path":"/rAGiXaUfPzY7CDEyNKUofk3Kw2e.jpg","release_date":"2016-04-27","title":"Captain America: Civil War","video":false,"vote_average":7.4,"vote_count":17854},{"adult":false,"backdrop_path":"/yFuKvT4Vm3sKHdFY4eG6I4ldAnn.jpg","genre_ids":[28,12,878],"id":1771,"media_type":"movie","original_language":"en","original_title":"Captain America: The First Avenger","overview":"During World War II, Steve Rogers is a sickly man from Brooklyn who's transformed into super-soldier Captain America to aid in the war effort. Rogers must stop the Red Skull \u2013 Adolf Hitler's ruthless head of weaponry, and the leader of an organization that intends to use a mysterious device of untold powers for world domination.","popularity":80.383,"poster_path":"/vSNxAJTlD0r02V9sPYpOjqDZXUK.jpg","release_date":"2011-07-22","title":"Captain America: The First Avenger","video":false,"vote_average":7,"vote_count":16614},{"adult":false,"backdrop_path":"/yHB0eNR8rvCpn0VdghEwBsXAC0N.jpg","genre_ids":[28,12,878],"id":100402,"media_type":"movie","original_language":"en","original_title":"Captain America: The Winter Soldier","overview":"After the cataclysmic events in New York with The Avengers, Steve Rogers, aka Captain America is living quietly in Washington, D.C. and trying to adjust to the modern world. But when a S.H.I.E.L.D. colleague comes under attack, Steve becomes embroiled in a web of intrigue that threatens to put the world at risk. Joining forces with the Black Widow, Captain America struggles to expose the ever-widening conspiracy while fighting off professional assassins sent to silence him at every turn. When the full scope of the villainous plot is revealed, Captain America and the Black Widow enlist the help of a new ally, the Falcon. However, they soon find themselves up against an unexpected and formidable enemy\u2014the Winter Soldier.","popularity":71.505,"poster_path":"/5r1zWuzbsVAYSPzvCecAReGhN7k.jpg","release_date":"2014-03-20","title":"Captain America: The Winter Soldier","video":false,"vote_average":7.7,"vote_count":14371},{"adult":false,"backdrop_path":"/fHx9e35Vn7mMH3O0Fmfds70ABo8.jpg","genre_ids":[28,878,10752],"id":13995,"media_type":"movie","original_language":"en","original_title":"Captain America","overview":"During World War II, a brave, patriotic American Soldier undergoes experiments to become a new supersoldier, \"Captain America.\" Racing to Germany to sabotage the rockets of Nazi baddie \"Red Skull\", Captain America winds up frozen until the 1990s. He reawakens to find that the Red Skull has changed identities and is now planning to kidnap the President of the United States.","popularity":22.088,"poster_path":"/lUsDBhzogxYOU5XshARgnnZY4Xd.jpg","release_date":"1990-12-14","title":"Captain America","video":false,"vote_average":4.6,"vote_count":280},{"adult":false,"backdrop_path":"/pPdMq9bk1BmGpben9T0ox91OIWS.jpg","genre_ids":[28,10770,878],"id":197467,"media_type":"movie","original_language":"en","original_title":"Captain America","overview":"An artist, Steve Rogers, is nearly murdered by spies, looking for his late father's national secrets. He is saved during surgery when a secret formula is injected into him; this serum not only heals him but also gives him fantastic strength and lightning reflexes.  To help him solve the mystery behind his father\u2019s murder and bring those guilty to justice, a government agency equips him with a special motorcycle loaded with gadgets and an indestructible shield. Now armed, he battles against the nation's enemies as the Sentinel of Liberty, Captain America.","popularity":13.919,"poster_path":"/j9jmwSINYQ7Qdv7oGeWN84mckg.jpg","release_date":"1979-01-19","title":"Captain America","video":false,"vote_average":4,"vote_count":39},{"adult":false,"backdrop_path":"/zxpQlh172HOLlG7UohW8sm7iOdz.jpg","genre_ids":[12,16,28],"id":284274,"media_type":"movie","original_language":"en","original_title":"Iron Man & Captain America: Heroes United","overview":"Iron Man and Captain America battle to keep the Red Skull and his triggerman, Taskmaster, from unleashing an army of Hydra Brutes on the world!  Sequel to the film \"Iron Man & Hulk: Heroes United\" and feature Iron Man teaming up with Captain America, it comes to accompany the live-action film \"Captain America: The Winter Soldier\".","popularity":27.569,"poster_path":"/gkOhGeRfDPJlFvZWsdRjXEZ3ymY.jpg","release_date":"2014-07-29","title":"Iron Man & Captain America: Heroes United","video":false,"vote_average":6,"vote_count":81},{"adult":false,"backdrop_path":null,"genre_ids":[28,12,878],"id":106355,"media_type":"movie","original_language":"en","original_title":"Captain America","overview":"Superhero Captain America battles the evil forces of the archvillain called The Scarab, who poisons his enemies and steals a secret device capable of destroying buildings by sound vibrations.","popularity":9.73,"poster_path":"/b15xz96lSiH1JC7uYKofXJz0HTD.jpg","release_date":"1944-02-05","title":"Captain America","video":false,"vote_average":6.1,"vote_count":13},{"adult":false,"backdrop_path":null,"genre_ids":[28,18,878,10770],"id":197481,"media_type":"movie","original_language":"en","original_title":"Captain America II: Death Too Soon","overview":"A government agent is looking for a missing scientist, believing that a revolutionary leader known as Miguel has him, and that he is using him to get his formula for something that can accelerate the aging process. He sends Steve Rogers aka Captain America to find him and rescue the scientist, his only lead is a chemical that the scientist needs for his formula. As he gets closer to the truth Miguel threatens to spray the chemical on a major city unless his demands are met. But the President does not negotiate with terrorists, can Captain America save the day!?","popularity":7.141,"poster_path":"/mu3YGtmU2HwoB9ZS0RNPRU2BF78.jpg","release_date":"1979-11-23","title":"Captain America II: Death Too Soon","video":false,"vote_average":3.8,"vote_count":28},{"adult":false,"backdrop_path":"/hGg4e8ZuLOYT46ERS5LY2Qnb4q5.jpg","genre_ids":[99],"id":379040,"media_type":"movie","original_language":"en","original_title":"Marvel's Captain America: 75 Heroic Years","overview":"A full-length documentary that follows the history of Captain America from 1941 to present and explores how \u201cCap\u201d has been a reflection of the changing times and the world he has existed in throughout the years. Fans will hear from various Marvel luminaries including Stan Lee, Joe Quesada, Clark Gregg, Ming-Na Wen, Chloe Bennet, Jeph Loeb, Louis D\u2019Esposito, Chris Evans and Hayley Attwell, as well as family members of Cap\u2019s creators.","popularity":5.541,"poster_path":"/lr8ZujMvC36pHXRiamsrEex5Nip.jpg","release_date":"2016-01-19","title":"Marvel's Captain America: 75 Heroic Years","video":false,"vote_average":7.7,"vote_count":25},{"adult":false,"backdrop_path":null,"genre_ids":[35,99],"id":473941,"media_type":"movie","original_language":"en","original_title":"Captain America: Civil War Reenactors","overview":"Chad and Angus (Tony Hale & Adam Pally) are pool store employees who share a passion for cosplay and faithfully reenacting major battles from Marvel comic book canon. This documentary examines the coworkers' devoted yet contentious relationship.","popularity":3.731,"poster_path":"/8or9JKM93yfwWcEL816Ch8g1jDh.jpg","release_date":"2016-05-11","title":"Captain America: Civil War Reenactors","video":false,"vote_average":0,"vote_count":0},{"adult":false,"backdrop_path":null,"genre_ids":[99],"id":448357,"media_type":"movie","original_language":"en","original_title":"Captain America: The First Avenger - Heightened Technology","overview":"A brief piece that looks at the \"secret arms race\" that plays out in the film and the resultant future-inspired weapons and vehicles that appear in the movie.","popularity":4.567,"poster_path":"/2GvmFcpKmpKqJbKtAcHrAfeL3WV.jpg","release_date":"2011-10-25","title":"Captain America: The First Avenger - Heightened Technology","video":true,"vote_average":7.9,"vote_count":13},{"adult":false,"backdrop_path":"/7KDO2McCQDQUpyUY6LcOJghnofe.jpg","genre_ids":[99],"id":448378,"media_type":"movie","original_language":"en","original_title":"United We Stand, Divided We Fall: The Making of 'Captain America: Civil War'","overview":"A two part feature. Part 1 (22:25) features cast and crew looking back at the story's comic book origins and discussing the story's thematic depth and relevance, the large assortment of characters featured in the film, the directors' contributions, the casts' abilities to perform complex stunt work, making various scenes, character relationships and development in the film, shooting locations, key props, Ant-Man's role in the film, choosing which characters would side with which faction, and General Ross' part in the movie. Part 2 (23:18) begins with a discussion of Vision's role in the film and Paul Bettany's performance, the part Black Panther plays in the movie and Chadwick Boseman's work on the film, Tom Holland's performance and Spider-Man's part in the story, making the large-scale battle between the warring factions, the villain Zemo, a major revelation in the film, and more.","popularity":6.294,"poster_path":"/1xJNi6ljfFFWeLmDI5DFslLq7L2.jpg","release_date":"2016-09-13","title":"United We Stand, Divided We Fall: The Making of 'Captain America: Civil War'","video":false,"vote_average":7.4,"vote_count":11},{"adult":false,"backdrop_path":null,"genre_ids":[],"id":315164,"media_type":"movie","original_language":"en","original_title":"The Origin of Captain America","overview":"A young man reads a comic depicting what the title says. We see his face and reactions. He finally finishes the book and leaves the scene.","popularity":1.091,"poster_path":null,"release_date":"1964-01-01","title":"The Origin of Captain America","video":false,"vote_average":0,"vote_count":0},{"adult":false,"backdrop_path":null,"genre_ids":[99],"id":448359,"media_type":"movie","original_language":"en","original_title":"Captain America: The First Avenger - The Transformation","overview":"A brief piece that offers an in-depth look at the process of digitally shrinking Actor Chris Evans for the film's first act.","popularity":1.42,"poster_path":"/8YXB6PzoEbcpx3pCcgXxBF6qWi5.jpg","release_date":"2011-10-25","title":"Captain America: The First Avenger - The Transformation","video":true,"vote_average":9.4,"vote_count":5},{"adult":false,"backdrop_path":"/NV8h1qAu9q4iK6G0eUT0LNR6GO.jpg","genre_ids":[99],"id":791401,"media_type":"movie","original_language":"en","original_title":"Captain Mike Across America","overview":"During the 2004 presidential election, Michael Moore set off on a 60 city tour (mostly colleges), making stops in the 20 battleground states, to help raise voting awareness.","popularity":0.985,"poster_path":"/xf81BLFGy22QqI03Z2Yte5jqv32.jpg","release_date":"2007-09-07","title":"Captain Mike Across America","video":false,"vote_average":8.5,"vote_count":2},{"adult":false,"backdrop_path":null,"genre_ids":[28],"id":58447,"media_type":"movie","original_language":"tr","original_title":"3 dev adam","overview":"Istanbul is being terrorized by a crime wave, and the police call in American superhero Captain America and Mexican wrestler Santo to put a stop to it.","popularity":5.73,"poster_path":"/nIALVkYLRwLxrwoktTUW3CGn2qe.jpg","release_date":"1973-01-01","title":"Three Giant Men","video":false,"vote_average":4.1,"vote_count":13},{"adult":false,"backdrop_path":null,"genre_ids":[99],"id":448352,"media_type":"movie","original_language":"en","original_title":"Behind the Skull","overview":"A look back at the history of Red Skull, casting the role, and creating the character's right look for the movie.","popularity":1.562,"poster_path":"/bJlf0AFAV36z9KRRP99y5GcaCap.jpg","release_date":"2011-10-25","title":"Captain America: The First Avenger - Behind the Skull","video":true,"vote_average":6,"vote_count":4},{"adult":false,"gender":2,"id":1956663,"known_for":[{"adult":false,"backdrop_path":"/gkkBhctHPGg8hrmtWbO3ySZoj4z.jpg","genre_ids":[36,18,53],"id":453201,"media_type":"movie","original_language":"en","original_title":"The 15:17 to Paris","overview":"In August 2015, an ISIS terrorist boarded train #9364 from Brussels to Paris. Armed with an AK-47 and enough ammo to kill more than 500 people, the terrorist might have succeeded except for three American friends who refused to give in to fear. One was a college student, one was a martial arts enthusiast and airman first class in the U.S. Air Force, and the other was a member of the Oregon National Guard, and all three pals proved fearless as they charged and ultimately overpowered the gunman after he emerged from a bathroom armed and ready to kill.","poster_path":"/qxJQ0VBCuJkJhJmuWzxI408ngwd.jpg","release_date":"2018-02-02","title":"The 15:17 to Paris","video":false,"vote_average":5.4,"vote_count":1248},{"adult":false,"backdrop_path":"/1GOUhxgZNftCtcuwvpYCMuDDLle.jpg","genre_ids":[99],"id":468912,"media_type":"movie","original_language":"pt","original_title":"ISIS: Rise of Terror","overview":"","poster_path":"/5zJtUPKyaXJeU9HBvb3U6jwSh6m.jpg","release_date":"2016-11-13","title":"ISIS: Rise of Terror","video":false,"vote_average":8,"vote_count":1}],"known_for_department":"Acting","media_type":"person","name":"Spencer Stone","popularity":0.6,"profile_path":"/yL6DJbzHmxhLwk5ajDrnMvaOiDX.jpg"},{"backdrop_path":"/vhbMTE6UVbIoyiD262wRYwFiNBa.jpg","first_air_date":"1966-09-05","genre_ids":[16,10759,10765,10762],"id":2164,"media_type":"tv","name":"The Marvel Super Heroes","origin_country":["CA","US"],"original_language":"en","original_name":"The Marvel Super Heroes","overview":"This cartoon series, characterized by extremely limited animation, features five of the most popular super-powered heroes from Marvel Comics: the Incredible Hulk, the Mighty Thor, Captain America, Iron Man, and the Sub-Mariner.","popularity":11.646,"poster_path":"/iqBeSf9akkdX7SQt10ryd3T29Mz.jpg","vote_average":7.8,"vote_count":2},{"adult":false,"backdrop_path":null,"genre_ids":[16,35],"id":303008,"media_type":"movie","original_language":"en","original_title":"Captain Amazing-Lad Saves America","overview":"With just a flyspeck of talent and a ginormous amount of dumb-luck, this gallantly square-jawed super person dispenses a cup of American justice that no dastardly villain or reckless pedestrian can withstand. CRIMINALS TAKE CARE! JAYWALKERS BEWARE! Wittily written and vividly voiced, this timeless collection contains some of the most enduring and entertaining episodes from the Quality Cheese Archives. Animated absurdly for all ages.","popularity":0.6,"poster_path":null,"release_date":"2014-03-25","title":"Captain Amazing-Lad Saves America","video":true,"vote_average":0,"vote_count":0}]
     * total_pages : 2
     * total_results : 21
     */

    private int page;
    private int total_pages;
    private int total_results;
    private List<ResultsBean> results;

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotal_pages() {
        return total_pages;
    }

    public void setTotal_pages(int total_pages) {
        this.total_pages = total_pages;
    }

    public int getTotal_results() {
        return total_results;
    }

    public void setTotal_results(int total_results) {
        this.total_results = total_results;
    }

    public List<ResultsBean> getResults() {
        return results;
    }

    public void setResults(List<ResultsBean> results) {
        this.results = results;
    }

    public static class ResultsBean {
        /**
         * adult : false
         * backdrop_path : /kvRT3GwcnqGHzPjXIVrVPhUix7Z.jpg
         * genre_ids : [12,28,878]
         * id : 271110
         * media_type : movie
         * original_language : en
         * original_title : Captain America: Civil War
         * overview : Following the events of Age of Ultron, the collective governments of the world pass an act designed to regulate all superhuman activity. This polarizes opinion amongst the Avengers, causing two factions to side with Iron Man or Captain America, which causes an epic battle between former allies.
         * popularity : 130.101
         * poster_path : /rAGiXaUfPzY7CDEyNKUofk3Kw2e.jpg
         * release_date : 2016-04-27
         * title : Captain America: Civil War
         * video : false
         * vote_average : 7.4
         * vote_count : 17854
         * gender : 2
         * known_for : [{"adult":false,"backdrop_path":"/gkkBhctHPGg8hrmtWbO3ySZoj4z.jpg","genre_ids":[36,18,53],"id":453201,"media_type":"movie","original_language":"en","original_title":"The 15:17 to Paris","overview":"In August 2015, an ISIS terrorist boarded train #9364 from Brussels to Paris. Armed with an AK-47 and enough ammo to kill more than 500 people, the terrorist might have succeeded except for three American friends who refused to give in to fear. One was a college student, one was a martial arts enthusiast and airman first class in the U.S. Air Force, and the other was a member of the Oregon National Guard, and all three pals proved fearless as they charged and ultimately overpowered the gunman after he emerged from a bathroom armed and ready to kill.","poster_path":"/qxJQ0VBCuJkJhJmuWzxI408ngwd.jpg","release_date":"2018-02-02","title":"The 15:17 to Paris","video":false,"vote_average":5.4,"vote_count":1248},{"adult":false,"backdrop_path":"/1GOUhxgZNftCtcuwvpYCMuDDLle.jpg","genre_ids":[99],"id":468912,"media_type":"movie","original_language":"pt","original_title":"ISIS: Rise of Terror","overview":"","poster_path":"/5zJtUPKyaXJeU9HBvb3U6jwSh6m.jpg","release_date":"2016-11-13","title":"ISIS: Rise of Terror","video":false,"vote_average":8,"vote_count":1}]
         * known_for_department : Acting
         * name : Spencer Stone
         * profile_path : /yL6DJbzHmxhLwk5ajDrnMvaOiDX.jpg
         * first_air_date : 1966-09-05
         * origin_country : ["CA","US"]
         * original_name : The Marvel Super Heroes
         */

        private boolean adult;
        private String backdrop_path;
        private int id;
        private String media_type;
        private String original_language;
        private String original_title;
        private String overview;
        private double popularity;
        private String poster_path;
        private String release_date;
        private String title;
        private boolean video;
        private double vote_average;
        private int vote_count;
        private int gender;
        private String known_for_department;
        private String name;
        private String profile_path;
        private String first_air_date;
        private String original_name;
        private List<Integer> genre_ids;
        private List<KnownForBean> known_for;
        private List<String> origin_country;

        @Override
        public String toString() {
            return "ResultsBean{" +
                    "adult=" + adult +
                    ", backdrop_path='" + backdrop_path + '\'' +
                    ", id=" + id +
                    ", media_type='" + media_type + '\'' +
                    ", original_language='" + original_language + '\'' +
                    ", original_title='" + original_title + '\'' +
                    ", overview='" + overview + '\'' +
                    ", popularity=" + popularity +
                    ", poster_path='" + poster_path + '\'' +
                    ", release_date='" + release_date + '\'' +
                    ", title='" + title + '\'' +
                    ", video=" + video +
                    ", vote_average=" + vote_average +
                    ", vote_count=" + vote_count +
                    ", gender=" + gender +
                    ", known_for_department='" + known_for_department + '\'' +
                    ", name='" + name + '\'' +
                    ", profile_path='" + profile_path + '\'' +
                    ", first_air_date='" + first_air_date + '\'' +
                    ", original_name='" + original_name + '\'' +
                    ", genre_ids=" + genre_ids +
                    ", known_for=" + known_for +
                    ", origin_country=" + origin_country +
                    '}';
        }

        public boolean isAdult() {
            return adult;
        }

        public void setAdult(boolean adult) {
            this.adult = adult;
        }

        public String getBackdrop_path() {
            return backdrop_path;
        }

        public void setBackdrop_path(String backdrop_path) {
            this.backdrop_path = backdrop_path;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getMedia_type() {
            return media_type;
        }

        public void setMedia_type(String media_type) {
            this.media_type = media_type;
        }

        public String getOriginal_language() {
            return original_language;
        }

        public void setOriginal_language(String original_language) {
            this.original_language = original_language;
        }

        public String getOriginal_title() {
            return original_title;
        }

        public void setOriginal_title(String original_title) {
            this.original_title = original_title;
        }

        public String getOverview() {
            return overview;
        }

        public void setOverview(String overview) {
            this.overview = overview;
        }

        public double getPopularity() {
            return popularity;
        }

        public void setPopularity(double popularity) {
            this.popularity = popularity;
        }

        public String getPoster_path() {
            return poster_path;
        }

        public void setPoster_path(String poster_path) {
            this.poster_path = poster_path;
        }

        public String getRelease_date() {
            return release_date;
        }

        public void setRelease_date(String release_date) {
            this.release_date = release_date;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public boolean isVideo() {
            return video;
        }

        public void setVideo(boolean video) {
            this.video = video;
        }

        public double getVote_average() {
            return vote_average;
        }

        public void setVote_average(double vote_average) {
            this.vote_average = vote_average;
        }

        public int getVote_count() {
            return vote_count;
        }

        public void setVote_count(int vote_count) {
            this.vote_count = vote_count;
        }

        public int getGender() {
            return gender;
        }

        public void setGender(int gender) {
            this.gender = gender;
        }

        public String getKnown_for_department() {
            return known_for_department;
        }

        public void setKnown_for_department(String known_for_department) {
            this.known_for_department = known_for_department;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getProfile_path() {
            return profile_path;
        }

        public void setProfile_path(String profile_path) {
            this.profile_path = profile_path;
        }

        public String getFirst_air_date() {
            return first_air_date;
        }

        public void setFirst_air_date(String first_air_date) {
            this.first_air_date = first_air_date;
        }

        public String getOriginal_name() {
            return original_name;
        }

        public void setOriginal_name(String original_name) {
            this.original_name = original_name;
        }

        public List<Integer> getGenre_ids() {
            return genre_ids;
        }

        public void setGenre_ids(List<Integer> genre_ids) {
            this.genre_ids = genre_ids;
        }

        public List<KnownForBean> getKnown_for() {
            return known_for;
        }

        public void setKnown_for(List<KnownForBean> known_for) {
            this.known_for = known_for;
        }

        public List<String> getOrigin_country() {
            return origin_country;
        }

        public void setOrigin_country(List<String> origin_country) {
            this.origin_country = origin_country;
        }

        public static class KnownForBean {
            /**
             * adult : false
             * backdrop_path : /gkkBhctHPGg8hrmtWbO3ySZoj4z.jpg
             * genre_ids : [36,18,53]
             * id : 453201
             * media_type : movie
             * original_language : en
             * original_title : The 15:17 to Paris
             * overview : In August 2015, an ISIS terrorist boarded train #9364 from Brussels to Paris. Armed with an AK-47 and enough ammo to kill more than 500 people, the terrorist might have succeeded except for three American friends who refused to give in to fear. One was a college student, one was a martial arts enthusiast and airman first class in the U.S. Air Force, and the other was a member of the Oregon National Guard, and all three pals proved fearless as they charged and ultimately overpowered the gunman after he emerged from a bathroom armed and ready to kill.
             * poster_path : /qxJQ0VBCuJkJhJmuWzxI408ngwd.jpg
             * release_date : 2018-02-02
             * title : The 15:17 to Paris
             * video : false
             * vote_average : 5.4
             * vote_count : 1248
             */

            private boolean adult;
            private String backdrop_path;
            private int id;
            private String media_type;
            private String original_language;
            private String original_title;
            private String overview;
            private String poster_path;
            private String release_date;
            private String title;
            private boolean video;
            private double vote_average;
            private int vote_count;
            private List<Integer> genre_ids;

            public boolean isAdult() {
                return adult;
            }

            public void setAdult(boolean adult) {
                this.adult = adult;
            }

            public String getBackdrop_path() {
                return backdrop_path;
            }

            public void setBackdrop_path(String backdrop_path) {
                this.backdrop_path = backdrop_path;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getMedia_type() {
                return media_type;
            }

            public void setMedia_type(String media_type) {
                this.media_type = media_type;
            }

            public String getOriginal_language() {
                return original_language;
            }

            public void setOriginal_language(String original_language) {
                this.original_language = original_language;
            }

            public String getOriginal_title() {
                return original_title;
            }

            public void setOriginal_title(String original_title) {
                this.original_title = original_title;
            }

            public String getOverview() {
                return overview;
            }

            public void setOverview(String overview) {
                this.overview = overview;
            }

            public String getPoster_path() {
                return poster_path;
            }

            public void setPoster_path(String poster_path) {
                this.poster_path = poster_path;
            }

            public String getRelease_date() {
                return release_date;
            }

            public void setRelease_date(String release_date) {
                this.release_date = release_date;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public boolean isVideo() {
                return video;
            }

            public void setVideo(boolean video) {
                this.video = video;
            }

            public double getVote_average() {
                return vote_average;
            }

            public void setVote_average(double vote_average) {
                this.vote_average = vote_average;
            }

            public int getVote_count() {
                return vote_count;
            }

            public void setVote_count(int vote_count) {
                this.vote_count = vote_count;
            }

            public List<Integer> getGenre_ids() {
                return genre_ids;
            }

            public void setGenre_ids(List<Integer> genre_ids) {
                this.genre_ids = genre_ids;
            }
        }
    }
}
