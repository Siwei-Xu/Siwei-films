package com.example.uscfilms;

import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws ParseException {
        String s = "2021-03-24T22:20:16.047Z";
        System.out.println(s.substring(0, 10));
        String date4string = "2021-03-24";
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
//        Date time = format.parse(date4string);
        String time = "Sat May 07 00:00:00 PDT 2016";
        String[] split = time.split("\\s+");
        for (int i = 0; i < split.length; i++) {
            System.out.println(i + "  " + split[i]);
        }
        System.out.println("将字符串的 November 27 2018 格式化为日期为：" + time);
        System.out.println(time.toString().substring(0, 3));
        System.out.println(time.toString().substring(4, 10));
        System.out.println(time.toString().substring(30, 34));
        System.out.println("on " + time.toString().substring(0, 3) + "," + time.toString().substring(4, 10) + " " + time.toString().substring(24, 28));
    }
}